/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.Graphics;

public class GameStateStarting extends GameState
{
    public GameScene game = null;
    SimpleText message = null;
    int time_out = 25;
    int time_counter = 0;

    public GameStateStarting(GameScene game)
    {
        String msg;

        this.game = game;
        
        if (game.level_index == 10)
            msg = "Final Stage";
        else
            msg = "Stage " + String.valueOf(game.level_index);

        message = new SimpleText(msg, -200, 100, 120, 100);
        game.create_game_objects();
    }

    void input(int keyStates) {
        game.update_ceferino(keyStates);
        message.update();
        time_counter += 1;
        
        // si termina de contar pasa al siguiente estado.
        if (time_counter > time_out)
            game.change_state(new GameStatePlaying(game));
    }

    void render(Graphics g)
    {
        game.render_all_objects(g);
        message.draw(g);
    }
    
    void add_pause()
    {
    }
}
