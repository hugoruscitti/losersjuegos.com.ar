/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import java.io.IOException;
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;

public class World extends GameCanvas implements Runnable
{
    private boolean done;
    public boolean arePaused;
    boolean enable_sound;
    private int frame_time;
    Scene scene = null;
    Scene nextScene = null;
    Image pauseImage = null;
    public DonCeferinoMobile main = null;
    public Graphics graphics;
    long lastPaint = 0;

    private static final long INTERRUPT_THRESHOLD_TIME = 1500;


    public World(DonCeferinoMobile main)
    {
        super(true);
        this.main = main;

        setFullScreenMode(true);
        done = true;
        frame_time = 30;
        loadPauseImage();

        change_scene_inmediately(new SceneEnableAudio(this));
        //change_scene_inmediately(new GameOverScene(this));
        //change_scene_inmediately(new GameScene(this, 1));

    }

    protected void hideNotify()
    {
        arePaused = true;
    }

    protected void showNotify()
    {
    }



    public void change_scene(Scene new_scene)
    {
        
        nextScene = new SceneTransition(this, new_scene);
        new_scene.input(0);
    }


    public void change_scene_inmediately(Scene new_scene)
    {
        nextScene = new_scene;
        new_scene.input(0);
    }

    public void start()
    {
        done = false;
        new Thread(this).start();
    }

    public void stop()
    {
    }

    public void run()
    {
        long start, end;
        int duration;
        int keyStates = 0;

        
        graphics = getGraphics();


        while (!done)
        {
            keyStates = getKeyStates();
            start = System.currentTimeMillis();

            if (! arePaused)
            {
                if (nextScene != null)
                {
                    System.gc();
                    scene = nextScene;
                    nextScene = null;
                    System.gc();
                }

                scene.input(keyStates);
            }

            if (scene != null)
                scene.render(graphics);

            if (arePaused)
            {
                checkPauseDone();
                drawPausedMessage(graphics);
            }
            
            flushGraphics();

            // sincronización
            end = System.currentTimeMillis();
            duration = (int) (end - start);

            if (duration < frame_time) {
                try {
                    Thread.sleep(frame_time - duration);
                } catch (InterruptedException ie) {
                    done = true;
                }
            }
        }
    }

    private void checkPauseDone()
    {
        int key = getKeyStates();

        if ((key & FIRE_PRESSED) != 0)
            arePaused = false;
    }

    public void drawPausedMessage(Graphics graphics)
    {
        graphics.setColor(0, 0, 0);
        graphics.fillRect(0, 0, 240, 89);
        graphics.drawImage(pauseImage, 0, 89, 0);
        graphics.fillRect(0, 231, 240, 89);
        graphics.setColor(255, 255, 255);
    }

    public void paint(Graphics g)
    {

    }
    
    public void close()
    {
        main.notifyDestroyed();
    }

    public void set_enable_sound(boolean state)
    {
        this.enable_sound = state;
    }

    public boolean are_soundEnabled()
    {
        return this.enable_sound;
    }

    public void loadPauseImage()
    {
        try
        {
            pauseImage = Image.createImage("/data/pause.png");
        }
        catch (IOException e)
        {
            System.err.println("Can't load 'pause.png'");
        }
    }
}
