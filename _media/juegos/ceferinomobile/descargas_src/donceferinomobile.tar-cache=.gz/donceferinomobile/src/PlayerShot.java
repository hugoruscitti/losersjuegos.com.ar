/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import java.io.*;

public class PlayerShot
{
    Sprite sprite;
    Image line_1 = null;
    GameScene game;
    int x;
    int y;
    int initial_y;
    int size;
    boolean has_to_die = false;

    public PlayerShot(GameScene game, int x, int y)
    {
        Image image;
        this.game = game;
        this.size = size;
        image = load_images();

        sprite = new Sprite(image, 15, 34);
        sprite.setVisible(true);
        this.x = x;
        this.y = y;
        initial_y = y;
        update();
    }

    private Image load_images()
    {
        Image image = null;

        try {
            image = Image.createImage("/data/fire.png");
        } catch (IOException e) {
            System.err.println("Can't load 'fire.png' image");
        }

        try {
            line_1 = Image.createImage("/data/line_1.png");
        } catch (IOException e) {
            System.err.println("Can't load 'line_1.png' image");
        }

        return image;
    }

    public Sprite getSprite()
    {
        return sprite;
    }

    public void update()
    {
        y -= 8;
        sprite.setPosition(x - 8, y - 34);
        
        if (game.level.get_collision_at(x, y - 30))
            has_to_die = true;

        if (y < 0)
            has_to_die = true;
        else
        {
            // colisiones con esferas
            Ball ball = game.get_ball_that_can_kill(x, y - 34, initial_y);

            if (ball != null)
                has_to_die = true;
            
            BreakTile bt = game.get_break_tile_that_can_kill(x, y - 34, initial_y);

            if (bt != null)
                has_to_die = true;
        }
    }

    public void drawline(Graphics g)
    {
        int actual_y = y;
        int rest;

        for (actual_y = y; actual_y < initial_y - 34; actual_y += 34)
            g.drawImage(line_1, x - 8, actual_y, 0);

        rest = initial_y - actual_y;

        if (rest > 0)
            g.drawRegion(line_1, 0, 0, 15, rest, Sprite.TRANS_NONE, x - 8, actual_y, 0);

    }

    public boolean must_be_removed()
    {
        return has_to_die;
    }
}
