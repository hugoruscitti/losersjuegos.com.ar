/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import java.io.*;

public class SimpleSprite
{
    public Sprite sprite;
    Image image;
    int to_x;
    int to_y;
    float x;
    float y;

    public SimpleSprite(String path, int x, int y, int to_x, int to_y)
    {
        this.to_x = to_x;
        this.to_y = to_y;
        this.x = x;
        this.y = y;

        try
        {
            image = Image.createImage(path);
        }
        catch (IOException e)
        {
            System.err.println("Can't load: " + path);
        }

        sprite = new Sprite(image, image.getWidth(), image.getHeight());
        sprite.setVisible(true);
    }

    public void update()
    {
        x += (to_x - x) / 6.0;
        y += (to_y - y) / 6.0;
        sprite.setPosition((int) x, (int) y);
    }
}
