/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import java.io.*;

public class Cursor
{
    public Sprite sprite;
    Image image;
    int x = 24;
    int yOffset = 157 + 13;
    float y = 341;
    public int index = 0;
    int max = 5;
    int height = 22;
    int to_y = yOffset;
    boolean key_pressed = false;
    boolean starting = true;

    public Cursor(int initialIndex)
    {
        image = load_image();
        to_y = yOffset + initialIndex * height;

        index = initialIndex;
        sprite = new Sprite(image, 197, 24);
        sprite.setVisible(true);
    }

    private Image load_image()
    {
        Image image2 = null;

        try {
            image2 = Image.createImage("/data/cursor.png");
        } catch (IOException e) {
            System.err.println("Can't load 'ceferino.png' image");
        }

        return image2;
    }

    public void input(int key)
    {
        if (starting)
            return;
        
        if (key_pressed)
        {
            if ((key & GameCanvas.DOWN_PRESSED) == 0 && 
                    (key & GameCanvas.UP_PRESSED) == 0)
            {
                key_pressed = false;
            }

            return;
        }
        else
        {
            if ((key & GameCanvas.DOWN_PRESSED) != 0)
            {
                key_pressed = true;
                index ++;

                if (index >= max)
                    index = 0;

                to_y = yOffset + index * height;
            }
            else
            {
                if ((key & GameCanvas.UP_PRESSED) != 0)
                {
                    key_pressed = true;
                    index --;

                    if (index < 0)
                        index = max - 1;

                    to_y = yOffset + index * height;
                }
            }
        }
    }

    public void update()
    {
        if (starting)
        {
            y += (to_y - y) / 6.0;
            
            if (Math.abs(y - to_y) < 2)
                starting = false;
        }
        else
            y = to_y;

        sprite.setPosition(x, (int) y);
    }

}
