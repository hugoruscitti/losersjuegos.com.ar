/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.Graphics;

public class GameStateBonusTime extends GameState
{
    public GameScene game = null;
    SimpleText message = null;
    int time_out = 50;
    double time_counter = 0;

    public GameStateBonusTime(GameScene game) {
        this.game = game;
        message = new SimpleText("3", -200, 100, 120, 100);
        game.ceferino.do_check_collisions = false;
    }

    void input(int keyStates)
    {
        double seconds_bonus;
        message.update();
        time_counter += 0.5;
        seconds_bonus = (60 - time_counter) /  10.0;
        message.set_text(String.valueOf((int)seconds_bonus));
        
        game.update_objects(keyStates);
        game.update_ceferino(keyStates);
        // si termina de contar pasa al siguiente estado.
        if (time_counter > time_out)
            game.change_state(new GameStatePlaying(game));
    }

    void render(Graphics g)
    {
        game.render_all_objects(g);
        message.draw(g);
    }
    
    void add_pause()
    {
        time_counter += 50;
    }
}
