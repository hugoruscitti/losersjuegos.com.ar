/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import java.io.*;
import java.util.*;

public class GameScene extends Scene
{
    public int level_index;
    public int lives;
    public LayerManager layers;
    public Image background;
    public Ceferino ceferino;
    public Vector balls;
    public Vector player_shots;
    public Vector break_tiles;
    public Vector bonus_items;
    public Vector lives_collection;
    public Player sound_ball_destroy = null;
    public Player sound_break_tile_destroy = null;
    public Level level = null;
    public World world = null;
    public GameState state = null;
    Image live_image = null;
    
    Player sound_fire = null;
    Player sound_die = null;
    
    
    public GameScene(World world, int level_index, int ceferino_fire_type, int ceferino_fire_counter_max, int lives)
    {
        this.world = world;
        this.lives = lives;
        this.level_index = level_index;
        load_live_images();
        ceferino = new Ceferino(this, ceferino_fire_type, ceferino_fire_counter_max);
        create_background();
        load_sounds();
        change_state(new GameStateStarting(this));
    }

    public void load_live_images()
    {
        try {
            live_image = Image.createImage("/data/live.png");
        } catch (IOException e) {
            System.err.println("Can't load 'live.png' image");
        }
    }
    
    public void create_game_objects()
    {
        layers = new LayerManager();
        balls = new Vector();
        player_shots = new Vector();
        break_tiles = new Vector();
        bonus_items = new Vector();
        lives_collection = new Vector();

        for (int i=0; i < lives; i++)
            create_live(i);
        
        level = new Level(world, this, this.level_index);
       
        ceferino.change_state(new CaferinoStateStand(ceferino));
        ceferino.set_initial_position();
        layers.append(ceferino.getSprite());
    }
    
    public void remove_all_objects()
    {
        layers = new LayerManager();
        balls = new Vector();
        player_shots = new Vector();
        break_tiles = new Vector();
        bonus_items = new Vector();
        lives_collection = new Vector();
        System.gc();  
    }
    
    public void change_state(GameState state) 
    {
        this.state = state;
    }

    public void create_ball(int x, int y, int size, int direction, boolean delay)
    {
        Ball ball;
        ball = new Ball(this, x, y, size, direction, delay);
        layers.append(ball.getSprite());
        balls.addElement(ball);
    }

    public void create_live(int index)
    {
        Sprite sprite;
        sprite = new Sprite(this.live_image);
        sprite.setPosition(2 + 15 * index, 320 - 13);
        layers.append(sprite);
        lives_collection.addElement(sprite);
    }

    public void create_break_tile(int x, int y)
    {
        BreakTile break_tile;
        break_tile = new BreakTile(this, x, y);
        layers.append(break_tile.getSprite());
        break_tiles.addElement(break_tile);
    }
    
    public void create_bonus_item(int x, int y)
    {
        BonusItem item;
        item = new BonusItem(this, x, y);

        layers.append(item.getSprite());
        bonus_items.addElement(item);
    }

    public void update_balls()
    {
        int i;
        for (i = 0; i < balls.size(); i++) {
            Ball ball = (Ball) balls.elementAt(i);
            ball.update();
        }
     }
    
    private void load_sounds()
    {
        sound_ball_destroy = load_sound("destroy.wav");
        sound_break_tile_destroy = load_sound("break.wav");
        sound_fire = load_sound("fire.wav");
        sound_die = load_sound("die.wav");
    }

    public Player load_sound(String file)
    {
        Player tmp = null;

        try
        {
            InputStream is = getClass().getResourceAsStream("/data/sounds/" + file);
            tmp = Manager.createPlayer(is, "audio/X-wav");
        }
        catch (IOException ex)
        {
            System.err.println("IOException, can't load: " + file);
        }
        catch (MediaException me)
        {
            System.err.println("MediaException, can't load: " + file);
        }
        catch (IllegalArgumentException ia)
        {
            System.err.println("IllegalArgumentException in file: " + file);
        }

        return tmp;
    }

    public void input(int keyStates)
    {
        state.input(keyStates);
    }
    
    public void update_ceferino(int keyStates) {
         ceferino.update(keyStates);
    }
    
    // Actualiza los objetos Ball y Shot
    public void update_objects(int keyStates)
    {
        int i;
        
        for (i=0; i<player_shots.size(); i++)
        {
            PlayerShot fire = (PlayerShot) player_shots.elementAt(i);
            fire.update();
        }

        for (i=0; i<bonus_items.size(); i++)
        {
            BonusItem bonus = (BonusItem) bonus_items.elementAt(i);
            bonus.update();
        }
        
        
        // elimina los objetos con marcade remover.
        clear_object_vectors();
    }

    // Elimina todos los objetos con marca de remover.
    public void clear_object_vectors()
    {
        int i;

        for (i=0; i<balls.size(); i++)
        {
            Ball ball = (Ball) balls.elementAt(i);

            if (ball.must_be_removed())
            {
                balls.removeElement(ball);
                layers.remove(ball.getSprite());
            }
        }

        for (i=0; i<player_shots.size(); i++)
        {
            PlayerShot fire = (PlayerShot) player_shots.elementAt(i);
            
            if (fire.must_be_removed())
            {
                player_shots.removeElement(fire);
                layers.remove(fire.getSprite());
            }
        }
        
        for (i=0; i<break_tiles.size(); i++)
        {
            BreakTile bt = (BreakTile) break_tiles.elementAt(i);
            
            if (bt.must_be_removed())
            {
                create_bonus_item(bt.x, bt.y);
                break_tiles.removeElement(bt);
                layers.remove(bt.getSprite());
            }
        }
        
        
         for (i=0; i<bonus_items.size(); i++)
        {
            BonusItem bi = (BonusItem) bonus_items.elementAt(i);
            
            if (bi.must_be_removed())
            {
                bonus_items.removeElement(bi);
                layers.remove(bi.getSprite());
            }
        }
    }

    private void create_background()
    {
        try {
            background = Image.createImage("/data/background.png");
        } catch (IOException e) {
            System.err.println("Can't load 'background.png' image");
        }
    }

    public int get_player_shots_size()
    {
        return player_shots.size();
    }

    public void create_fire_normal(int x, int y)
    {
        PlayerShot fire = new PlayerShot(this, x, y);
        layers.insert(fire.getSprite(), 1);
        player_shots.addElement(fire);
    }

    public void create_fire_trident(int x, int y)
    {
        PlayerShotTrident fire = new PlayerShotTrident(this, x, y);
        layers.insert(fire.getSprite(), 1);
        player_shots.addElement(fire);
    }
    
    
    public void remove_playershot(PlayerShot to_remove)
    {
        player_shots.removeElement(to_remove);
    }
    
    public void render(Graphics g)
    {
        g.drawImage(background, 0, 0, 0);
        state.render(g);
    }
    
    public void render_all_objects(Graphics g)
    {
        int i;
        
        level.draw(g);
        layers.paint(g, 0, 0);

        for (i=0; i<player_shots.size(); i++)
        {
            PlayerShot fire = (PlayerShot) player_shots.elementAt(i);
            fire.drawline(g);
        }
    }
   

    /*
     * Utilizado por PlayerShot para determinar si hay algún objeto Ball
     * dentro del rango delimitado por (x, [initial_y, y + initial_y]).
     */
    public Ball get_ball_that_can_kill(int x, int y, int initial_y)
    {
        int i;

        for (i=0; i<balls.size(); i++)
        {
            Ball ball = (Ball) balls.elementAt(i);

            if (ball.are_in_this_area(x, initial_y, y) && ball.can_kill)
            {
                ball.do_kill();
                play_sound_ball_destroy();
                    
                return ball;
            }
        }

        return null;
    }

    boolean level_are_done()
    {
        return (balls.size() <= 0);
    }


    public BreakTile get_break_tile_that_can_kill(int x, int y, int initial_y)
    {
        int i;

        for (i=0; i<break_tiles.size(); i++)
        {
            BreakTile bt = (BreakTile) break_tiles.elementAt(i);

            if (bt.are_in_this_area(x, initial_y, y))
            {
                bt.destroy();
                play_sound_break_tile_destroy();

                return bt;
            }
        }

        return null;
    }

    public boolean get_break_tile_in(int x, float y)
    {
        int i;

        for (i=0; i<break_tiles.size(); i++)
        {
            BreakTile bt = (BreakTile) break_tiles.elementAt(i);
            
            if (bt.are_in(x, (int)y))
                return true;
        }

        return false;
    }    
    
    public void play_sound_ball_destroy()
    {
        try
        {
            if (world.are_soundEnabled())
                sound_ball_destroy.start();
        }
        catch (MediaException me)
        {
            System.err.println("Can't play this sound");
        }
    }

    public void play_sound_break_tile_destroy()
    {
        try
        {
            if (world.are_soundEnabled())
                sound_break_tile_destroy.start();
        }
        catch (MediaException me)
        {
            System.err.println("Can't play this sound");
        }
    }
    
    
    public Ball get_ball_in_collision_with(Ceferino ceferino)
    {
        int i;

        for (i=0; i<balls.size(); i++)
        {
            Ball ball = (Ball) balls.elementAt(i);
            
            if (ceferino.sprite.collidesWith(ball.sprite, true))
                return ball;
        }
        return null;
    }

    public BonusItem get_bonus_item_in_collision_with(Ceferino ceferino)
    {
        int i;

        for (i=0; i<bonus_items.size(); i++)
        {
            BonusItem item = (BonusItem) bonus_items.elementAt(i);
            
            if (ceferino.sprite.collidesWith(item.sprite, true))
                return item;
        }
        return null;
    }    
    
    public float get_dist_to_floor(int x, int y, float dy)
    {
        return this.level.get_dist_to_floor(x, y, dy);
    }
    
    public float get_dist_to_ceiling(int x, int y, float dy)
    {
        return this.level.get_dist_to_ceiling(x, y, dy);
    }
    
    public void go_to_next_stage()
    {

        if (this.level_index < 10)
            world.change_scene_inmediately(new NextLevelScene(world, this.level_index + 1, ceferino.fire_type, ceferino.fire_counter_max, lives));
        else
            world.change_scene_inmediately(new ShowFinalScene(world));
    }
    
    public void add_pause()
    {
        state.add_pause();
    }


 
    public void play_sound_die()
    {
        try
        {
            if (world.are_soundEnabled())
                sound_die.start();
        }
        catch (MediaException me)
        {
            System.err.println("Can't play this sound");
        }
    }

    public void play_sound_fire()
    {
        try
        {
            if (world.are_soundEnabled())
                sound_fire.start();
        }
        catch (MediaException me)
        {
            System.err.println("Can't play this sound");
        }
    }

    void removeOneLive()
    {
        lives -= 1;
    }

    boolean hasLives()
    {
        return lives >= 0;
    }

}
