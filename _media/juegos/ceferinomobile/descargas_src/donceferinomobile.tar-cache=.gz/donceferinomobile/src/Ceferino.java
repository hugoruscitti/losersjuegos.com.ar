/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import java.io.*;

public class Ceferino
{
    public Sprite sprite;
    private CeferinoState state;
    int x;
    int y;
    int flip = 0;
    int control_point_x = 30;
    int control_point_y = 60;
    public int fire_counter_max;
    public int fire_type;
    boolean initial_can_shot = false;
    public boolean do_check_collisions = true;

    
    GameScene game = null;

    public Ceferino(GameScene game, int fire_type, int fire_counter_max)
    {
        Image image;
        image = load_image();


        this.fire_type = fire_type;
        this.fire_counter_max = fire_counter_max;
        sprite = new Sprite(image, 66, 67);
        sprite.setVisible(true);
        this.game = game;
        set_initial_position();
        update_position();
    }

    public void set_initial_position(){
        x = 120;
        y = 294;
    }
    public boolean can_shot()
    {
        if (initial_can_shot)
        {
            if (fire_counter_max > game.get_player_shots_size())
                return true;
        }
        else
        {
            return false;
        }
        
        return false;
    }
    
    // Inicialmente el personaje no puede disparar. Este metodo
    // le permite comenzar a disparar (asociado al cambio de estado
    // de GameScene, de Starting a Playing.)
    public void set_initial_can_shot()
    {
        initial_can_shot = true;
    }

    public void shot()
    {
        int dx = 5;

        if (flip == 1)
            dx *= -1;

        game.play_sound_fire();

        
        if (fire_type == 0)
            game.create_fire_normal(x + dx, y);
        else
            game.create_fire_trident(x + dx, y);
    }

    private Image load_image()
    {
        Image image = null;

        try {
            image = Image.createImage("/data/ceferino.png");
        } catch (IOException e) {
            System.err.println("Can't load 'ceferino.png' image");
        }

        return image;
    }





    public void change_state(CeferinoState new_state)
    {
        state = new_state;
    }

    public Sprite getSprite()
    {
        return sprite;
    }

    public void update(int keys)
    {
        int speed = 4;

        state.update(keys);
        sprite.nextFrame();
        update_flip();
        update_position();
        check_collisions();
        
        if (do_check_collisions)
            check_collisions_with_balls();
    }

    public void check_collisions_with_balls(){
        Ball ball = game.get_ball_in_collision_with(this);

        if (ball != null)
            change_state(new CeferinoStateDie(this));
    }
    
    public void check_collisions()
    {   
        BonusItem item = game.get_bonus_item_in_collision_with(this);
        
        if (item != null)
        {

            int bonus_type = item.type;
            
            switch (bonus_type)
            {
                case 0:
                    fire_counter_max += 1;
                    break;
                    
                case 1:
                    game.add_pause();
                    break;
                   
                case 2:
                    if (fire_type == 1)
                        fire_counter_max += 1;
                    else
                        fire_type = 1;
                    break;
            }
            
            item.destroy();
        }
    }


    private void update_flip()
    {
        if (flip == 1)
            sprite.setTransform(Sprite.TRANS_MIRROR);
        else
            sprite.setTransform(Sprite.TRANS_NONE);
    }

    private void update_position()
    {
        sprite.setPosition(x - control_point_x, y - control_point_y);
    }

    public void set_animation(int [] sec)
    {
        sprite.setFrameSequence(sec);
    }

    public void move(int dx, int dyy)
    {
        x += dx;

        if (x > 230)
            x = 230;
        else
            if (x < 5)
                x = 5;
    }
    
    public void setFlip(boolean state)
    {
        if (state)
            flip = 1;
        else
            flip = 0;
    }

    public boolean getFlip()
    {
        if (flip == 1)
            return true;
        else
            return false;
    }

}
