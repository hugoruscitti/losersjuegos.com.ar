/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import java.io.*;
import java.util.Random;

public class BonusItem
{
    public Sprite sprite;
    public boolean can_kill = true;
    public int x;
    public int y;
    public int type;
    boolean has_to_die = false;
    Player sound_item = null;
    float speed;
    
    GameScene game = null;

    public BonusItem(GameScene game, int x, int y)
    {
        Image image;
        Random generator = new Random();
        
        this.speed = -3;
        this.game = game;
        this.x = x;
        this.y = y;
        this.type = generator.nextInt(3);
        image = load_image(type);

        sprite = new Sprite(image, image.getHeight(), image.getHeight());
        sprite.setVisible(true);
        load_sound();
        update();
    }

    private void load_sound(){
        try
        {
            InputStream is3 = getClass().getResourceAsStream("/data/sounds/item.wav");
            sound_item = Manager.createPlayer(is3, "audio/X-wav");
        }
        catch (IOException ioe)
        {
            System.err.println("Can't load sound");
        }
        catch (MediaException me)
        {
            System.err.println("Can't load sound");
        }
    }
    
    private Image load_image(int type)
    {
        Image image = null;

        try {
            image = Image.createImage("/data/item_" + String.valueOf(type) + ".png");
        } catch (IOException e) {
            System.err.println("Can't load 'item_shot.png'");
        }

        return image;
    }


    public Sprite getSprite()
    {
        return sprite;
    }

    public void update()
    {
        speed += 0.4;
        y += (int) speed;

        if (y + 24 > 296)
            y = 296 - 24;
        
        sprite.setPosition(x, y);
    }


    // Metodo utilizado para veficar colisiones con el disparo.
    public boolean are_in_this_area(int x, int initial_y, int y)
    {
        if (x < this.x + 16 && x > this.x)
        {
            if (this.y - 8 > y && this.y + 8 < initial_y && ! has_to_die)
                return true;
        }
        
        return false;
    }
    
    public boolean are_in(int x, int y) {
        if (this.x < x && x < this.x + 16)
        {
            if (this.y < y && y < this.y + 16 && ! has_to_die)
            {
                return true;
            }
        }
        
        return false;
    }

    public void destroy()
    {
        play_sound();
        has_to_die = true;
    }

    public boolean must_be_removed()
    {
        return has_to_die;
    }
    
    public void play_sound()
    {
        try
        {
            if (game.world.are_soundEnabled())
                sound_item.start();
        }
        catch (MediaException me)
        {
            System.err.println("Can't play this sound");
        }
    }    

}
