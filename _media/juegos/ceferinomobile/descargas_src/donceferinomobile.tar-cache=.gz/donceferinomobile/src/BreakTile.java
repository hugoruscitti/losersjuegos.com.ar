/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import java.io.*;

public class BreakTile
{
    public Sprite sprite;
    public boolean can_kill = true;
    public int x;
    public int y;
    boolean has_to_die = false;
    GameScene game = null;

    public BreakTile(GameScene game, int x, int y)
    {
        Image image;
        this.game = game;
        this.x = x;
        this.y = y;
        image = load_image();

        sprite = new Sprite(image, image.getHeight(), image.getHeight());
        sprite.setVisible(true);
        update();
    }

    private Image load_image()
    {
        Image image = null;

        try {
            image = Image.createImage("/data/break_tile.png");
        } catch (IOException e) {
            System.err.println("Can't load 'break_tile.png'");
        }

        return image;
    }


    public Sprite getSprite()
    {
        return sprite;
    }

    public void update()
    {
        sprite.setPosition(x, y);
    }


    // Metodo utilizado para veficar colisiones con el disparo.
    public boolean are_in_this_area(int x, int initial_y, int y)
    {
        if (x < this.x + 16 && x >= this.x - 1)
        {
            if (this.y - 8 > y && this.y + 8 < initial_y && ! has_to_die)
                return true;
        }
        
        return false;
    }
    
    public boolean are_in(int x, int y) {
        if (this.x < x && x < this.x + 16)
        {
            if (this.y < y && y < this.y + 16 && ! has_to_die)
            {
                return true;
            }
        }
        
        return false;
    }

    public void destroy()
    {
        has_to_die = true;
    }

    public boolean must_be_removed()
    {
        return has_to_die;
    }
    

}

