/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import java.io.*;
import java.util.*;

public class SceneEnableAudio extends Scene
{
    Image background;
    World world = null;
    Sprite cursor;
    int lastKeyState = 0;

    public SceneEnableAudio(World world)
    {
        this.world = world;
        create_background();
        create_cursor();
    }

    public void input(int key)
    {
        if (key != lastKeyState)
        {
            if ((key & GameCanvas.FIRE_PRESSED) != 0)
            {
                if (cursor.getY() == 163)
                    world.set_enable_sound(true);
                else
                    world.set_enable_sound(false);

                world.change_scene(new SceneIntro(world));
            }

            if ((key & GameCanvas.DOWN_PRESSED) != 0)
                move_cursor();

            if ((key & GameCanvas.UP_PRESSED) != 0)
                move_cursor();
        }

        lastKeyState = key;
    }

    private void create_background()
    {
        try
        {
            background = Image.createImage("/data/audio/bg.png");
        }
        catch (IOException e)
        {
            System.err.println("Can't load 'bg.png'");
        }
    }

    void create_cursor()
    {
        Image tmp = null;

        try
        {
            tmp = Image.createImage("/data/audio/cursor.png");
        }
        catch (IOException ex)
        {
            System.err.println("Can't create cursor");
        }

        cursor = new Sprite(tmp);
        cursor.setPosition(0, 163);

    }

    void move_cursor()
    {
        if (cursor.getY() == 163)
            cursor.setPosition(0, 163 + 20);
        else
            cursor.setPosition(0, 163);
    }

    public void render(Graphics g)
    {
        g.drawImage(background, 0, 0, 0);
        cursor.paint(g);
    }
}
