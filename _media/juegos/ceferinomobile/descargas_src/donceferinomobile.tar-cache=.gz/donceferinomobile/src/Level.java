/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.*;
import java.io.DataInputStream;
import java.io.InputStream;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.TiledLayer;
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import java.io.*;

public class Level
{
    TiledLayer tile;
    Image image;
    GameScene game;
    byte[][] collisionmap = {
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
        };

    public Level(World world, GameScene game, int index)
    {
        String level_number;
        
        this.game = game;
        // Intenta cargar la imagen de tiles.
        try {
            image = Image.createImage("/data/tiles.png");
        } catch (IOException e) {
            System.err.println("Can't load 'tiles.png' image");
        }
        
        if (index < 10)
            level_number = "0" + String.valueOf(index);
        else
            level_number = String.valueOf(index);


        tile = this.getMap("/data/stages/level" + level_number + ".smp", image);
    }


    void draw(Graphics g)
    {
        tile.paint(g);
    }


    public TiledLayer getMap(String fpath, Image ftiles)
    {
        TiledLayer tMap = null;
        try {
            // open the file
            InputStream is = this.getClass().getResourceAsStream(fpath);
            DataInputStream ds = new DataInputStream(is);
            try {
                // skip the descriptor
                ds.skipBytes(8);

                // read map width
                int mW = ds.readByte();

                // read map height
                int mH = ds.readByte();

                // read tile width
                int tW = ds.readByte();

                // read tile height
                int tH = ds.readByte();

                // create a new tiled layer
                tMap = new TiledLayer(mW, mH, ftiles, tW, tH);

                // loop through the map data
                for (int row_counter = 0; row_counter < mH; row_counter++){
                  for (int column_counter = 0; column_counter < mW; column_counter++){
                    // read a tile index 
                    byte index = ds.readByte();

                    // if tile index is non-zero
                    // tile index 0 is usually a blank tile
                    if (index > 0) {
                        // assign (tile index + 1) to the current cell
                        // TiledLayer objects start tile index at 1
                        // instead of 0
                        if (index < 19)
                            tMap.setCell(column_counter, row_counter, index + 1);
                        
                        

                        
                        
                        switch (index)
                            {
                            // suelos
                            case 4:
                            case 5:
                            case 6:
                            case 10:
                            case 11:
                            case 12:
                            case 13:
                            case 14:
                            case 15:
                                collisionmap[row_counter][column_counter] = 1;
                                break;
                                
                            case 19:
                                this.game.create_ball(column_counter *16, row_counter * 16, 1, -1, true);
                                break;
                                
                            case 20:
                                this.game.create_ball(column_counter *16, row_counter * 16, 2, -1, true);
                                break;

                             case 21:
                                this.game.create_ball(column_counter *16, row_counter * 16, 3, -1, true);
                                break;
                                
                            case 22:
                                this.game.create_ball(column_counter *16, row_counter * 16, 4, -1, true);
                                break;      
                                
                            case 23:
                                this.game.create_ball(column_counter *16, row_counter * 16, 1, 1, true);
                                break;
                                
                            case 24:
                                this.game.create_ball(column_counter *16, row_counter * 16, 2, 1, true);
                                break;

                             case 25:
                                this.game.create_ball(column_counter *16, row_counter * 16, 3, 1, true);
                                break;
                                
                            case 26:
                                this.game.create_ball(column_counter *16, row_counter * 16, 4, 1, true);
                                break;                                                
                           
                                
                           //bloque que se puede romper
                           case 27:
                                this.game.create_break_tile(column_counter *16, row_counter * 16);
                                break;       
                            }

                    }
                  }  
                }

           } catch (Exception ex) {
               tMap = null;
               System.err.println("map loading error : " + ex.getMessage());
           }
           // close the file
           ds.close();
           ds = null;
           is = null;
        } catch (Exception ex) {
            tMap = null;
            System.err.println("map loading error : " + ex.getMessage());
        }

        // return the newly created map or null if loading failed
        return tMap;
    }
    
    public boolean get_collision_at(int x, int y){
        int col = x / 16;
        int row = y / 16;     
        
        if (col > 14)
            col = 14;
        else
        {
            if (col < 0)
                col = 0;
        }               
        
        if (row < 0)
            row = 0;
        if (row > 19)
            row = 19;
        
        
        return (collisionmap[row][col] == 1);
    }
    
    public float get_dist_to_floor(int x, int y, float dy)
    {
        int col = (x-1) / 16;
        int row;

        float step = 0;

        for (step=0f; step <= dy; step += 0.1f)
        {
            row = (int) (y + step) / 16;

            boolean collision_with_break_tile = game.get_break_tile_in(x, (int) y + step);

            try
            {
                if (collisionmap[row][col] == 1 || collision_with_break_tile)
                    return step;
            }
            catch (ArrayIndexOutOfBoundsException ex)
            {
                return step;
            }
        }

        return dy;
    }
    
    public float get_dist_to_ceiling(int x, int y, float dy)
    {
        int col = (x-1) / 16;
        int row;
        float step = 0;

        for (step=0f; step <= -dy; step += 0.1f)
        {
            row = (int) (y - step) / 16;
            boolean collision_with_break_tile = game.get_break_tile_in(x, (int) y + step);

            try
            {
                if (collisionmap[row][col] == 1 || collision_with_break_tile)
                    return step;
            }
            catch (ArrayIndexOutOfBoundsException ex)
            {
                return step;
            }
        }
        
        return dy;
    }
}
