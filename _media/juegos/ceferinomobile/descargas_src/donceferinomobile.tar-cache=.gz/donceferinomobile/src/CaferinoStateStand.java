/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.game.*;

public class CaferinoStateStand extends CeferinoState
{
    Ceferino ceferino = null;
    int speed = 4;

    public CaferinoStateStand(Ceferino ceferino)
    {
        int [] sec = {0};
        this.ceferino = ceferino;
        this.ceferino.set_animation(sec);
    }

    public void update(int key)
    {
        if ((key & GameCanvas.LEFT_PRESSED) != 0)
        {
            CeferinoState state = new CeferinoStateWalk(ceferino, -speed);
            ceferino.change_state(state);
            ceferino.setFlip(true);
        }
        

        if ((key & GameCanvas.RIGHT_PRESSED) != 0)
        {
            CeferinoState state = new CeferinoStateWalk(ceferino, speed);
            ceferino.change_state(state);
            ceferino.setFlip(false);
        }

        if ((key & GameCanvas.DOWN_PRESSED) != 0)
        {
            int new_speed = speed * 3;

            if (ceferino.getFlip())
                new_speed *= -1;

            ceferino.change_state(new CeferinoStateRun(ceferino, new_speed));
        }

        if ((key & GameCanvas.UP_PRESSED) != 0)
        {
            if (ceferino.can_shot())
                ceferino.change_state(new CeferinoStateShot(ceferino));
        }

        if ((key & GameCanvas.FIRE_PRESSED) != 0)
        {
            if (ceferino.can_shot())
                ceferino.change_state(new CeferinoStateShot(ceferino));
        }
    }
}
