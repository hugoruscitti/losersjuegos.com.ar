/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

import java.io.IOException;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.GameCanvas;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hugoruscitti
 */
public class GameOverScene extends Scene
{
    Image background;
    World world = null;

    public GameOverScene(World world)
    {
        this.world = world;
        create_background();
    }

    public void input(int key)
    {
        if ((key & GameCanvas.FIRE_PRESSED) != 0) {
            SceneMenu menu = new SceneMenu(world, 0);
            world.change_scene(menu);
        }
    }

    private void create_background()
    {
        try {
            background = Image.createImage("/data/gameover.jpg");
        } catch (IOException e) {
            System.err.println("Can't load 'gameover.jpg'");
        }
    }

    public void render(Graphics g)
    {
        g.drawImage(background, 0, 0, 0);
    }
}
