/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import java.io.*;

public class SceneHistory extends Scene
{
    Image background;
    World world = null;
    int step;

    public SceneHistory(World world, int step)
    {
        this.world = world;
        this.step = step;
        create_background_from_step();
    }

    public void input(int key)
    {
        if ((key & GameCanvas.FIRE_PRESSED) != 0)
        {
            Scene newScene = null;

            if (step < 5)
                newScene = new SceneHistory(world, step + 1);
            else
                newScene = new SceneMenu(world, 2);
            
            world.change_scene(newScene);
        }
    }

    private void create_background_from_step()
    {
        try {
            background = Image.createImage("/data/history/h" + this.step + ".jpg");
        } catch (IOException e) {
            System.err.println("Can't load history image'");
        }
    }

    public void render(Graphics g)
    {
        g.drawImage(background, 0, 0, 0);
    }
}
