/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.midlet.*;

public class DonCeferinoMobile extends MIDlet  implements CommandListener
{
    Command exit;
    Display display;
    World world;

    

    public void startApp()
    {
        if (world == null)
        {
            world = new World(this);
            world.setCommandListener(this);

            display = Display.getDisplay(this);
            display.setCurrent(world);
            world.start();

        }

    }

    public void pauseApp()
    {
    }

    public void destroyApp(boolean incondicional)
    {
    }

    public void commandAction(Command c, Displayable s)
    {
        if (c == exit)
        {
            destroyApp(false);
            notifyDestroyed();
        }
    }
}
