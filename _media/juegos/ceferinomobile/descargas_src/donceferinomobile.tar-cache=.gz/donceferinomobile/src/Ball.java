/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import java.io.*;

public class Ball
{
    public Sprite sprite;
    public boolean can_kill = true;
    int x;
    int y;
    int direction;
    int size;
    float dy;
    int radio;
    boolean has_to_die = false;
    GameScene game = null;
    BallState state = null;

    public Ball(GameScene game, int x, int y, int size, int direction, boolean delay)
    {
        Image image;
        this.game = game;
        this.size = size;
        this.direction = direction;
        this.x = x;
        this.y = y;
        image = load_image();

        sprite = new Sprite(image, image.getHeight(), image.getHeight());
        radio = image.getHeight() / 2;
        sprite.setVisible(true);
        dy = 0;

        if (delay)
            change_state(new BallStateStarting(this, direction));
        else
            change_state(new BallStateNormal(this));

        update();

    }

    private Image load_image()
    {
        Image image = null;

        try {
            image = Image.createImage("/data/ball_" + size + ".png");
        } catch (IOException e) {
            System.err.println("Can't load 'ball_" + size + ".png'");
        }

        return image;
    }

    public void change_state(BallState new_state)
    {
        state = new_state;
    }

    public Sprite getSprite()
    {
        return sprite;
    }

    public void update()
    {
        state.update();
        sprite.setPosition(x - radio, y - radio);
        sprite.nextFrame();
    }

    public boolean update_bouncing_movement()
    {
        boolean collision_before_move;
        boolean collision_after_move;
        
        dy += 0.095;
        x += direction;
        


        check_wall_collision();
        
        collision_before_move = game.level.get_collision_at(x - direction, y);
        collision_after_move = game.level.get_collision_at(x, y);
        
        if (!collision_before_move && collision_after_move)
        {
            direction *= -1;
            x += direction * 2;
        }
        
        return check_flood_collision_and_move();
    }

    private void check_wall_collision()
    {
        if (x > 240)
        {
            x = 240;
            direction = -1;
        }
        else
        {
            if (x < 0)
            {
                x = 0;
                direction = 1;
            }
        }
    }

    private boolean check_flood_collision_and_move()
    {
        int flood = 300;

        if (y + dy + radio > flood)
        {
            y = flood - radio;
            dy = -4;
            return true;
        }
        else
        {
            // si esta bajando.
            if (dy > 0)
            {
                float tmp_dy = dy;
            
                dy = game.get_dist_to_floor(x, y + radio - radio / 4, dy);

                
                if (tmp_dy > dy)
                {
                    y += dy;
                    dy = -4;
                    return true;
                }
            }
            // si esta subiendo.
            else
            {
                float tmp_dy = dy;
            
                dy = game.get_dist_to_ceiling(x, y - radio + radio / 4, dy);
                
                if (tmp_dy < dy)
                {
                    dy = 4;
                    return true;
                }
            }
            

        }

        y += dy;
        return false;
    }

    // Metodo utilizado para veficar colisiones con el disparo.
    public boolean are_in_this_area(int x, int initial_y, int y)
    {
        if (x < this.x + radio && x > this.x - radio)
        {
            if (this.y - radio > y && this.y + radio < initial_y)
                return true;
        }
        
        return false;
    }

    public void destroy()
    {
        has_to_die = true;
    }

    public void do_kill()
    {
        can_kill = false;

        if (size > 1)
        {
            game.create_ball(x - 10, y, size -1, -1, false);
            game.create_ball(x + 10, y, size -1, +1, false);
        }

        change_state(new BallStateDestroy(this));
    }

    public boolean must_be_removed()
    {
        return has_to_die;
    }

    public void set_animation(int [] sec)
    {
        sprite.setFrameSequence(sec);
    }
}
