/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import java.io.*;

public class SceneIntro extends Scene
{
    World world;
    LayerManager layers;
    Image background;
    SimpleSprite ceferino;
    SimpleSprite losers;
    SimpleSprite juegos;
    int delay = 50;

    public SceneIntro(World world)
    {
        this.world = world;
        layers = new LayerManager();
        load_images();
        create_objects();
    }

    public void load_images()
    {
        try
        {
            background = Image.createImage("/data/intro_bg.png");
        } 
        catch (IOException e)
        {
            System.err.println("Can't load 'intro_bg.png'");
        }
    }

    public void create_objects()
    {
        ceferino = new SimpleSprite("/data/titles/intro_ceferino.png", -100, 120, 11, 120);
        losers = new SimpleSprite("/data/titles/intro_losers.png", 100, -60, 100, 100);
        juegos = new SimpleSprite("/data/titles/intro_juegos.png", 100, 320, 100, 161);

        layers.append(ceferino.sprite);
        layers.append(losers.sprite);
        layers.append(juegos.sprite);
    }

    public void render(Graphics g)
    {
        int i;

        g.drawImage(background, 0, 0, 0);
        layers.paint(g, 0, 0);
    }
    

    public void input(int key)
    {
        
        if (delay < 0 || (key & GameCanvas.FIRE_PRESSED) != 0)
        {
            SceneMenu menu = new SceneMenu(this.world, 0);
            world.change_scene(menu);
        }

        ceferino.update();
        losers.update();
        juegos.update();

        delay --;
    }
}
