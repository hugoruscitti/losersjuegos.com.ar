/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.media.*;
import java.io.*;
import java.util.*;

public class SceneMenu extends Scene
{
    LayerManager layers;
    Image background;
    Player sound_ball_destroy = null;
    World world = null;
    Vector sprites = new Vector();
    Cursor cursor;

    public SceneMenu(World world, int optionIndex)
    {
        this.world = world;
        cursor = new Cursor(optionIndex);
        layers = new LayerManager();

        create_background();
        load_sounds();
        
        layers.append(cursor.sprite);
        create_sprites(); 
    }

    private void load_sounds()
    {
        try
        {
            InputStream is = getClass().getResourceAsStream("/data/sounds/destroy.wav");
            sound_ball_destroy = Manager.createPlayer(is, "audio/X-wav");
        }
        catch (IOException ioe)
        {
            System.err.println("Can't load sound");
        }
        catch (MediaException me)
        {
            System.err.println("Can't load sound");
        }
    }

    public void input(int key)
    {
        if ((key & GameCanvas.FIRE_PRESSED) != 0)
        {

            switch (cursor.index)
            {
                case 0:
                    world.change_scene(new GameScene(this.world, 1, 0, 1, 4));
                    break;

                case 1:
                    world.change_scene(new SceneHowToPlay(world));
                    break;

                case 2:
                    world.change_scene(new SceneHistory(world, 1));
                    break;

                case 3:
                    world.change_scene(new SceneAbout(world));
                    break;

                case 4:
                    world.close();
                    break;

                default:
                    break;
            }
        }

        for (int i=0; i < sprites.size(); i ++)
        {
            SimpleSprite s = (SimpleSprite) sprites.elementAt(i);
            s.update();
        }

        cursor.input(key);
        cursor.update();
    }

    private void create_background()
    {
        try {
            background = Image.createImage("/data/menu/background.jpg");
        } catch (IOException e) {
            System.err.println("Can't load 'menu_background.jpg'");
        }
    }

    private void create_sprites()
    {
        add_sprite(new SimpleSprite("/data/menu/menu_bg1.png", 4, -110, 4, 5));
        add_sprite(new SimpleSprite("/data/titles/menu_t1.png", -80, 23, 4, 23));
        add_sprite(new SimpleSprite("/data/titles/menu_t2.png", 240, 19, 78, 19));
        add_sprite(new SimpleSprite("/data/titles/menu_t3.png", -400, 65, 62, 65));

        add_sprite(new SimpleSprite("/data/menu/menu_textos.png", 45, 157 + 200, 45, 157));
        add_sprite(new SimpleSprite("/data/menu/menu_bg2.png", 13, 341, 13, 141));
    }

    private void add_sprite(SimpleSprite tmp)
    {
        sprites.addElement(tmp);
        layers.append(tmp.sprite);
    }

    public void render(Graphics g)
    {
        g.drawImage(background, 0, 0, 0);
        layers.paint(g, 0, 0);
    }
}
