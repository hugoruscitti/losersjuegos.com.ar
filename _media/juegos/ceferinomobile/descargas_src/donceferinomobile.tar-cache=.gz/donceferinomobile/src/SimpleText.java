/*
 * Don Ceferino Hazaña Mobile
 *
 * Copyright (C) 2009 Hugo Ruscitti <hugoruscitti at gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;


public class SimpleText
{
    public Sprite sprite;
    int to_x;
    int to_y;
    int x;
    int y;
    String msg;

    public SimpleText(String msg, int x, int y, int to_x, int to_y)
    {
        this.to_x = to_x;
        this.to_y = to_y;
        this.x = x;
        this.y = y;
        
        this.msg = msg;
    }

    public void update()
    {
        x += (to_x - x) / 3.0;
        y += (to_y - y) / 3.0;
    }

    public void draw(Graphics g)
    {
        int width;
        int height;
        
        Font font = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, 
                Font.SIZE_LARGE);
        g.setFont(font);
        g.setColor(255, 255, 255);
        
        width = font.stringWidth(msg);
        height = font.getHeight(); 
        
        g.drawString(msg, x - width / 2, y - height / 2, 0);
    }
    
    public void set_text(String msg){
        this.msg = msg;
    }
}
