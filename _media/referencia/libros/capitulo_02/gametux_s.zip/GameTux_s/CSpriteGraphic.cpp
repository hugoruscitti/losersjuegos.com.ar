#include "CSpriteGraphic.h"
#include "util.h"

// Constructor
CSpriteGraphic::CSpriteGraphic()
{
}

// Destructor
CSpriteGraphic::~CSpriteGraphic()
{
  vector <SpriteFrame>::iterator tmp;

  for(tmp=frames.begin(); tmp!=frames.end(); tmp++)
    SDL_FreeSurface(tmp->image);
}

// Carga desde un directorio una lista de frames
int CSpriteGraphic::init(const char *dir, int num_frames, int time, const char *ext)
{
  char filename[256];
  SDL_Surface *image;
 
  for(int num=0; num < num_frames; num++)
  {
    sprintf(filename, "%s%03d.%s", dir, num, ext);
    image=load_sprite(filename);
    if(!image) return 0;

    add_frame(image, 0, 0, time);
  }
  
  return 1;
}

// Carga desde un directorio una lista de frames
// Se pasa por parametro el color transparente
int CSpriteGraphic::init(const char *dir, int num_frames, int time, 
                         SDL_Color color, const char *ext)
{
  char filename[256];
  SDL_Surface *image;
 
  for(int num=0; num < num_frames; num++)
  {
    sprintf(filename, "%s%03d.%s", dir, num, ext);
    image=load_sprite(filename, color);
    if(!image) return 0;

    add_frame(image, 0, 0, time);
  }

  return 1;
}

// Agrega un nuevo frame a la lista de frames
void CSpriteGraphic::add_frame(SDL_Surface *image, int cx, int cy, int time)
{
  SpriteFrame frame;
    
  frame.center.x=cx;
  frame.center.y=cy;
  frame.image=image;
  frame.time=time;
    
  frames.push_back(frame);
}

// Dibuja un frame en buffer en la posicion (x, y)
void CSpriteGraphic::draw(SDL_Surface *buffer, int x, int y, int num)
{
  x-=frames[num].center.x;
  y-=frames[num].center.y;

  draw_sprite(buffer, frames[num].image, x, y);
}

// Devuelve el numero total de frames
int CSpriteGraphic::get_num_frames()
{
  return frames.size();
}

// Devuelve el tiempo de espera de un frame
int CSpriteGraphic::get_time(int num)
{
  return frames[num].time;
}

// Devuelve el ancho de un frame determinado
int CSpriteGraphic::get_w(int num)
{
  return frames[num].image->w;
}

// Devuelve el alto de un frame determinado
int CSpriteGraphic::get_h(int num)
{
  return frames[num].image->h;
}

// Devuelve un puntero a la superficie de un frame determinado
SDL_Surface *CSpriteGraphic::get_frame(int num)
{
  return frames[num].image;
}

