#ifndef UTIL_H
#define UTIL_H

#include <SDL/SDL.h>

// Variables globales externas
extern SDL_Surface *screen;		// Pantalla
extern Uint8 *key;						// Teclado
extern int SCREEN_W;					// Ancho en pixeles de la pantalla
extern int SCREEN_H;					// Alto en pixeles de la pantalla
extern int BPP;								// Bit por pixel

// Prototipo de funciones
void showerror(char *msg);
void putpixel(SDL_Surface *screen, int x, int y, SDL_Color color);
SDL_Color getpixel(SDL_Surface *screen, int x, int y);
Uint32 get_pixel(SDL_Surface *screen, int x, int y);
void lock(SDL_Surface *screen);
void unlock(SDL_Surface *screen);
void draw_sprite(SDL_Surface *screen, SDL_Surface *sprite, int x, int y);
void clear(SDL_Surface *screen);
void clear(SDL_Surface *screen, SDL_Color color);
SDL_Surface *load_sprite(const char *filename);
SDL_Surface *load_sprite(const char *filename, SDL_Color color);

#endif
