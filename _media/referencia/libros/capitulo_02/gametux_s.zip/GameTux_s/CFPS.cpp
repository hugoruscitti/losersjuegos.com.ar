#include "CFPS.h"
#include <SDL/SDL.h>

// Constructor
CFPS::CFPS(int _fps)
{
	timer=new CTimer;
	set_fps(_fps);
}

// Destructor
CFPS::~CFPS()
{
	delete timer;
}

// Asigna un nuevo valor de fps
void CFPS::set_fps(int _fps)
{
	fps=_fps;
	time_delay=1000/fps;
}

// Comienza a funcionar el timer
void CFPS::start()
{
	timer->start();
}

// Espera el tiempo necesario para cumplir los fps solicitados
void CFPS::delay()
{
	int dtime;

	do
	{
		dtime=timer->get_now()-timer->get_first();
	} while(dtime <= time_delay);
}

// Devuelve el numero de frames por segundo
int CFPS::get_fps()
{
	return fps;
}


