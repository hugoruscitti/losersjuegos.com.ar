#ifndef CSPRITE_H
#define CSPRITE_H

#include <SDL/SDL.h>
#include "CSpriteGraphic.h"

class CSprite
{
public:
  CSprite(CSpriteGraphic *graph=NULL);
  virtual ~CSprite();
  void init_graph(CSpriteGraphic *graph);
  int load_anim(const char *filename);
  virtual void update();
  void draw(SDL_Surface *buffer);
  void draw(SDL_Surface *buffer, int num_frame);
  void animate();
  void set_actual_frame(int num);
  int get_actual_frame();
  void start_anim();
  void stop_anim();
  void toggle_anim();
  void rewind();
  void set_pos_x(int x);
  void set_pos_y(int y);
  int get_pos_x();
  int get_pos_y();
  int get_w(int num=0);
  int get_h(int num=0);
  void set_actual_anim(int num);
  int get_actual_anim();
  bool get_full_anim();

protected: 
  SDL_Rect pos;

private:
	CSpriteGraphic *graph;
  int actual_frame;
  int last_time;
  bool anim;
  bool full_anim;
  int actual_anim;
  int actual_secuencia;
  typedef vector <int> secuencia_t;
  vector <secuencia_t> animation;
};

#endif
