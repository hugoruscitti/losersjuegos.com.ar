#include "util.h"
#include <stdlib.h>
#include <string.h>
#include "SDL/SDL_image.h"

// Variables globales
SDL_Surface *screen;  // Pantalla
Uint8 *key;           // Teclado
int SCREEN_W;         // Ancho en pixeles de la pantalla
int SCREEN_H;         // Alto en pixeles de la pantalla
int BPP;              // Bit por pixel

// Muestra un mensaje de error y sale del programa
void showerror(char *msg)
{
  fprintf(stderr, "Error %s: %s", msg, SDL_GetError());
  exit(1);
}

// Coloca un pixel en una posicion determinada de screen
void putpixel(SDL_Surface *screen, int x, int y, SDL_Color color)
{
  // Convertimos color
  Uint32 col=SDL_MapRGB(screen->format, color.r, color.g, color.b);

  // Determinamos posicion de inicio
  char *buffer=(char*) screen->pixels;

  // Calculamos offset para y
  buffer+=screen->pitch*y;

  // Calculamos offset para x
  buffer+=screen->format->BytesPerPixel*x;

  // Copiamos el pixel
  memcpy(buffer, &col, screen->format->BytesPerPixel);
}

// Obtiene un pixel de una posicion determinada de screen
SDL_Color getpixel(SDL_Surface *screen, int x, int y)
{
  SDL_Color color;
  Uint32 col;

  // Determinamos posicion de inicio
  char *buffer=(char *) screen->pixels;

  // Calculamos offset para y
  buffer += screen->pitch*y;

  // Calculamos offset para x
  buffer += screen->format->BytesPerPixel*x;

  // Obtenemos el pixel
  memcpy(&col, buffer, screen->format->BytesPerPixel);

  // Descomponemos el color
  SDL_GetRGB(col, screen->format, &color.r, &color.g, &color.b);

  // Devolvemos el color
  return color;
}

// Obtiene un pixel de una posicion determinada de screen
Uint32 get_pixel(SDL_Surface *screen, int x, int y)
{
  Uint32 col;
  
  //if((x < 0) && (y < 0) && (x > screen->w) && (y > screen->h))
    //return 0;
	
  // Determinamos posicion de inicio
  char *buffer=(char *) screen->pixels;

  // Calculamos offset para y
  buffer += screen->pitch*y;

  // Calculamos offset para x
  buffer += screen->format->BytesPerPixel*x;

  // Obtenemos el pixel
  memcpy(&col, buffer, screen->format->BytesPerPixel);

  // Devolvemos el color
  return col;
}

// Bloquea la superficie si es necesario
void lock(SDL_Surface *screen)
{
  if(SDL_MUSTLOCK(screen))
    SDL_LockSurface(screen);
}

// Desbloquea la superficie si es necesario
void unlock(SDL_Surface *screen)
{
  if(SDL_MUSTLOCK(screen))
    SDL_UnlockSurface(screen);
}

// Dibuja un sprite en screen
void draw_sprite(SDL_Surface *screen, SDL_Surface *sprite, int x, int y)
{
  SDL_Rect rect;

  rect.x=x;
  rect.y=y;

  SDL_BlitSurface(sprite, 0, screen, &rect);
}

// Limpia screen de color negro
void clear(SDL_Surface *screen)
{
  Uint32 col=SDL_MapRGB(screen->format, 0, 0, 0);
  SDL_FillRect(screen, 0, col);
}

// Limpia screen con el color especificado
void clear(SDL_Surface *screen, SDL_Color color)
{
  Uint32 col=SDL_MapRGB(screen->format, color.r, color.g, color.b);
  SDL_FillRect(screen, 0, col);
}

// Carga un sprite desde un archivo 
// El color tranparente es el color magenta (255, 0, 255)
SDL_Surface *load_sprite(const char *filename)
{
  SDL_Surface *tmp, *bmp;
  Uint32 color_key;

  tmp=IMG_Load(filename);
  if(!tmp) return 0;

  color_key=SDL_MapRGB(tmp->format, 255, 0, 255);
  SDL_SetColorKey(tmp, SDL_SRCCOLORKEY|SDL_RLEACCEL, color_key);
  bmp=SDL_DisplayFormat(tmp);
  SDL_FreeSurface(tmp);
  if(!bmp) return 0;

  return bmp;
}

// Carga un sprite desde un archivo
// El color transparente se pasa por parametro
SDL_Surface *load_sprite(const char *filename, SDL_Color color)
{
  SDL_Surface *tmp, *bmp;
  Uint32 color_key;

  tmp=IMG_Load(filename);
  if(!tmp) return 0;

  color_key=SDL_MapRGB(tmp->format, color.r, color.g, color.b);
  SDL_SetColorKey(tmp, SDL_SRCCOLORKEY|SDL_RLEACCEL, color_key);
  bmp=SDL_DisplayFormat(tmp);
  SDL_FreeSurface(tmp);
  if(!bmp) return 0;

  return bmp;
}

