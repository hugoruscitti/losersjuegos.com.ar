#include "CTimer.h"

// Constructor
CTimer::CTimer()
{
	reset();
}

// Destructor
CTimer::~CTimer()
{
}

// Inicializa el timer
void CTimer::reset()
{
	first_time=final_time=0;
	time_cumulated=0;
	time_elapsed=0;
}

// Comienza a funcionar el timer
void CTimer::start()
{
	first_time=SDL_GetTicks();
}

// Detiene el timer
void CTimer::stop()
{
	final_time=SDL_GetTicks();
	time_elapsed=final_time-first_time;
	time_cumulated+=time_elapsed;
}

// Devuelve el tiempo transcurrido
Uint32 CTimer::get_elapsed()
{
	return time_elapsed;
}

// Devuelve el tiempo acumulado
Uint32 CTimer::get_cumulated()
{
	return time_cumulated;
}

// Devuelve el tiempo actual
Uint32 CTimer::get_now()
{
	return SDL_GetTicks();
}

// Devuelvel el tiempo inicial
Uint32 CTimer::get_first()
{
	return first_time;
}

// Devuelve el tiempo final
Uint32 CTimer::get_final()
{
	return final_time;
}

