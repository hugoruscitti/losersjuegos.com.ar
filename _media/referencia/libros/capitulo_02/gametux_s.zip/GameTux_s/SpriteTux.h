#ifndef SPRITE_TUX_H
#define SPRITE_TUX_H

#include "CSprite.h"
#include "CTimer.h"

class SpriteTux:public CSprite
{
public:
  void init();
  void update();
  void caminar();
  void saltar();
  void caer();    

private:
  enum {IZQ, DER};
  float speed_o, speed_max, speed_x, speed_y;
  float pos_x, pos_y;
  float gravedad;
  float speed_correr;
  int dir;
  int suelo;
  bool saltando;
  bool cayendo;
  CTimer timer;
};

#endif

