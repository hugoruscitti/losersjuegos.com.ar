#ifndef CSPRITE_GRAPHIC_H
#define CSPRITE_GRAPHIC_H

#include <SDL/SDL.h>
#include <vector>

using namespace std;

class CSpriteGraphic
{
public:
  CSpriteGraphic();
  ~CSpriteGraphic();
  int init(const char *dir, int num_frames, int time, const char *ext="pcx");
  int init(const char *dir, int num_frames, int time, SDL_Color color, 
					 const char *ext="pcx");
  void add_frame(SDL_Surface *image, int cx, int cy, int time);
  void draw(SDL_Surface *buffer, int x, int y, int num);
  int get_num_frames();
  int get_time(int num=0);
  int get_w(int num=0);
  int get_h(int num=0);
  SDL_Surface *get_frame(int num=0);

private: 
  struct SpriteFrame
  {
    SDL_Rect center;
    SDL_Surface *image;
    int time;
  };
    
  vector <SpriteFrame> frames;
};

#endif

