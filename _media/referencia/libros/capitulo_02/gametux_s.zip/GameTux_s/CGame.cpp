#include "CGame.h"
#include "util.h"
#include <stdlib.h>

// Constructor
CGame::CGame()
{
  SCREEN_W=SCREEN_H=0;
  BPP=0;
  screen=NULL;  
}

// Destructor
CGame::~CGame()
{
}

// Inicializa la SDL y un modo grafico
void CGame::init_graph(int w, int h, int bpp, const char *name, bool fullscreen)
{
  Uint32 flags;

  SCREEN_W=w;
  SCREEN_H=h;
  BPP=bpp;

  if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_TIMER) < 0)
    showerror("al inicializar la SDL");

  atexit(SDL_Quit);

  SDL_WM_SetCaption(name, 0);

  flags=SDL_HWSURFACE|SDL_DOUBLEBUF;
  if(fullscreen) flags|=SDL_FULLSCREEN;

  screen=SDL_SetVideoMode(w, h, bpp, flags);

  if(!screen)
    showerror("al inicializar el modo de video");
}

// Inicializacion de objetos
void CGame::init()
{
}

// Libera memoria ocupada por objetos
void CGame::shutdown()
{
}

// Ciclo principal del juego
void CGame::main()
{
}

