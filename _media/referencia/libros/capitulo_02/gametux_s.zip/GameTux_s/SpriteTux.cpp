#include "SpriteTux.h"
#include "util.h"

// Inicializacion del personaje
void SpriteTux::init()
{
  suelo=SCREEN_H-16;
  pos_x=SCREEN_W/2-get_w()/2;
  pos_y=suelo-get_h();
  speed_o=1.5;
  speed_max=8;
  speed_x=speed_o;
  speed_y=speed_max;
  gravedad=0.5;
  speed_correr=0;
  dir=DER;
  set_actual_frame(10);
  saltando=false;
  cayendo=false;
}

// Actualizacion del personaje
void SpriteTux::update()
{
  timer.start();
  
  stop_anim();

  if(key[SDLK_LEFT]) 
  {
    dir=IZQ; 
    caminar();  
  }
  else if(key[SDLK_RIGHT]) 
  {
    dir=DER;
    caminar();
  }
  else 
  {
    if(dir==IZQ) set_actual_frame(0);
    else set_actual_frame(10);
  }

  if(key[SDLK_LALT] && !cayendo) saltando=true;

  if(key[SDLK_LCTRL]) speed_correr=2;
  else speed_correr=0;

  if(saltando) saltar();
  if(cayendo) caer();

  pos.x=int(pos_x);
  pos.y=int(pos_y);
}

// Nuestro personaje camina
void SpriteTux::caminar()
{
  start_anim();

  if(dir==IZQ)
  {
    set_actual_anim(0);
    pos_x-=speed_x+speed_correr;
    if(pos_x < 0) 
    {
      pos_x=0;
      set_actual_frame(0);
      stop_anim();
    }
  }
  else
  {
    set_actual_anim(1);
    pos_x+=speed_x+speed_correr;
    if(pos_x+get_w() > SCREEN_W) 
    {
      pos_x=SCREEN_W-get_w();
      set_actual_frame(10);
      stop_anim();
    }
  }
}

// Nuestro personaje salta
void SpriteTux::saltar()
{
  float t;

  stop_anim();

  if(dir==IZQ) set_actual_frame(2);
  else set_actual_frame(12);

  timer.stop();
  t=timer.get_elapsed();
  pos_y-=(speed_y+0.5*gravedad*t*t);
  speed_y-=gravedad;

  if(speed_y <= 0)
  {    
    saltando=false;
    cayendo=true;
  }
}

// Nuestro personaje cae
void SpriteTux::caer()
{
  float t;

  stop_anim();

  if(dir==IZQ) set_actual_frame(2);
  else set_actual_frame(12);

  timer.stop();
  t=timer.get_elapsed();
  pos_y+=(speed_y+0.5*gravedad*t*t);
  speed_y+=gravedad;

  if(pos_y+get_h() >= suelo)
  {    
    cayendo=false;
    speed_y=speed_max;
    pos_y=suelo-get_h();
    if(dir==IZQ) set_actual_frame(0);
    else set_actual_frame(10);
  }
}
