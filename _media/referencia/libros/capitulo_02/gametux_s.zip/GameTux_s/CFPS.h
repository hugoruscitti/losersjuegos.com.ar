#ifndef CFPS_H
#define CFPS_H

#include "CTimer.h"

class CFPS
{
public:
	CFPS(int _fps=60);
	~CFPS();
	void set_fps(int _fps);
	void start();
	void delay();
	int get_fps();

private:
	CTimer *timer;
	int fps;
	int time_delay;
};

#endif
