#ifndef GAME_TUX_H
#define GAME_TUX_H

#include "CGame.h"
#include "CSpriteGraphic.h"
#include "SpriteTux.h"
#include "Snow.h"
#include "CFPS.h"

class GameTux:public CGame
{
public:
  void init();
  void shutdown();
  void main();

private:
  CSpriteGraphic *tux_graph;
  SpriteTux *tux;
  Snow *snow;
  CFPS *fps;
};

#endif
