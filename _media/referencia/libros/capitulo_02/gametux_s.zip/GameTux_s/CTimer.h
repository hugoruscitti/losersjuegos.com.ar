#ifndef CTIMER_H
#define CTIMER_H

#include <SDL/SDL.h>

class CTimer
{
public:
	CTimer();
	~CTimer();
	void reset();
	void start();
	void stop();
	Uint32 get_elapsed();
	Uint32 get_cumulated();
	Uint32 get_now();
	Uint32 get_first();
	Uint32 get_final();

private:
	Uint32 first_time, final_time;
	Uint32 time_cumulated;
	Uint32 time_elapsed;
};

#endif
