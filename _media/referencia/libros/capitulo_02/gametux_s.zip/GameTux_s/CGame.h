#ifndef CGAME_H
#define CGAME_H

#include <SDL/SDL.h>

class CGame
{
public:
  CGame();
  virtual ~CGame();
  void init_graph(int w, int h, int bpp, const char *name, bool fullscreen=false);
  virtual void init();
  virtual void shutdown();
  virtual void main();
};

#endif
