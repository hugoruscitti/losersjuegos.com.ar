#include "GameTux.h"
#include "util.h"

// Inicializa los objetos
void GameTux::init()
{
  tux_graph=new CSpriteGraphic;
  tux=new SpriteTux;

  if(!tux_graph->init("tux/tux", 20, 24))
    showerror("al cargar graficos");
  if(!tux->load_anim("tux/tux.ani"))
    showerror("al cargar tux.ani");

  tux->init_graph(tux_graph);
  tux->init();

  snow=new Snow;
  fps=new CFPS;
}

// Libera la memoria de los objetos
void GameTux::shutdown()
{
  delete tux;
  delete tux_graph;
  delete snow;
  delete fps;
}

// Ciclo principal del juego
void GameTux::main()
{
  int salir=0;
  SDL_Event event;

  init();
  
  while(!salir)
  {
  	fps->start();
   
   	while(SDL_PollEvent(&event))
    {
      if(event.type==SDL_QUIT) salir=1;
    }
    key=SDL_GetKeyState(0);
    if(key[SDLK_ESCAPE]) break;

    tux->update();
    tux->animate();
    snow->update();
 
    clear(screen);
    tux->draw(screen);
    snow->draw(screen);
    SDL_Flip(screen);

    fps->delay();
  }

  shutdown();
}
