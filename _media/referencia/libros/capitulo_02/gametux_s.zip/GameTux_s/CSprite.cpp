#include "CSprite.h"
#include "util.h"
#include <stdio.h>

// Constructor
CSprite::CSprite(CSpriteGraphic *graph)
{
  pos.x=pos.y=0;
  actual_frame=0;
  last_time=0;
  full_anim=false;
  anim=false;
  actual_anim=0;
  actual_secuencia=0;
  init_graph(graph);
}

// Destructor
CSprite::~CSprite()
{
}

// Asigna un nuevo sprite grafico
void CSprite::init_graph(CSpriteGraphic *graph)
{
  this->graph=graph;
}

// Carga la secuencia de los frames de las animaciones desde un archivo
int CSprite::load_anim(const char *filename)
{
  FILE *f;
  secuencia_t *secuencia;
  int i, num, num_anim;

  f=fopen(filename, "rt");
  if(!f) return 0;

  fscanf(f, "%d", &num_anim);

  i=0;	
  secuencia=new secuencia_t;
  while((i < num_anim) && !feof(f))
  {
    fscanf(f, "%d", &num);
    
    if(num==-1) // Si completamos una secuencia
    {
      i++;    
      animation.push_back(*secuencia);
      delete secuencia;
      secuencia=new secuencia_t; 
    }
    else     
      secuencia->push_back(num);
  }
  fclose(f);

  return 1;
}

// Actualiza el sprite
void CSprite::update()
{
}

// Dibuja el frame actual del sprite en buffer
void CSprite::draw(SDL_Surface *buffer)
{
  graph->draw(buffer, pos.x, pos.y, actual_frame);
}

// Dibuja un frame determinado del sprite en buffer
void CSprite::draw(SDL_Surface *buffer, int num_frame)
{
  graph->draw(buffer, pos.x, pos.y, num_frame);
}

// Si es necesario realiza la animacion del sprite
void CSprite::animate()
{
  int num_frames=animation[actual_anim].size();

  if(num_frames <= 1) return;

  if(anim)
  {
    int time=SDL_GetTicks();
    int dt=time-last_time;

    if(dt >= (1000/graph->get_time(actual_frame)))
    {
      last_time=time;
      actual_frame=animation[actual_anim][actual_secuencia];
      actual_secuencia++;
      if(actual_secuencia >= num_frames) 
      {
        actual_secuencia=0;      
        full_anim=true;
      }
      else full_anim=false;
    }
  }
}

// Setea el numero del frame actual
void CSprite::set_actual_frame(int num)
{
  if(num < 0) num=0;
  if(num >= graph->get_num_frames()) num=graph->get_num_frames()-1;
  actual_frame=num;
}

// Devuelve el numero del frame actual
int CSprite::get_actual_frame()
{
  return actual_frame;
}

// Inicia la animacion
void CSprite::start_anim()
{
  anim=true;
}

// Para la animacion
void CSprite::stop_anim() 
{
  anim=false;
}

// Toggle la animacion
void CSprite::toggle_anim()
{
  anim=!anim;
}

// Reinicia la animacion
void CSprite::rewind()
{
  actual_frame=0;
}

// Setea la coordenada x de la posicion
void CSprite::set_pos_x(int x)
{
  pos.x=x;
}

// Setea la coordenada y de la posicion
void CSprite::set_pos_y(int y)
{
  pos.y=y;
}

// Devuelve la coordenada x de la posicion
int CSprite::get_pos_x()
{
  return pos.x;
}

// Devuelve la coordenada y de la posicion
int CSprite::get_pos_y()
{
  return pos.y;
}

// Devuelve el ancho de un frame determinado
int CSprite::get_w(int num)
{
  if(num==0) num=actual_frame;
  return graph->get_w(num);
}

// Devuelve el alto de un frame determinado
int CSprite::get_h(int num)
{
  if(num==0) num=actual_frame;
  return graph->get_h(num);
}

// Setea el valor de la animacion actual
void CSprite::set_actual_anim(int num)
{
  if(num < 0) num=0;
  if(num >= int(animation.size())) num=int(animation.size())-1;
  actual_anim=num;
}

// Devuelve el numero de la animacion actual
int CSprite::get_actual_anim()
{
  return actual_anim;
}

// Devuelve true si se ha vuelto a comenzar de nuevo la animacion actual, de lo contrario false
bool CSprite::get_full_anim()
{
  return full_anim;
}

