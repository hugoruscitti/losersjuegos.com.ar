#ifndef SNOW_H
#define SNOW_H

#include <SDL/SDL.h>
#include <list>

using namespace std;

class Snow
{
public:
  Snow(int num=500);
  ~Snow();
  void draw(SDL_Surface *buffer);
  void update();

private:
  struct copo_t
  {
    SDL_Rect pos, speed;
  };

  list <copo_t> copos;  

  void crear_copo(copo_t *copo);
};

#endif 
