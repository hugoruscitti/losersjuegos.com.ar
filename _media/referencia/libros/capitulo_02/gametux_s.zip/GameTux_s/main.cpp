/*

  NOMBRE: main.cpp

  DESCRIPCION: Ejemplo de como mover un personaje por la pantalla 
               utilizando la libreria SDL.

  AUTOR: Roberto Albornoz Figueroa

  FECHA CREACION: 19/09/2002
  
  ULTIMA MODIFICACION: 07/02/2003

*/

#include "GameTux.h"
#include <string.h>

int main(int argc, char **argv)
{
  GameTux *tux;
  bool full=false;

  if(argc > 1)
  {
    if(!strcmp(argv[1], "-f")) full=true;
  }

  tux=new GameTux;
  tux->init_graph(640, 480, 16, "Ejemplo: Juego Tux por RCAF (C) 2003", full);
  tux->main();
  delete tux;

  return 0;
}
