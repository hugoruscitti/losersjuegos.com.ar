// Listado: test1.c

// No te preocupes por no entender este código
// Sólo compilalo para comprobar que enlaza correctamente

#include <SDL/SDL.h>
#include <stdio.h>


int main() {

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
	fprintf(stderr, "No podemos inicializar SDL: %s\n", SDL_GetError());
	exit(1);
    }
    else {

	fprintf(stdout, "Hemos inicializado SDL\n");
	atexit(SDL_Quit);
    }


    return 0;
}
