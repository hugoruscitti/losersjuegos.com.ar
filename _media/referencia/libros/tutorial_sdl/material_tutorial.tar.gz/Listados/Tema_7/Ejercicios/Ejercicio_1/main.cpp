// Listados: main.cpp
//
// Ejercicio 1

#include <iostream>
#include <SDL/SDL.h>

#include "Personaje.h"

using namespace std;

int main() {

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {

        cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
        exit(1);

    }


    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video

    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {

        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);

    }


    // Establecemos el modo de video

    SDL_Surface *pantalla;

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {

        cerr << "No se pudo establecer el modo de video: "
             << SDL_GetError() << endl;

        exit(1);
    }


    // Cargamos la bola

    Personaje principal("./Imagenes/bola.bmp");


    // Lo mostramos por pantalla
    
    principal.dibujar(pantalla);

    SDL_Flip(pantalla);


    // Variables auxiliares

    SDL_Event evento;
 
    bool terminar = false;

    // Controlará la dirección con 
    // respecto al eje x o y
    
    bool direccion_x = true;
    bool direccion_y = false;

    int x0, y0;

    cout << "Pulse ESC para terminar" << endl;

    // Game loop

    while(terminar == false) {

	// Variables de control para saber si 
	// tenemos que refrescar la pantalla o no

	x0 = principal.pos_x();
	y0 = principal.pos_y();


	if(direccion_x == true && principal.pos_x() >= 540)
	    direccion_x = false;
	
	if(direccion_y == true && principal.pos_y() >= 380)
	    direccion_y= false;
	
	if(direccion_x == false && principal.pos_x() <= 0)
	    direccion_x = true;

	if(direccion_y == false && principal.pos_y() <= 0)
	    direccion_y = true;	
	    

	if(direccion_x == true)
	    principal.avanzar_x();
	else
	    principal.retrasar_x();

	
	if(direccion_y == true)
	    principal.bajar_y();
	else
	    principal.subir_y();	


	



	// Si existe modificación dibujamos

	if(x0 != principal.pos_x() || y0 != principal.pos_y()) {

#ifdef DEBUG	    
	    cout << "= Posición actual del personaje" << endl;
	    cout << "- X: " << principal.pos_x() << endl;
	    cout << "- Y: " << principal.pos_y() << endl;
#endif
	    
	    // Dibujamos al personaje en su posición nueva
	    
	    Uint32 negro = SDL_MapRGB(pantalla->format, 0, 0, 0);
	    
	    SDL_FillRect(pantalla, NULL, negro);
	    
	    principal.dibujar(pantalla);
	    
	    SDL_Flip(pantalla);
	}



	// Control de Eventos

	while(SDL_PollEvent(&evento)) {


	    if(evento.type == SDL_KEYDOWN) {
		
		if(evento.key.keysym.sym == SDLK_ESCAPE)
		    terminar = true;
		
	    }
	    
	    if(evento.type == SDL_QUIT)
		terminar = true;
	    
	}
	
    }

    return 0;

}


