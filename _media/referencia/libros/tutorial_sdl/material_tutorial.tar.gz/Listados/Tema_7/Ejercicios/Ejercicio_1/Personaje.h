// Listado: Personaje.h
//
// Clase Personaje

#ifndef _PERSONAJE_H_
#define _PERSONAJE_H_

#include <SDL/SDL.h>


class Personaje {

 public:

    // Constructor

    Personaje(char *ruta, int x = 0, int y = 0);


    // Consultoras

    int pos_x(void);
    int pos_y(void);

    void dibujar(SDL_Surface *pantalla);

    // Modificadoras

    void pos_x(int x);
    void pos_y(int y);

    // Modifica la posición del personaje con respecto al eje X

    void avanzar_x(void);
    void retrasar_x(void);

    // Modifica la posición del personaje con respecto al eje Y

    void bajar_y(void);
    void subir_y(void);
   


 private:
    
    // Posición
    int x, y;

    SDL_Surface *imagen;

};

#endif // _PERSONAJE_H_
