// Listado: Miscelanea.h
//
// Librería auxiliar para evitar tareas repetitivas

#ifndef _MISCELANEA_
#define _MISCELANEA_

// Inicializa SDL con los parámetros indicados

int inicializar_SDL(SDL_Surface **pantalla, char *caption,\
		    int ancho = 640, int alto = 480, int bpp = 24);


// Maneja los eventos de salida

int eventos_salida(void);


#endif // _MISCELANEA
