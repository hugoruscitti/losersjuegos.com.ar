// Listado: Miscelanea.cpp
//
// Implementación de funciones auxiliares

#include <iostream>
#include <SDL/SDL.h>

#include "Miscelanea.h"

using namespace std;

int inicializar_SDL(SDL_Surface **pantalla, char *caption,\
                    int ancho, int alto, int bpp) {


    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
	
        cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	return 1;       
	
    }
    
    
    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video
    
    if(SDL_VideoModeOK(ancho, alto, bpp, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {

        cerr << "Modo no soportado: " << SDL_GetError() << endl;
	return 1;

    }


    // Establecemos el modo de video

    *pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(*pantalla == NULL) {

        cerr << "No se pudo establecer el modo de video: "
             << SDL_GetError() << endl;

	return 1;
    }

    
    return 0;

}


int eventos_salida(void) {
    
    // La misma variable para todas las llamadas
    
    static SDL_Event evento;
    
    
    // Bucle de control de los eventos de salida
    
    while(SDL_PollEvent(&evento)) {
	
	if (evento.type == SDL_QUIT)
	    return 0;
	
	if (evento.type == SDL_KEYDOWN) {
	    
	    if (evento.key.keysym.sym == SDLK_ESCAPE) 
		return 0;
	    
	}
    }
    
    return 1;
}
