// Listado: Colisiones.cpp
//
// Implementación de funciones dedicadas a la detección
// de colisiones

// Esta función devuelve true si existe colisión entre los dos 
// personajes que recibe como parámetros.
//
// Estos personajes estarán compuestos por rectángulos

#include <iostream>
#include "Personaje.h"
#include "Colisiones.h"

using namespace std;


// Colisión entre dos personajes divididos en rectángulos
// Devuelve true en caso de colisión
// O(n^2)


bool colision(Personaje &uno, Personaje &otro) {

    int w1, h1, w2, h2, x1, y1, x2, y2;

    // Todos los rectángulos del primer personaje

    for(size_t i = 0; i < uno.rectangulos.size(); i++) {
    
     
	w1 = uno.rectangulos[i].w;
	h1 = uno.rectangulos[i].h;
	x1 = uno.rectangulos[i].x + uno.pos_x();
	y1 = uno.rectangulos[i].y + uno.pos_y();

	
	// Con todos los rectángulos del segundo personaje
	
	for(size_t j = 0; j < otro.rectangulos.size(); j++) {
	    
	    w2 = otro.rectangulos[j].w;
	    h2 = otro.rectangulos[j].h;
	    x2 = otro.rectangulos[j].x + otro.pos_x();
	    y2 = otro.rectangulos[j].y + otro.pos_y();
    
	
	    // Si existe colisión entre alguno de los 
	    // rectángulos paramos los bucles

	    if( ((x1 + w1) > x2) &&
		((y1 + h1) > y2) &&
		((x2 + w2) > x1) &&
		((y2 + h2) > y1)) 
	
		return true;
	}
    }


    return false;

}
