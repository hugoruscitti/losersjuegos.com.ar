// Listado: main.cpp
//
// Ejercicio 2. Implementación de colisiones 
// entre dos circunferencias

#include <iostream>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>


#include "Miscelanea.h"
#include "Teclado.h"
#include "Personaje.h"
#include "Colisiones.h"

using namespace std;

int main() {

    SDL_Surface *pantalla;

    // Inicializamos SDL y establecemos el modo de video

    if(inicializar_SDL(&pantalla, "Colisiones")) {

	cerr << "No se puede inicializar SDL" << SDL_GetError() << endl;
        exit(1);
	
    }


    // Inicializamos la librería TTF

    if(TTF_Init() == 0) {

	atexit(TTF_Quit);
        cout << "TTF inicializada" << endl;
	
    }

    TTF_Font *fuente;

    fuente = TTF_OpenFont("Fuentes/ep.ttf", 40);

    SDL_Color color;

    // Establecemos el color para la fuente

    color.r = 250;
    color.g = 100;
    color.b = 100;

    // Teclado para controlar al personaje
    
    Teclado teclado;

    // Cargamos los personajes para las colisiones

    Personaje principal("./Imagenes/jacinto_tutorial.bmp");
    Personaje adversario("./Imagenes/malvado.bmp", 250, 200);

    // Componemos los personajes

    // Vamos a contruir el área de colisión a partir de rectángulos
    // para el personaje principal

    SDL_Rect rect_principal[3] = {{27, 3, 41, 35},
				  {34, 39, 37, 32},
				  {30, 72, 46, 24}};


    for(int i = 0; i < 3; i++)
	principal.annadir_rectangulo(rect_principal[i]);

    
    // Vamos a contruir el área de colisión a partir de rectángulos
    // para el adversario

    SDL_Rect rect_adversario[1] = {{25, 2, 48, 94}}; 
    
    for(int i = 0; i < 1; i++)
	adversario.annadir_rectangulo(rect_adversario[i]);   
    

    // Los mostramos por pantalla
    
    principal.dibujar(pantalla);
    adversario.dibujar(pantalla);

    SDL_Flip(pantalla);


    // Variables auxiliares

    bool terminar = false;

    int x0, y0;
    
    SDL_Rect pos_texto;

    pos_texto.x = 200;
    pos_texto.y = 75;

    // Game loop

    while(terminar == false) {

	// Actualizamos el estado del teclado

	teclado.actualizar();

	// Variables de control para saber si 
	// tenemos que refrescar la pantalla o no

	x0 = principal.pos_x();
	y0 = principal.pos_y();


	// El adversario se recorrerá la pantalla
	// linealmente en ciclos

	//if(adversario.pos_x() < -40)
	//adversario.pos_x(640);

	//adversario.retrasar_x();

	// Actualización lógica de la posición
       
	if(teclado.pulso(Teclado::TECLA_SUBIR)) {

	    principal.subir_y();

	}

	if(teclado.pulso(Teclado::TECLA_BAJAR)) {

	    principal.bajar_y();

	}

	if(teclado.pulso(Teclado::TECLA_IZQUIERDA)) {

	    principal.retrasar_x();

	}

	if(teclado.pulso(Teclado::TECLA_DERECHA)) {

	    principal.avanzar_x();

	}
	
	// Dibujamos a los personajes
	// en su nuevas posiciones
	
	Uint32 negro = SDL_MapRGB(pantalla->format, 0, 0, 0);
	
	SDL_FillRect(pantalla, NULL, negro);
	
	principal.dibujar(pantalla);
	adversario.dibujar(pantalla);
	
	// Comprobamos si existe colision

	if(colision(principal, adversario))
	    SDL_BlitSurface(TTF_RenderText_Blended(fuente, "Colision", color),
			    NULL,
			    pantalla,
			    &pos_texto);

	// Actualizamos la pantalla

	SDL_Flip(pantalla);
				

	// Función auxiliar que
	// controla si existen eventos de salida

	if(eventos_salida() == 0)
	    terminar = 1;
	
    }

    return 0;

}


