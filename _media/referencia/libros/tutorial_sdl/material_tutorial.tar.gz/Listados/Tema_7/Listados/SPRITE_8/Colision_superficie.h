// Listados: Colisiones.h
//
//

#ifndef _COLISION_SUPERFICIE_H_
#define _COLISION_SUPERFICIE_H_

class Personaje;

bool colision_superficie(Personaje &uno, Personaje &otro);

#endif
