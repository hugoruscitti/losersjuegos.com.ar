// Listados: main.cpp
//
// Programa de prueba. Implementación de colisiones

#include <iostream>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>


#include "Miscelanea.h"
#include "Teclado.h"
#include "Personaje.h"
#include "Colision_superficie_ajustada.h"

using namespace std;

int main() {

    SDL_Surface *pantalla;

    // Inicializamos SDL y establecemos el modo de video

    if(inicializar_SDL(&pantalla, "Colisiones")) {

	cerr << "No se puede inicializar SDL" << SDL_GetError() << endl;
        exit(1);
	
    }


    // Inicializamos la librería TTF

    if(TTF_Init() == 0) {

	atexit(TTF_Quit);
        cout << "TTF inicializada" << endl;
	
    }

    TTF_Font *fuente;

    fuente = TTF_OpenFont("Fuentes/ep.ttf", 40);

    SDL_Color color;

    // Establecemos el color para la fuente

    color.r = 250;
    color.g = 100;
    color.b = 100;

    // Teclado para controlar al personaje
    
    Teclado teclado;

    // Cargamos los personajes para las colisiones

    // Definimos los rectángulos que nos van a permitir 
    // ajustar la superficie del personaje

    SDL_Rect rect_principal, rect_adversario;

    rect_principal.x = 24;
    rect_principal.y = 1;
    rect_principal.h = 95;
    rect_principal.w = 45;

    rect_adversario.x = 23;
    rect_adversario.y = 1;
    rect_adversario.h = 95;
    rect_adversario.w = 45;
    

    Personaje principal("./Imagenes/jacinto.bmp", rect_principal);
    Personaje adversario("./Imagenes/malvado.bmp", rect_adversario, 250, 200);


    // Los mostramos por pantalla
    
    principal.dibujar(pantalla);
    adversario.dibujar(pantalla);

    SDL_Flip(pantalla);


    // Variables auxiliares

    bool terminar = false;

    int x0, y0;
    
    SDL_Rect pos_texto;

    pos_texto.x = 200;
    pos_texto.y = 75;

    // Game loop

    while(terminar == false) {

	// Actualizamos el estado del teclado

	teclado.actualizar();

	// Variables de control para saber si 
	// tenemos que refrescar la pantalla o no

	x0 = principal.pos_x();
	y0 = principal.pos_y();


	// El adversario se recorrerá la pantalla
	// linealmente en ciclos

	//if(adversario.pos_x() < -40)
	//adversario.pos_x(640);

	//adversario.retrasar_x();

	// Actualización lógica de la posición
       
	if(teclado.pulso(Teclado::TECLA_SUBIR)) {

	    principal.subir_y();

	}

	if(teclado.pulso(Teclado::TECLA_BAJAR)) {

	    principal.bajar_y();

	}

	if(teclado.pulso(Teclado::TECLA_IZQUIERDA)) {

	    principal.retrasar_x();

	}

	if(teclado.pulso(Teclado::TECLA_DERECHA)) {

	    principal.avanzar_x();

	}
	
	// Dibujamos a los personajes
	// en su nuevas posiciones
	
	Uint32 negro = SDL_MapRGB(pantalla->format, 0, 0, 0);
	
	SDL_FillRect(pantalla, NULL, negro);
	
	principal.dibujar(pantalla);
	adversario.dibujar(pantalla);
	
	// Comprobamos si existe colision

	if(colision_superficie_ajustada(principal, adversario))
	    SDL_BlitSurface(TTF_RenderText_Blended(fuente, "Colision", color),
			    NULL,
			    pantalla,
			    &pos_texto);

	// Actualizamos la pantalla

	SDL_Flip(pantalla);
				

	// Función auxiliar que
	// controla si existen eventos de salida

	if(eventos_salida() == 0)
	    terminar = 1;
	
    }

    return 0;

}


