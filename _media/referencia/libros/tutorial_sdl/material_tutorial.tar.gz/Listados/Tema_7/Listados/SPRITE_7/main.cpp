// Listados: main.cpp
//
// Programa de prueba
// Implementación INTUITIVA de autómata
// Nos acerca a la implementación del autómata pero no es la
// metodología más correcta

#include <iostream>
#include <SDL/SDL.h>

#include "Teclado.h"
#include "Personaje.h"
#include "Miscelanea.h"

using namespace std;

int main() {

    // Inicializamos SDL y Establecemos el modo de video

    SDL_Surface *pantalla;

    if(inicializar_SDL(&pantalla, "Automata")) {

	cerr << "No se puede inicializar SDL" << SDL_GetError() << endl;
	exit(1);

    }


    // Teclado para controlar al personaje
    
    Teclado teclado;

    // Cargamos un personaje

    Personaje principal;


    // Variables auxiliares

    SDL_Event evento;
    SDL_Rect antiguo;
 
    bool terminar = false;

    int x0, y0;

    estados_personaje s0;

    Uint32 negro = SDL_MapRGB(pantalla->format, 0, 0, 0);

    // Controlo la dirección: true = derecha & false = izquierda

    bool direccion = true; 

    // Game loop

    while(terminar == false) {

	// Actualizamos el estado del teclado
	
	teclado.actualizar();
	
	// Variables de control para saber si 
	// tenemos que refrescar la pantalla o no
	
	x0 = principal.pos_x();
	y0 = principal.pos_y();
	s0 = principal.estado_actual();
	
	// Actualización lógica de la posición
	// y el estado
	
	if(teclado.pulso(Teclado::TECLA_SUBIR)) {
	    
	    if(direccion)
		principal.cambio_estado(SALTAR_DERECHA);
	    else
		principal.cambio_estado(SALTAR_IZQUIERDA);
	    
	} else if(teclado.pulso(Teclado::TECLA_BAJAR)) {
	    
	    if(direccion)
		principal.cambio_estado(AGACHAR_DERECHA);
	    else
		principal.cambio_estado(AGACHAR_IZQUIERDA);		
	    
	} else if(teclado.pulso(Teclado::TECLA_IZQUIERDA)) {
	    
	    if(principal.pos_x() > -10) {
		
		principal.retrasar_x();
		principal.cambio_estado(ANDAR_IZQUIERDA);		
		
	    }
	    
	    direccion = false;
	    
	} else if(teclado.pulso(Teclado::TECLA_DERECHA)) {
	    
	    if(principal.pos_x() < 580) {
		
		principal.avanzar_x();
		principal.cambio_estado(ANDAR_DERECHA);	    
		
	    }
	    
	    direccion = true;
	    
	} else if(teclado.pulso(Teclado::TECLA_DISPARAR)) {
	    
	    if(direccion)
		principal.cambio_estado(GOLPEAR_DERECHA);
	    else
		principal.cambio_estado(GOLPEAR_IZQUIERDA);
	    
	} else {
	    
	    if(direccion)
		principal.cambio_estado(PARADO_DERECHA);
	    else
		principal.cambio_estado(PARADO_IZQUIERDA);		
	    }
	
	
	// Si existe modificación dibujamos
	
	if(x0 != principal.pos_x() || y0 != principal.pos_y()
	   || s0 != principal.estado_actual() ) {
	    
#ifdef DEBUG
	    cout << "= Posición actual del personaje" << endl;
	    cout << "- X: " << principal.pos_x() << endl;
	    cout << "- Y: " << principal.pos_y() << endl;
#endif
	    
	    // Dibujamos al personaje en su posición nueva
	    // Borramos la antigua
	    
	    antiguo.x = x0;
	    antiguo.y = y0;
	    
	    
	    SDL_FillRect(pantalla, NULL, negro);
	    
	    principal.dibujar(pantalla);
	    
	    SDL_Flip(pantalla);
	}
	
	// Control de Eventos
	
	while(SDL_PollEvent(&evento)) {


	    if(evento.type == SDL_KEYDOWN) {
		
		if(evento.key.keysym.sym == SDLK_ESCAPE)
		    terminar = true;
		
	    }
	    
	    if(evento.type == SDL_QUIT)
		terminar = true;
	    
	}
	
    }

    return 0;

}


