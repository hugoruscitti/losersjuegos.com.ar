// Listados: main.cpp
//
// Programa de prueba. Implementación de colisiones

#include <iostream>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>


#include "Miscelanea.h"
#include "Teclado.h"
#include "Personaje.h"
#include "Colisiones.h"

using namespace std;

int main() {

    SDL_Surface *pantalla;

    // Inicializamos SDL y establecemos el modo de video

    if(inicializar_SDL(&pantalla, "Colisiones")) {

	cerr << "No se puede inicializar SDL" << SDL_GetError() << endl;
        exit(1);
	
    }


    // Inicializamos la librería TTF

    if(TTF_Init() == 0) {

	atexit(TTF_Quit);
        cout << "TTF inicializada" << endl;
	
    }

    TTF_Font *fuente;

    fuente = TTF_OpenFont("Fuentes/ep.ttf", 40);

    SDL_Color color;

    // Establecemos el color para la fuente

    color.r = 250;
    color.g = 100;
    color.b = 100;

    // Teclado para controlar al personaje
    
    Teclado teclado;

    // Cargamos los personajes para las colisiones

    Personaje principal("./Imagenes/bueno_tutorial.bmp");
    Personaje adversario("./Imagenes/malvado_tutorial.bmp", 250, 200);

    // Componemos los personajes

    // Vamos a contruir el área de colisión a partir de rectángulos
    // para el personaje principal

    SDL_Rect rect_principal[12] = {{3, 82, 92, 8},
				   {10, 75, 78, 6},
				   {14, 67, 71, 7},
				   {17, 60, 64, 6},
				   {26, 45, 48, 5},
				   {29, 39, 40, 5},
				   {32, 34, 34, 4},
				   {35, 29, 28, 4},
				   {38, 24, 22, 4},
				   {40, 18, 18, 5},
				   {44, 13, 11, 4},
				   {47, 8, 5, 4}};


    for(int i = 0; i < 12; i++)
	principal.annadir_rectangulo(rect_principal[i]);

    
    // Vamos a contruir el área de colisión a partir de rectángulos
    // para el adversario

    SDL_Rect rect_adversario[12] = {{82, 3, 8, 92},
				    {75, 10, 6, 78},
				    {67, 14, 7, 71},
				    {60, 17, 6, 64},
				    {45, 26, 5, 48},
				    {39, 29, 5, 40},
				    {34, 32, 4, 34},
				    {29, 35, 4, 28},
				    {24, 38, 4, 22},
				    {18, 40, 5, 18},
				    {13, 44, 4, 11},
				    {8, 47, 4, 5}};

    
    for(int i = 0; i < 12; i++)
	adversario.annadir_rectangulo(rect_adversario[i]);   
    

    // Los mostramos por pantalla
    
    principal.dibujar(pantalla);
    adversario.dibujar(pantalla);

    SDL_Flip(pantalla);


    // Variables auxiliares

    bool terminar = false;

    int x0, y0;
    
    SDL_Rect pos_texto;

    pos_texto.x = 200;
    pos_texto.y = 75;

    // Game loop

    while(terminar == false) {

	// Actualizamos el estado del teclado

	teclado.actualizar();

	// Variables de control para saber si 
	// tenemos que refrescar la pantalla o no

	x0 = principal.pos_x();
	y0 = principal.pos_y();


	// El adversario se recorrerá la pantalla
	// linealmente en ciclos

	//if(adversario.pos_x() < -40)
	//adversario.pos_x(640);

	//adversario.retrasar_x();

	// Actualización lógica de la posición
       
	if(teclado.pulso(Teclado::TECLA_SUBIR)) {

	    principal.subir_y();

	}

	if(teclado.pulso(Teclado::TECLA_BAJAR)) {

	    principal.bajar_y();

	}

	if(teclado.pulso(Teclado::TECLA_IZQUIERDA)) {

	    principal.retrasar_x();

	}

	if(teclado.pulso(Teclado::TECLA_DERECHA)) {

	    principal.avanzar_x();

	}
	
	// Dibujamos a los personajes
	// en su nuevas posiciones
	
	Uint32 negro = SDL_MapRGB(pantalla->format, 0, 0, 0);
	
	SDL_FillRect(pantalla, NULL, negro);
	
	principal.dibujar(pantalla);
	adversario.dibujar(pantalla);
	
	// Comprobamos si existe colision

	if(colision(principal, adversario))
	    SDL_BlitSurface(TTF_RenderText_Blended(fuente, "Colision", color),
			    NULL,
			    pantalla,
			    &pos_texto);

	// Actualizamos la pantalla

	SDL_Flip(pantalla);
				

	// Función auxiliar que
	// controla si existen eventos de salida

	if(eventos_salida() == 0)
	    terminar = 1;
	
    }

    return 0;

}


