// Listado: Galeria.h

#ifndef _GALERIA_H_
#define _GALERIA_H_

#include <map>

// Declaración adelantada

class Imagen;
class Fuente;


using namespace std;

class Galeria {

 public:

    // Tipos de imágenes contenidas en la galería

    enum codigo_imagen {
	
	//... Nos permite indexar las imágenes
    };

    // Fuentes almacenadas en la galería

    enum codigo_fuente {
	
	//... Nos permite indexar las fuentes
    };


    // Constructor

    Galeria ();

    // Consultoras		
 
    Imagen *imagen(codigo_imagen cod_ima);
    Fuente *fuente(codigo_fuente indice);

    ~Galeria();

    // Conjunto de imágenes y de fuentes
    // que vamos a utilizar en la aplicación

    map<codigo_imagen, Imagen *> imagenes;
    map<codigo_fuente, Fuente *> fuentes;
};

#endif
