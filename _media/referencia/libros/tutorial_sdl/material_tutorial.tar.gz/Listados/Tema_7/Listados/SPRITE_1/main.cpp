// Ejemplo 1
//
// Listado: main.cpp
// Programa de pruebas. Animación básica
// Primera versión. Poco eficiente


#include <iostream>
#include <iomanip>

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>

#define TEMPO 80

using namespace std;

int main()
{

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {

	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
	
    }


    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video
    
    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {
	
        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);
	
    }


    // Establecemos el modo de video

    SDL_Surface *pantalla;

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {

        cerr << "No se pudo establecer el modo de video: "
             << SDL_GetError() << endl;

        exit(1);
    }


    // Cargamos las 30 imágenes de la animación
    // 30 accesos a disco (muy mejorable)

    SDL_Surface *imagenes[30];

    imagenes[29] = NULL;

    imagenes[0] = IMG_Load("Imagenes/1.png");
    imagenes[1] = IMG_Load("Imagenes/2.png");
    imagenes[2] = IMG_Load("Imagenes/3.png");
    imagenes[3] = IMG_Load("Imagenes/4.png");
    imagenes[4] = IMG_Load("Imagenes/5.png");
    imagenes[5] = IMG_Load("Imagenes/6.png");
    imagenes[6] = IMG_Load("Imagenes/7.png");
    imagenes[7] = IMG_Load("Imagenes/8.png");
    imagenes[8] = IMG_Load("Imagenes/9.png");
    imagenes[9] = IMG_Load("Imagenes/10.png");
    imagenes[10] = IMG_Load("Imagenes/11.png");
    imagenes[11] = IMG_Load("Imagenes/12.png");
    imagenes[12] = IMG_Load("Imagenes/13.png");
    imagenes[13] = IMG_Load("Imagenes/14.png");
    imagenes[14] = IMG_Load("Imagenes/15.png");
    imagenes[15] = IMG_Load("Imagenes/16.png");
    imagenes[16] = IMG_Load("Imagenes/17.png");
    imagenes[17] = IMG_Load("Imagenes/18.png");
    imagenes[18] = IMG_Load("Imagenes/19.png");
    imagenes[19] = IMG_Load("Imagenes/20.png");
    imagenes[20] = IMG_Load("Imagenes/21.png");
    imagenes[21] = IMG_Load("Imagenes/22.png");
    imagenes[22] = IMG_Load("Imagenes/23.png");
    imagenes[23] = IMG_Load("Imagenes/24.png");
    imagenes[24] = IMG_Load("Imagenes/25.png");
    imagenes[25] = IMG_Load("Imagenes/26.png");
    imagenes[26] = IMG_Load("Imagenes/27.png");
    imagenes[27] = IMG_Load("Imagenes/28.png");
    imagenes[28] = IMG_Load("Imagenes/29.png");

    // Variables auxiliares

    SDL_Event evento;
    int i = 0;
    Uint32 negro = SDL_MapRGB(pantalla->format, 0, 0, 0);

    Uint32 t0 = SDL_GetTicks();
    Uint32 t1;

    // Bucle "infinito"

    for( ; ; ) {

	t1 = SDL_GetTicks();
	
	// Mostramos una imagen cada medio segundo

	if((t1 - t0) > TEMPO) {

	    if(i > 28) {
	    
		SDL_FillRect(pantalla, NULL, negro);
		SDL_Flip(pantalla);
		
		i = 0;
		
	    } else {
		
		SDL_BlitSurface(imagenes[i], NULL, pantalla, NULL);    
		
		SDL_Flip(pantalla);

		t0 = SDL_GetTicks();
		
		i++;
	    }
	}
	
	while(SDL_PollEvent(&evento)) {
	    
	    if(evento.type == SDL_KEYDOWN) {
	
		if(evento.key.keysym.sym == SDLK_ESCAPE)
		    
		    return 0;

		if(evento.key.keysym.sym == SDLK_f)
		    SDL_WM_ToggleFullScreen(pantalla);

	    }

	    if(evento.type == SDL_QUIT)
		
		return 0;
	    
	    
	}
    }   
}

