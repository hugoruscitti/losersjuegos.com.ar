// Listado: Personaje.cpp
//
// Implementación de la clase Personaje

#include <iostream>
#include <SDL/SDL_image.h>

#include "Personaje.h"

using namespace std;


// Constructor

Personaje::Personaje(char *ruta, int x, int y) {

    this->x = x;
    this->y = y;

    // Cargamos la imagen

    imagen = IMG_Load(ruta);

    if(imagen == NULL) {

	cerr << "Error: " << SDL_GetError() << endl;;
	exit(1);

    } 

    // Calculamos el color transparente, en nuestro caso el verde

    // Uint32 colorkey = SDL_MapRGB(imagen->format, 0, 255, 0); 

    // Lo establecemos como color transparente

    // SDL_SetColorKey(imagen, SDL_SRCCOLORKEY, colorkey);

}



// Consultoras

int Personaje::pos_x(void) {

    return x;

}

int Personaje::pos_y(void) {

    return y;

}

int Personaje::ancho(void) {

    return imagen->w;

}

int Personaje::alto(void) {

    return imagen->h;

}


void Personaje::dibujar(SDL_Surface *pantalla) {

    SDL_Rect rect;

    rect.x = x;
    rect.y = y;

    SDL_BlitSurface(imagen, NULL, pantalla, &rect);
    

}


// Modificadoras

void Personaje::pos_x(int x) {

    this->x = x;

}


void Personaje::pos_y(int y) {

    this->y = y;

}

// El movimiento de la imagen se establece
// de 4 en 4 píxeles

void Personaje::avanzar_x(void) {

    x += 4;
}

void Personaje::retrasar_x(void) {

    x -= 4;
}

void Personaje::bajar_y(void) {

    y += 4;

}

void Personaje::subir_y(void) {

    y -= 4;

}
