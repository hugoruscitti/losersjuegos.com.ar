// Listado: main.cpp
//
// Programa de prueba de la clase Control Animación

#include <iostream>

#include "Control_Animacion.h"

using namespace std;

int main() {

    Control_Animacion animacion("0, 2, 4, 6, 8");

    cout << "Secuencia: " ;

    for(int i = 0; i < 100; i++) {

	cout << " - " << animacion.cuadro();

	animacion.avanzar();

    }

    cout << endl;

    return 0;

}
