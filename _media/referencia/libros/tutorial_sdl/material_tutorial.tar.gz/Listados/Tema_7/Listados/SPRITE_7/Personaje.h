// Listado: Personaje.h
//
// Clase Personaje

#ifndef _PERSONAJE_H_
#define _PERSONAJE_H_

#include <SDL/SDL.h>

class Animacion;                      // Declaración adelantada

// Enumerado con los posibles estados del personaje

enum estados_personaje {
    
    PARADO,
    PARADO_DERECHA,
    SALTAR_DERECHA,
    ANDAR_DERECHA,
    GOLPEAR_DERECHA,
    AGACHAR_DERECHA,
    PARADO_IZQUIERDA,
    SALTAR_IZQUIERDA,
    ANDAR_IZQUIERDA,
    GOLPEAR_IZQUIERDA,
    AGACHAR_IZQUIERDA,   
    MAX_ESTADOS

};

class Personaje {

 public:

    // Constructor

    Personaje(void);


    // Consultoras

    int pos_x(void);
    int pos_y(void);

    estados_personaje estado_actual(void);

    void dibujar(SDL_Surface *pantalla);

    // Modificadoras

    void cambio_estado(estados_personaje status);
    

    void pos_x(int x);
    void pos_y(int y);

    // Modifica la posición del personaje con respecto al eje X

    void avanzar_x(void);
    void retrasar_x(void);

    // Modifica la posición del personaje con respecto al eje Y

    void bajar_y(void);
    void subir_y(void);
   


 private:
    
    // Posición

    int x, y;

    estados_personaje estado;

    // Galería de animaciones

    Animacion *galeria_animaciones[MAX_ESTADOS];
    

};

#endif
