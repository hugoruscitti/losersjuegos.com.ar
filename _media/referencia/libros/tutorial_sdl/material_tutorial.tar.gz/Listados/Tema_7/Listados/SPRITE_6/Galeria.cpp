// Listado: Galeria.cpp
// Implementación de la clase galería del videojuego

#include <iostream>

#include "Galeria.h"
#include "Imagen.h"
#include "Fuente.h"

using namespace std;


Galeria::Galeria() {

    // Cargamos las rejillas en la galería para las animaciones
    // y las imágenes fijas
	
    imagenes[ /* código imagen */ ] = new Imagen( ... );
    
    // Cargamos las fuentes en la galería

    fuentes[ /* código fuente */ ] = new Fuente(...);

}


Imagen *Galeria::imagen(codigo_imagen cod_ima) {

    // Devolvemos la imagen solicitada

    return imagenes[cod_ima];
}


Fuente *Galeria::fuente(codigo_fuente indice) {

    // Devolvemos la fuente solicitada

    return fuentes[indice];
}



Galeria::~Galeria() {

    // Descargamos la galería

    delete imagenes[ /* código */ ];
	...

    delete fuentes[ /* código */];
	...

}
