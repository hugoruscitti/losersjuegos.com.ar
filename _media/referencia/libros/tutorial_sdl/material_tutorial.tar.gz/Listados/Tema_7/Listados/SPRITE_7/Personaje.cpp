// Listado: Personaje.cpp
//
// Implementación de la clase Personaje

#include <iostream>
#include <SDL/SDL_image.h>

#include "Personaje.h"
#include "Animacion.h"

using namespace std;


// Constructor

Personaje::Personaje(void) {

    // Inicializamos las variables

    this->x = 0;
    this->y = 380;

    estado = PARADO_DERECHA;

    galeria_animaciones[PARADO_DERECHA] =
	new Animacion("./Imagenes/jacinto.bmp", 4, 7, "0", 0);
    
    galeria_animaciones[SALTAR_DERECHA] =
	new Animacion("./Imagenes/jacinto.bmp", 4, 7, "21", 0);	

    galeria_animaciones[ANDAR_DERECHA] =
	new Animacion("./Imagenes/jacinto.bmp", 4, 7,\
		      "1,2,3,2,1,0,4,5,6,5,4,0", 18);
	
    galeria_animaciones[GOLPEAR_DERECHA] = 
	new Animacion("./Imagenes/jacinto.bmp", 4, 7, "15", 0);
	
    galeria_animaciones[AGACHAR_DERECHA] =
	new Animacion("./Imagenes/jacinto.bmp", 4, 7, "17", 2);
	
    galeria_animaciones[PARADO_IZQUIERDA] =
	new Animacion("./Imagenes/jacinto.bmp", 4, 7, "7", 0);
	
    galeria_animaciones[SALTAR_IZQUIERDA] =
	new Animacion("./Imagenes/jacinto.bmp", 4, 7, "20", 0);
	
    galeria_animaciones[ANDAR_IZQUIERDA] =
	new Animacion("./Imagenes/jacinto.bmp", 4, 7, "8,9,10,9,8,7,11,12,13,12,11,7", 18);
	
    galeria_animaciones[GOLPEAR_IZQUIERDA] =
	new Animacion("./Imagenes/jacinto.bmp", 4, 7, "14", 0);
	
    galeria_animaciones[AGACHAR_IZQUIERDA] =
	new Animacion("./Imagenes/jacinto.bmp", 4, 7, "16", 2);
	
    
}


// Consultoras

int Personaje::pos_x(void) {

    return x;

}

int Personaje::pos_y(void) {

    return y;

}

estados_personaje Personaje::estado_actual(void) {
    
    return estado;

}

void Personaje::dibujar(SDL_Surface *pantalla) {

    // Según sea el estado del personaje
    // en un momento determinado 
    // dibujaremos una animación u otra
    
    switch(estado) {

     case PARADO:
	 estado = PARADO_DERECHA;
	
     case PARADO_DERECHA:
	galeria_animaciones[PARADO_DERECHA]->paso_a_paso(pantalla, x, y);
	break;

    case SALTAR_DERECHA:
	galeria_animaciones[SALTAR_DERECHA]->paso_a_paso(pantalla, x, y);
	break;

    case ANDAR_DERECHA:
	galeria_animaciones[ANDAR_DERECHA]->paso_a_paso(pantalla, x, y);
	break;

    case GOLPEAR_DERECHA:
	galeria_animaciones[GOLPEAR_DERECHA]->paso_a_paso(pantalla, x, y);
	break;
	
    case AGACHAR_DERECHA:
	galeria_animaciones[AGACHAR_DERECHA]->paso_a_paso(pantalla, x, y);
	break;
	
    case PARADO_IZQUIERDA:
	galeria_animaciones[PARADO_IZQUIERDA]->paso_a_paso(pantalla, x, y);
	break;
	
    case SALTAR_IZQUIERDA:
	galeria_animaciones[SALTAR_IZQUIERDA]->paso_a_paso(pantalla, x, y);
	break;
	
    case ANDAR_IZQUIERDA:
	galeria_animaciones[ANDAR_IZQUIERDA]->paso_a_paso(pantalla, x, y);
	break;
	
    case GOLPEAR_IZQUIERDA:
	galeria_animaciones[GOLPEAR_IZQUIERDA]->paso_a_paso(pantalla, x, y);
	break;
	
    case AGACHAR_IZQUIERDA:
	galeria_animaciones[AGACHAR_IZQUIERDA]->paso_a_paso(pantalla, x, y);
	break;
	 
    default:
	cerr << "Personaje::dibujar()  " << endl;

    } // end switch(estado)


     SDL_Rect rect;

     rect.x = x;
     rect.y = y;

     SDL_BlitSurface(NULL, NULL, pantalla, &rect);
    

}


// Modificadoras

void Personaje::cambio_estado(estados_personaje status) {

    estado = status;

}

void Personaje::pos_x(int x) {

    this->x = x;

}


void Personaje::pos_y(int y) {

    this->y = y;

}

// El movimiento de la imagen se establece
// de 4 en 4 píxeles

void Personaje::avanzar_x(void) {

    x += 6;
}

void Personaje::retrasar_x(void) {

    x -= 6;
}

void Personaje::bajar_y(void) {

    y += 4;

}

void Personaje::subir_y(void) {

    y -= 4;

}
