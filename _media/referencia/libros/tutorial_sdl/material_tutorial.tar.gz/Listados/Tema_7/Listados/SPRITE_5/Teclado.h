// Listado: Teclado.h
//
// Control del dispositivo de entrada


#ifndef _TECLADO_H_
#define _TECLADO_H_

#include <SDL/SDL.h>


const int NUM_TECLAS = 9;


class Teclado {

 public:
    // Constructor
    Teclado();

    // Teclas a usar en la aplicación
    
    enum teclas_configuradas {
	TECLA_SALIR,
	TECLA_SUBIR,
	TECLA_BAJAR,
	TECLA_ACEPTAR,
	TECLA_DISPARAR,
	TECLA_IZQUIERDA,
	TECLA_DERECHA,
	TECLA_SALTAR,
	TECLA_GUARDAR
    };

    // Consultoras
    void actualizar(void);
    bool pulso(enum teclas_configuradas tecla);
		
 private:
    Uint8* teclas;
    SDLKey teclas_configuradas[NUM_TECLAS];
};

#endif
