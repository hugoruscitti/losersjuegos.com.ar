// Listados: main.cpp
//
// Programa de prueba

#include <iostream>
#include <SDL/SDL.h>

#include "Teclado.h"
#include "Personaje.h"

using namespace std;

int main() {

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {

        cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
        exit(1);

    }


    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video

    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {

        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);

    }


    // Establecemos el modo de video

    SDL_Surface *pantalla;

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {

        cerr << "No se pudo establecer el modo de video: "
             << SDL_GetError() << endl;

        exit(1);
    }


    // Teclado para controlar al personaje
    
    Teclado teclado;

    // Cargamos un personaje

    Personaje principal("./Imagenes/jacinto.bmp");


    // Lo mostramos por pantalla
    
    principal.dibujar(pantalla);

    SDL_Flip(pantalla);


    // Variables auxiliares

    SDL_Event evento;
 
    bool terminar = false;

    int x0, y0;

    // Game loop

    while(terminar == false) {

	// Actualizamos el estado del teclado

	teclado.actualizar();

	// Variables de control para saber si 
	// tenemos que refrescar la pantalla o no

	x0 = principal.pos_x();
	y0 = principal.pos_y();

	// Actualización lógica de la posición
       
	if(teclado.pulso(Teclado::TECLA_SUBIR)) {

	    principal.subir_y();

	}

	if(teclado.pulso(Teclado::TECLA_BAJAR)) {

	    principal.bajar_y();

	}

	if(teclado.pulso(Teclado::TECLA_IZQUIERDA)) {

	    principal.retrasar_x();

	}

	if(teclado.pulso(Teclado::TECLA_DERECHA)) {

	    principal.avanzar_x();

	}


	// Si existe modificación dibujamos

	if(x0 != principal.pos_x() || y0 != principal.pos_y()) {
	    
	    cout << "= Posición actual del personaje" << endl;
	    cout << "- X: " << principal.pos_x() << endl;
	    cout << "- Y: " << principal.pos_y() << endl;
	    
	    // Dibujamos al personaje en su posición nueva
	    
	    Uint32 negro = SDL_MapRGB(pantalla->format, 0, 0, 0);
	    
	    SDL_FillRect(pantalla, NULL, negro);
	    
	    principal.dibujar(pantalla);
	    
	    SDL_Flip(pantalla);
	}



	// Control de Eventos

	while(SDL_PollEvent(&evento)) {


	    if(evento.type == SDL_KEYDOWN) {
		
		if(evento.key.keysym.sym == SDLK_ESCAPE)
		    terminar = true;
		
	    }
	    
	    if(evento.type == SDL_QUIT)
		terminar = true;
	    
	}
	
    }

    return 0;

}


