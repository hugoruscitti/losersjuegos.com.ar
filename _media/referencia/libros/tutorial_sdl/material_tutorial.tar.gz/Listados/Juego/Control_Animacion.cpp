// Listado: Control_Animacion.cpp
// Implementación de la clase Control Animacion

#include <iostream>
#include "Control_Animacion.h"
#include "CommonConstants.h"


using namespace std;


Control_Animacion::Control_Animacion(const char *frames, int retardo):
    delay(retardo)
{

    char frames_tmp[MAX_FRAMES];
    char *proximo;
    
    
    strcpy(frames_tmp, frames);

    // Trabajamos con una copia de los cuadros
    // pasados como parámetro

    // Extraemos de la cadena cada uno de los elementos

    for(proximo = strtok(frames_tmp, ","); proximo; ){

	this->cuadros.push_back(atoi(proximo));
	proximo = strtok(NULL, ",\0");
    }

    // Inicializamos las variables de la clase

    this->cuadros.push_back(-1);
    this->paso = 0;
    this->cont_delay = 0;
	
#ifdef DEBUG    
    cout << "Control_Animacion::Control_Animacion()" << endl;
#endif
}


int Control_Animacion::cuadro(void) {

    // Devolvemos el paso actual
    // de la animación

    return cuadros[paso];
}


int Control_Animacion::avanzar(void) {	

    // Si ha pasado el tiempo suficiente 
    // entre cuadro y cuadro

    if((++ cont_delay) >= delay) {

	// Reestablecemos el tiempo a 0

	cont_delay = 0;
	
	// Incrimentamos el paso siempre
	// que no sea el último elemento
	// lo que hará que volvamos al 
	// primer elemento

	if(cuadros[++paso] == -1) {
	    paso = 0;
	    return 1;
	}
    }

    return 0;
}


void Control_Animacion::reiniciar(void) {

    // Volvemos al inicio de la animación

    paso = 0;
    cont_delay = 0;
}


bool Control_Animacion::es_primer_cuadro(void) {

    if(paso == 0)
	return true;

    return false;
}

Control_Animacion::~Control_Animacion() {

#ifdef DEBUG
    cout << "Control_Animacion::~Control_Animacion()" << endl;
#endif
}
