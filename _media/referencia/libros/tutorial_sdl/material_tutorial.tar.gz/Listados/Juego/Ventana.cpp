// Listado: Ventana.cpp
//
// Implementación de la clase ventana

#include <iostream>

 #include "Ventana.h"
 #include "Nivel.h"

 using namespace std;


 Ventana::Ventana(int filas, int columnas) {

     // Inicializamos las variables
     x = y = 0;
     x_final = y_final = 0;

     limite_x = ANCHO_VENTANA * 2 - columnas * TAMANO_BLOQUE;
     limite_y = ALTO_VENTANA * 2 - filas * TAMANO_BLOQUE;
 }



 void Ventana::actualizar(void)
 {
     int incremento_x = x_final - x;
     int incremento_y = y_final - y;

     // Si existe variación

     if(incremento_x != 0) {

	 // Controlamos el movimiento de la ventan
	 if(abs(incremento_x) >= 10)
	     x += incremento_x / 10;   // Reducimos la cantidad de movimiento
	 
	 else // Sobre todo en movimientos pequeños 
	     x += incremento_x / abs(incremento_x);
	                    
     }

     // Si existe variación

     if(incremento_y != 0) {

	 // Animación de movimiento fluida
	 if(abs(incremento_y) >= 10)
	     y += incremento_y / 10; 
	 else
	     y += incremento_y / abs(incremento_y);
     }
 }


// Funciones referentes al posicionamiento

 void Ventana::establecer_pos(int x, int y) {

     x_final = x;
     y_final = y;

     limitar_movimiento();
 }


 void Ventana::tomar_pos_final(int *x, int *y) {

     *x = x_final;
     *y = y_final;
}



void Ventana::tomar_pos(int *x, int *y) {

    *x = this->x;
    *y = this->y;
}


int Ventana::pos_x(void) {
    
    return x;

}

int Ventana::pos_y(void) {

    return y;

}


void Ventana::limitar_movimiento(void) {
    
    // Comprobamos que se cumplen los límites lógicos de pantalla

    if(x_final < 0)
	x_final = 0;
    
    if(y_final < 0)
	y_final = 0;
    
    if(x_final > limite_x)
	x_final = limite_x;
    
    if(y_final > limite_y)
	y_final = limite_y;
}

