// Listado: Imagen.h
//
// Clase para facilitar el trabajo con imágenes

#ifndef _IMAGEN_H_
#define _IMAGEN_H_

#include <SDL/SDL.h>


class Imagen {

 public:

    // Constructor

    Imagen(char *ruta, int filas, int columnas,\
	   int x = 0, int y = 0, bool alpha = false);
    
    void dibujar(SDL_Surface *superficie, int i, int x, int y, int flip = 1);

    // Consultoras

    int pos_x();
    int pos_y();
    
    int anchura();
    int altura();
    int cuadros();
    
    // Destructor 

    ~Imagen();

 private:

    SDL_Surface *imagen;
    SDL_Surface *imagen_invertida;

    // Propiedades de la rejilla de la imagen

    int columnas, filas;

    // Ancho y alto por frame o recuerdo de la animación

    int w, h; 

    // Coordenadas origen

    int x0, y0;
    
    // Rota 180 grado en horizontal

    SDL_Surface * invertir_imagen(SDL_Surface *imagen);
};

#endif
