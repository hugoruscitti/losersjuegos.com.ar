// Listado: Texto.h
//
// Con esta clase controlamos los textos con los que va a trabajar la 
// aplicación


#ifndef _TEXTO_H_
#define _TEXTO_H_

#include <SDL/SDL.h>
#include "CommonConstants.h"

class Fuente;


class Texto {
 public:

    // Constructor

    Texto(Fuente *fuente, int x, int y, char *cadena);

    void dibujar(SDL_Surface *pantalla);
    void actualizar(void);
    
 private:
    
    int x, y;
    
    Fuente *fuente;
    char texto[MAX_TAM_TEXTO];

};

#endif
