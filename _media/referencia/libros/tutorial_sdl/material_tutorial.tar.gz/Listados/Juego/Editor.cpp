// Listado: Editor.cpp
//
// Implementación de la clase esditor

#include <iostream>

#include "Editor.h"
#include "Universo.h"
#include "Nivel.h"
#include "Galeria.h"
#include "Imagen.h"
#include "Teclado.h"
#include "Apuntador.h"
#include "Fuente.h"
#include "Musica.h"
#include "CommonConstants.h"

using namespace std;


// Constructor

Editor::Editor(Universo *universo) : Interfaz(universo) {

#ifdef DEBUG
    cout << "Editor::Editor()" << endl;
#endif

    // Inicializamos los atributos de la clase

    nivel = new  Nivel(universo, FILAS_ZONA_EDITABLE, COLUMNAS_ZONA_EDITABLE);

    // Acciones de teclado en el editor

    teclado = &(universo->teclado); 

    // Apuntador del ratón para el editor

    apuntador = new  Apuntador(this);

    barra_scroll_ = 0;
    x = 0;
    y = 0;
	
    // Imagen con los tiles para el editor

    imagen = universo->galeria->imagen(Galeria::TILES);
}

void Editor::reiniciar(void) { 
    
    // Hacemos sonar la música

    universo->galeria->musica(Galeria::MUSICA_EDITOR)->pausar();   
    universo->galeria->musica(Galeria::MUSICA_EDITOR)->reproducir();

}



void Editor::actualizar(void)
{

    // Mueve la ventana a la posición correspondiente

    mover_ventana();

    // Actualiza los elementos del Editor

    nivel->actualizar();

    // Actualiza la posición del puntero del ratón

    apuntador->actualizar();

    // Si se pulsa la tecla de salida se vuelve al menú

    if(teclado->pulso(Teclado::TECLA_SALIR))
	universo->cambiar_interfaz(ESCENA_MENU);
}


void Editor::mover_barra_scroll(int desplazamiento) {

    // Incrementamos la posición de la barra

    barra_scroll_ = barra_scroll_ + desplazamiento;

    // Dentro de los parámetros permitidos

    if(barra_scroll_ < 0)
	barra_scroll_ = 0;
    
    if(barra_scroll_ > 5)
	barra_scroll_ = 5;
}


int Editor::barra_scroll(void) {

    return (barra_scroll_);
}


Editor::~Editor() {

    delete nivel;
    delete apuntador;

#ifdef DEBUG
    cout << "Editor::~Editor() " << endl;
#endif

}


void Editor::mover_ventana(void) {

    int x0 = x;
    int y0 = y;

    // Según la pulsación de la tecla movemos la ventana de la aplicación
    // en un sentido un otro
    
    if(teclado->pulso(Teclado::TECLA_IZQUIERDA))
	x -= 20;

    else if(teclado->pulso(Teclado::TECLA_DERECHA))
	x += 20;

    else if(teclado->pulso(Teclado::TECLA_BAJAR))
	y += 20;

    else if(teclado->pulso(Teclado::TECLA_SUBIR))
	y -= 20;
    
    // Si existe movimiento

    if(x != x0 || y != y0) {

	nivel->ventana->establecer_pos(x, y);
	nivel->ventana->tomar_pos_final(&x, &y);

    }
}



void Editor::dibujar(void)
{
    // Dibuja todos los elementos del editor
    
    nivel->dibujar(universo->pantalla);
    nivel->dibujar_actores(universo->pantalla);

    // Mostramos el menú

    dibujar_menu();

    apuntador->dibujar(universo->pantalla); // Mostramos el puntero del ratón
    dibujar_numero_nivel(); // Mostramos el número del nivel actual


    // Actualizamos la pantalla 

    SDL_Flip(universo->pantalla);
}



void Editor::dibujar_menu(void) {

    int i, j;

    // Fondo
    
    universo->dibujar_rect(544, 0, 96, 480,\
			   SDL_MapRGB(universo->pantalla->format, 25, 10, 50));
    
    imagen->dibujar(universo->pantalla, 48, 544, 0);
    imagen->dibujar(universo->pantalla, 49, 576, 0);
    imagen->dibujar(universo->pantalla, 50, 608, 0);
 
    imagen->dibujar(universo->pantalla, 54, 544, 32);
    imagen->dibujar(universo->pantalla, 55, 576, 32);
    imagen->dibujar(universo->pantalla, 56, 608, 32);

    // Flechas para el scrolling

    imagen->dibujar(universo->pantalla, 51, 576, 92);
    imagen->dibujar(universo->pantalla, 52, 576, 448);

    // Elementos

    for(i = 0; i < 10; i ++) {
	for(j = 0; j < 3 ; j ++) {

	    imagen->dibujar(universo->pantalla,
			    (i + barra_scroll_) * 3 + j,
			    544 + j * 32, 96 + 32 + i * 32);
	}
    }
}


void Editor::dibujar_numero_nivel(void) {

    char numero_aux[20];
    
    Fuente *fuente = universo->galeria->fuente(Galeria::FUENTE_MENU);
    
    sprintf(numero_aux, "Nivel - %d", nivel->indice());
    
    fuente->dibujar(universo->pantalla, numero_aux, 10, 10);
}


