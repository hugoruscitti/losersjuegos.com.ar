// Listado:Texto.cpp
//
// Implementación de la clase Texto

#include <iostream>

#include "Fuente.h"
#include "Control_Movimiento.h"
#include "Texto.h"

using namespace std;


Texto::Texto(Fuente *fuente, int x, int y, char *cadena) {

#ifdef DEBUG
    cout << "Texto::Texto()" << endl;
#endif

    // Iniciamos las variables

    this->fuente = fuente;
    this->x = x;
    this->y = y;

    // Copiamos la cadena a nuestro texto

    strcpy(texto, cadena);

}


void Texto::dibujar(SDL_Surface * pantalla) {

    // Dibujamos el texto en pantalla

    fuente->dibujar(pantalla, texto, x, y);
}


void Texto::actualizar(void) {

    // No realiza ninguna acción en particular
}
