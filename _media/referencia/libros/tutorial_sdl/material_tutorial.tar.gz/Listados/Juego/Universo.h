// Listado: Universo.h
//
// Nos permite cohesionar todas las clases de la aplicación y
// nos permite llevar un control global sobre la misma


#ifndef _UNIVERSO_H_
#define _UNIVERSO_H_

#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>

#include "Teclado.h"
#include "Interfaz.h"


// Declaraciones adelantadas

class Galeria;
class Juego;
class Editor;
class Menu;


class Universo {

 public:
    
    // Constructor

    Universo();


    // Proporciona la "reproducción continua"

    void bucle_principal(void);
    

    // Nos permite el cambio entre "opciones" del juego

    void cambiar_interfaz(Interfaz::escenas nueva);


    // Dibuja un rectángulo en pantalla

    void dibujar_rect(int x, int y, int w, int h, Uint32 color = 0);


    // Finaliza el juego

    void terminar(void);
    
    ~Universo();// Destructor 
    

    Teclado teclado;  // Controla el dispositivo de entrada
    Galeria *galeria; // Almacena todas las imágenes necesarias
    SDL_Surface *pantalla; // Superficie principal del videojuego


 private:

    // Escena en la que estamos
    
    Interfaz *actual;


    // Pantallas del juego
    
    Juego *juego;
    Editor *editor;
    Menu *menu;

    // Variable que modificamos cuando queremos salir de la aplicación

    bool salir;
    
    void iniciar_ventana(bool fullscreen);
    void pantalla_completa(void);


    // Estudia los eventos en un momento dado

    int procesar_eventos(void);
    
    // Lleva el control del tiempo

    int sincronizar_fps(void);
};

#endif 
