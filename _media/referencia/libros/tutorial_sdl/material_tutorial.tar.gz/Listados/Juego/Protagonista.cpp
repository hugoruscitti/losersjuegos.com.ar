// Listado: Protagonista
//
// Implementación de la clase Protagonista

#include <iostream>

#include "Protagonista.h"
#include "Juego.h"
#include "Teclado.h"
#include "Galeria.h"
#include "Sonido.h"
#include "Universo.h"
#include "Nivel.h"
#include "Imagen.h"
#include "Control_Animacion.h"


using namespace std;


Protagonista::Protagonista(Juego *juego, int x, int y, int direccion):
    Participante(juego, x, y, direccion)
{

#ifdef DEBUG
    cout << "Protagonista::Protagonista()" << endl;
#endif

    // Inicializamos los atributos de la clase

    this->juego = juego;
    this->teclado = &(juego->universo->teclado);
	
    imagen = juego->universo->galeria->imagen(Galeria::PERSONAJE_PPAL);

    // Asociamos al personaje las animaciones
    // según la rejilla que cargamos para controlarlo

    animaciones[PARADO] = new Control_Animacion("0", 5);
    animaciones[CAMINAR] = new Control_Animacion("1,2,3,2,1,0,4,5,6,5,4,0", 6);
    animaciones[SALTAR] = new Control_Animacion("21,19", 0);
    animaciones[GOLPEAR] = new Control_Animacion("15", 20);
    animaciones[MORIR] = new Control_Animacion("22, 23, 23, 24, 25, 23, 25", 10);
    
    x0 = x;
    y0 = y;
    
    reiniciar();
}



void Protagonista::actualizar(void) {

    // Establecemos la posición de l a ventana

    juego->nivel->ventana->establecer_pos(x - 320, y - 240);

    // Si no estamos en el mismo estado 

    if(estado != estado_anterior) {
	
	// Comenzamos la animación y guardamos el estado

	animaciones[estado]->reiniciar();
	estado_anterior = estado; 
    }

    // Implementación del autómata
    // Según sea el estado

    switch(estado) {

     case PARADO:

	 estado_parado();
	 break;
	 
     case CAMINAR:

	 estado_caminar();
	 break;
	 
     case GOLPEAR:

	 estado_disparar();
	 break;
	 
     case SALTAR:

	 estado_saltar();
	 break;

     case MORIR:

	 estado_morir();
	 break;
			
     default:
	 cout << "Estado no contemplado" << endl;
	 break;
    }
    
}

void Protagonista::colisiona_con(Participante *otro) {

    if(estado != MORIR) {

	juego->universo->\
	    galeria->sonidos[Galeria::MUERE_BUENO]->reproducir();

	estado = MORIR;             // Muere el personaje
	velocidad_salto = -5;       // Hace el efecto de morir
    }
}


void Protagonista::reiniciar(void) {
    
    // Reestablecemos el personaje
    
    x = x0;
    y = y0;
    direccion = 1;
    
    estado = PARADO;
    velocidad_salto = 0;
    estado_anterior = estado;
}


// Destructor

Protagonista::~Protagonista()
{

#ifndef DEBUG
    cout << "Protagonista::~Protagonista()" << endl;
#endif 

}

// Funciones que implementan el diagrama de estados

void Protagonista::estado_parado(void) {

    // Estando parado podemos realizar las 
    // siguientes acciones
    
    if(teclado->pulso(Teclado::TECLA_IZQUIERDA)) {

	direccion = -1;
	estado = CAMINAR;

    }

    if(teclado->pulso(Teclado::TECLA_DERECHA)) {

	direccion = 1;
	estado = CAMINAR;

    }

    if(teclado->pulso(Teclado::TECLA_GOLPEAR))
	estado = GOLPEAR;

    if(teclado->pulso(Teclado::TECLA_SALTAR)) {

	velocidad_salto = -5;
	estado = SALTAR;

    }
}



void Protagonista::estado_caminar(void) {

    // Acciones que podemos realizar
    // mientras caminamos

    animaciones[estado]->avanzar();
    
    mover_sobre_x(direccion * 2);
	
    if(direccion == 1 && ! teclado->pulso(Teclado::TECLA_DERECHA))
	estado = PARADO;
    
    if(direccion == -1 && ! teclado->pulso(Teclado::TECLA_IZQUIERDA))
	estado = PARADO;
    
    if(teclado->pulso(Teclado::TECLA_GOLPEAR))
	estado = GOLPEAR;
    
    if(teclado->pulso(Teclado::TECLA_SALTAR)) {

	velocidad_salto = -5;
	estado = SALTAR;

    }

    if(!pisa_el_suelo()) {

	velocidad_salto = 0;
	estado = SALTAR;

    }
}


void Protagonista::estado_disparar(void) {

    // Cuando golpeamos nos detenemos

    if(animaciones[estado]->avanzar())
	estado = PARADO;

}



void Protagonista::estado_saltar(void) {

    // Acciones que podemos realizar al saltar

    velocidad_salto += 0.1;
    
    if(teclado->pulso(Teclado::TECLA_IZQUIERDA)) {

	direccion = -1;
	mover_sobre_x(direccion * 2);

    }
    
    if(teclado->pulso(Teclado::TECLA_DERECHA)) {

	direccion = 1;
	mover_sobre_x(direccion * 2);

    }

    
    // Cuando la velocidad cambia de signo empezamos a caer

    if(velocidad_salto > 0.0) {

	y += altura((int) velocidad_salto);
	
	if(animaciones[estado]->es_primer_cuadro())
	    animaciones[estado]->avanzar();
		
	if(velocidad_salto >= 1.0 && pisa_el_suelo())
	    estado = PARADO;

	if(y > ALTO_VENTANA * 2) {
	    estado = MORIR;
	    velocidad_salto = -5;
	}
    }
    else {

	y += (int) velocidad_salto;

    }
}


void Protagonista::estado_morir(void) {

    // Morimos

    velocidad_salto += 0.1;
    y += (int) velocidad_salto;
    
    mover_sobre_x(direccion * 2 * - 1);
    
    animaciones[estado]->avanzar();
    
    if(y > ALTO_VENTANA * 2 + 300) // Salimos de la pantalla
	reiniciar();
}
