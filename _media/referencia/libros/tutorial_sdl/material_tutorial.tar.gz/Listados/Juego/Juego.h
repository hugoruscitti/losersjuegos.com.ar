// Listado: Juego.h
//
// Esta clase hija de interfaz nos permite relacionar el control del juego
// con los niveles para cohesionar los módulos

#ifndef _JUEGO_H_
#define _JUEGO_H_

#include <SDL/SDL.h>
#include "Interfaz.h"

// Declaración adelantada

class Universo;
class Control_Juego;
class Nivel;

class Juego : public Interfaz {

 public:

    // Constructor

    Juego(Universo *universo);
    
    // Funciones heradadas

    void reiniciar(void);
    void actualizar(void);
    void dibujar(void);
    
    Control_Juego *control_juego;
    Nivel *nivel;

    // Destructor
    ~Juego();
};

#endif
