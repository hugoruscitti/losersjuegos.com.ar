// Listado: Menu.cpp
//
// Implementación de la clase Menu

#include <iostream>

#include "Menu.h"
#include "Universo.h"
#include "Galeria.h"
#include "Imagen.h"
#include "Sonido.h"
#include "Teclado.h"
#include "Control_Movimiento.h"
#include "Fuente.h" 
#include "Texto.h"
#include "Musica.h"


using namespace std;


Menu::Menu(Universo *universo) : Interfaz(universo) {

#ifdef DEBUG
    cout << "Menu::Menu()" << endl;
#endif
    
    // El dispositivo de entrada nos lo da el entorno del juego

    teclado = &(universo->teclado);


    // Cargamos el título del juego

    imagen = universo->galeria->imagen(Galeria::MENU);
    
    x = y = opcion = 0;

    
    // Cargamos el cursor de selección

    cursor = new Control_Movimiento(universo->galeria->imagen(Galeria::TILES), 50, 100, 300);


    // Creamos los títulos

    crear_titulos();

    // Creo las cadenas de las opciones

    crear_cadenas();
    
    // Inicio el Menu

    reiniciar();
}


void Menu::reiniciar(void) {

    // Hacemos sonar la música

    universo->galeria->musica(Galeria::MUSICA_MENU)->pausar();   
    universo->galeria->musica(Galeria::MUSICA_MENU)->reproducir();
    

    // Colocamos cada parte del título en su lugar
    // Desde una posición de origen hasta la posición final

    titulo_tutorial->mover_inmediatamente(100, -250);
    titulo_tutorial->mover(100,110);
    
    titulo_firma->mover_inmediatamente(640, 200);
    titulo_firma->mover(400, 200);
}


void Menu::actualizar(void) {

    static int delay = 0; // Variable con "memoria"
	
    // Actualizamos el cursor seleccionador

    cursor->actualizar();
    
    // Actualizamos los títulos

    titulo_tutorial->actualizar();
    titulo_firma->actualizar();
    
    // Si pulsamos abajo y no estamos en la última
    // (controlamos no ir excesivamente rápido)

    if(teclado->pulso(Teclado::TECLA_BAJAR) && opcion < 2 && delay == 0) {

	delay = 30;                            // Retardo de 30 ms
	opcion++;                              // Bajamos -> opcion = opcion + 1          
	cursor->mover(100, 300 + 50 * opcion); // Movemos el cursor

	// Reproducimos un efecto de sonido
	
	universo->galeria->sonidos[Galeria::EFECTO_MENU]->reproducir();

    }

    // Si pulsamos arriba y no estamos en la primera opción

    if(teclado->pulso(Teclado::TECLA_SUBIR) && opcion > 0 && delay == 0) {

	delay = 30;                            // Retardo de 30 ms
	opcion--;                              // Subimos -> opcion = opcion - 1
	cursor->mover(100, 300 + 50 * opcion); // Movemos el cursor

	// Reproducimos un efecto de sonido

	universo->galeria->sonidos[Galeria::EFECTO_MENU]->reproducir();

    }


    if(delay) // Reducimos el retardo
	delay--;
	

    // Si aceptamos

    if(teclado->pulso(Teclado::TECLA_ACEPTAR)) { 
	
	// Entramos en una opción determinada
	
	switch(opcion) {

	case 0: // Jugar

	     universo->cambiar_interfaz(ESCENA_JUEGO);
	     break;

	 case 1: // Editar niveles

	     universo->cambiar_interfaz(ESCENA_EDITOR);
	     break;

	 case 2: // Salir de la aplicación

	     universo->terminar();
	     break;
	}
    }
}



void Menu::dibujar(void) {

    // Dibujamos un rectángulo de fondo con el color anaranjado

    SDL_FillRect(universo->pantalla, NULL,\
		 SDL_MapRGB(universo->pantalla->format, 161, 151, 240));

    // Dibujamos el cursor que selecciona una opción u otra

    cursor->dibujar(universo->pantalla);

    // Dibujamos los títulos

    titulo_tutorial->dibujar(universo->pantalla);
    titulo_firma->dibujar(universo->pantalla);
    
    // Dibujamos las 3 cadenas de opciones

    for(int i = 0; i < NUM_OPCIONES; i ++)
	cadena_opciones[i]->dibujar(universo->pantalla);
    
    // Actualizamos la pantalla del entorno

    SDL_Flip(universo->pantalla);
}


Menu::~Menu() {

#ifdef DEBUG
    cout << "Menu::~Menu()" << endl;
#endif
    
    // Liberamos memoria

    delete cursor;
    delete titulo_tutorial;
    delete titulo_firma;

    
    // Tamabién de las cadenas

    for(int i = 0; i < NUM_OPCIONES; i ++)
	delete cadena_opciones[i];

}


void Menu::crear_cadenas(void) {

    // Crea las cadenas que mostraremos como opciones

    char textos[][20] = { {"Jugar"}, {"Editar niveles"}, {"Salir"} };


    // Cargamos la fuente

    Fuente *fuente = universo->galeria->fuente(Galeria::FUENTE_MENU);
    

    // La amacenamos en el vector de tipo Texto

    for(int i = 0; i < NUM_OPCIONES; i ++) {

	cadena_opciones[i] = new Texto(fuente, 150, 300 + i * 50, textos[i]);
    }
}



void Menu::crear_titulos(void) {

    // Creamos los títulos animados

    titulo_tutorial = 
	new Control_Movimiento(universo->galeria->imagen(Galeria::TITULO_TUTORIAL),\
					   0, 300, 200);

    titulo_firma =
	new Control_Movimiento(universo->galeria->imagen(Galeria::TITULO_FIRMA),\
					  0, 300, 400);
}
