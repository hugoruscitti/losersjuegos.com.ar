// Listado: Editor.h
//
// Controla las características del editor de niveles

#ifndef _EDITOR_H_
#define _EDITOR_H_

#include <SDL/SDL.h>
#include "Interfaz.h"

// Declaraciones adelantadas

class Universo;
class Nivel;
class Teclado;
class Imagen;
class Apuntador;

// Definición de la clase

class Editor: public Interfaz {

 public:

    // Constructor

    Editor(Universo *universo);

    // Acciones de la clase
    
    void reiniciar(void);
    void actualizar(void);
    void dibujar(void);
    
    // Barra de menú

    void mover_barra_scroll(int incremento);
    int barra_scroll(void);

    // Destructor

    ~Editor();
    
    Nivel *nivel;
    Teclado *teclado;
    Imagen *imagen;
    
 private:

    int x, y;
    int barra_scroll_;
    
    Apuntador *apuntador;
    
    void mover_ventana(void);
    void dibujar_menu(void);
    void dibujar_numero_nivel(void);
};

#endif 
