// Listado: Nivel.h
//
// Esta clase controla todo lo relevante a la construcción
// de los nivel del juego

#ifndef _NIVEL_H_
#define _NIVEL_H_

#include <SDL/SDL.h>
#include "Ventana.h"
#include "CommonConstants.h"

class Ventana;
class Imagen;
class Universo;
class Control_Juego;

class Nivel {

 public:
    
    // Constructor (al menos el tamaño de una ventana)

    Nivel(Universo *universo,\
	  int filas = FILAS_VENTANA, int columnas = COLUMNAS_VENTANA);


    // Funciones de dibujo

    void dibujar(SDL_Surface *superficie);
    void dibujar_actores(SDL_Surface *superficie);

    // Actualizando el nivel

    void actualizar(void);
    int altura(int x, int y, int rango);

    // Comprueba si el elemento es traspasable

    bool no_es_traspasable(char codigo);
    
    // Pasa al nivel siguiente o al anterior

    void siguiente(void);
    void anterior(void);

    // Funciones para la edición del nivel

    void editar_bloque(int i, int x, int y);
    void guardar(void);
    int cargar(void);
    void limpiar(void);

    // Devuelve el número de nivel

    int indice(void);
    
    // Genera los actores que participan en el nivel

    void generar_actores(Control_Juego *procesos);
    
    // Foco de la acción

    Ventana *ventana;

    // Destructor

    ~Nivel();
    
 private:

    int numero_nivel;
    int filas, columnas;

    // indica si este nivel ha sido editado

    bool modificado;

    // Almacena las características del nivel

    char mapa[FILAS_NIVEL][COLUMNAS_NIVEL];

    // Para guardar el nivel

    FILE *fichero;
    
    Imagen *bloques;
    Universo *universo;
    
    // Funciones para el manejo de ficheros

    void abrir_fichero(void);
    void cerrar_fichero(void);
    FILE *crear_fichero(void);
    void copiar_fichero(FILE *tmp);
};

#endif 
