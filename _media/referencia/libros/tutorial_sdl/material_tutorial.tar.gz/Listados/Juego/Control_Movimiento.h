// Listado: Control_Movimiento.h
//
// La clase Control Movimiento controla la animación externa de los personajes
// lo que es lo mismo, el movimiento sobre el mapa del nivel


#ifndef _CONTROL_MOVIMIENTO_H_
#define _CONTROL_MOVIMIENTO_H_

#include <SDL/SDL.h>


class Imagen; // Declaración adelantada


class Control_Movimiento {

 public:
    //Constructor

    Control_Movimiento(Imagen *imagen, int indice = 0, int x = 0, int y = 0);

    // Modificadoras

    void actualizar(void);
    void dibujar(SDL_Surface *pantalla);

    void mover(int x, int y);
    void mover_inmediatamente(int x, int y);
    
 private:
    
    // Posición
    int x, y;

    // Destino
    int x_destino, y_destino;

    // Dentro de la rejilla especificamos qué imagen
    int indice;

    // Rejilla de imágenes
    Imagen *imagen;

};

#endif
