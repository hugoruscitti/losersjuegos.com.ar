// Listado: Galeria.h
//
// Controla los elementos multimedia de la aplicación

#ifndef _GALERIA_H_
#define _GALERIA_H_

#include <map>
#include "CommonConstants.h"


// Declaración adelantada

class Imagen;
class Fuente;
class Musica;
class Sonido;


using namespace std;

class Galeria {

 public:

    // Tipos de imágenes contenidas en la galería

    enum codigo_imagen {

	TILES,
	PERSONAJE_PPAL,
	ENEMIGO_RATA,
	ENEMIGO_MOTA,
	MENU,
	TITULO_TUTORIAL, 
	TITULO_FIRMA,
	ITEM_ALICATE,
	ITEM_DESTORNILLADOR
    };

    // Fuentes almacenadas en la galería

    enum codigo_fuente {
	
	FUENTE_MENU
    };

    enum codigo_musica { 

	MUSICA_MENU,
	MUSICA_EDITOR,
	MUSICA_JUEGO

    };

    enum codigo_sonido {

	COGE_ITEM,
	MATA_MALO,
	PASA_NIVEL,
	EFECTO_MENU,
	MUERE_BUENO

    };
	


    // Constructor

    Galeria ();

    // Consultoras		
 
    Imagen *imagen(codigo_imagen cod_ima);
    Fuente *fuente(codigo_fuente indice);
    Musica *musica(codigo_musica cod_music);
    Sonido *sonido(codigo_sonido cod_sonido);

    ~Galeria();

    // Conjunto de imágenes y de fuentes
    // que vamos a utilizar en la aplicación

    map<codigo_imagen, Imagen *> imagenes;
    map<codigo_fuente, Fuente *> fuentes;
    map<codigo_musica, Musica *> musicas;
    map<codigo_sonido, Sonido *> sonidos;
};

#endif
