// Listado: Control_Movimiento.cpp
//
// Implementación de la clase Control Movimiento


#include <iostream>

#include "Control_Movimiento.h"
#include "Imagen.h"

using namespace std;

Control_Movimiento::Control_Movimiento(Imagen *imagen, int indice, int x, int y) {

    // Inicializamos los atributos de la clase

    this->imagen = imagen;
    this->x = x;
    this->y = y;
    x_destino = x;
    y_destino = y;
    this->indice = indice;
    
#ifdef DEBUG
    cout << "Control_Movimiento::Control_Movimiento()" << endl;
#endif
}


void Control_Movimiento::actualizar(void) {

    // Actualización de la posición del elemento

    int dx = x_destino - x;
    int dy = y_destino - y;
    
    // Si hay movimiento
    
    if(dx != 0) {
	
	// Controlamos la precisión del movimiento
	
	if(abs(dx) >= 4) // Si es mayor o igual que 4
	    x += dx / 4; // la reducimos
	else
	    x += dx / abs(dx); // Si es menor, reducimos a 1
    }

    if(dy != 0)	{

	// Ídem para el movimiento vertical

	if(abs(dy) >= 4)
	    y += dy / 4;
	else
	    y += dy / abs(dy);
    }
}



void Control_Movimiento::dibujar(SDL_Surface *pantalla) {

    imagen->dibujar(pantalla, indice, x, y, 1);
}



void Control_Movimiento::mover(int x, int y) {

    // Este movimiento es actualizado por la función actualizar()
    // de esta clase con la precisión que tenemos implementada
    // en ella

    x_destino = x;
    y_destino = y;
}


void Control_Movimiento::mover_inmediatamente(int x, int y) {

    // Esta función nos permite hacer un movimiento inmediato
    // a una determinada posición

    mover(x,y);
    this->x = x;
    this->y = y;
}
