// Listado: Juego.cpp
//
// Implementación de la clase juego

#include <iostream>

#include "Participante.h"
#include "Juego.h"
#include "Universo.h"
#include "Nivel.h"
#include "Control_Juego.h"
#include "Galeria.h"
#include "Imagen.h"
#include "Musica.h"


using namespace std;


Juego::Juego(Universo *universo): Interfaz(universo) {

#ifdef DEBUG
    cout << "Juego::Juego()" << endl;
#endif

    nivel = NULL;
    control_juego = NULL;

    // Iniciamos el juego

    reiniciar();
}


void Juego::reiniciar(void) {

    // Hacemos sonar la música

    universo->galeria->musica(Galeria::MUSICA_JUEGO)->pausar();   
    universo->galeria->musica(Galeria::MUSICA_JUEGO)->reproducir();

    // Si se ha iniciado el juego
    // Eliminamos los datos anteriores (restauramos)

    if(control_juego != NULL)
	delete control_juego;
    
    if(nivel != NULL)
	delete nivel;
    
    // Generamos de nuevo el entorno del juego

    control_juego = new Control_Juego(this);
    nivel = new Nivel(universo);

    nivel->generar_actores(control_juego);
 
#ifdef DEBUG
    cout << "Juego::reiniciado" << endl;
#endif
}


void Juego::actualizar(void) {

    // Si pulsamos la tecla de salir, salimos al menu

    if(universo->teclado.pulso(Teclado::TECLA_SALIR))
	universo->cambiar_interfaz(ESCENA_MENU);

    // Actualizamos la posición de la ventana

    nivel->actualizar();

    // Actualizamos el estado de los items,
    // enemigos y el personaje principal

    control_juego->actualizar();
}



void Juego::dibujar(void) {

    // Dibujamos en la superficie principal

    // El nivel

    nivel->dibujar(universo->pantalla);

    // Los personajes, items y enemigos

    control_juego->dibujar(universo->pantalla);

    // Actualizamos la pantalla

    SDL_Flip(universo->pantalla);
}


Juego::~Juego() {
    
    // Liberamos la memoria
    delete control_juego;
    delete nivel;

#ifdef DEBUG
    cout << "Juego::~Juego()" << endl;
#endif
}
