// Listado: main.cpp
//
// Contiene la función principal
// Arrancamos el juego

#include <iostream>
#include "Universo.h"


using namespace std;


int main(int argc, int *argv[]) {

    Universo universo;

    universo.bucle_principal();
    
    return 0;
}
