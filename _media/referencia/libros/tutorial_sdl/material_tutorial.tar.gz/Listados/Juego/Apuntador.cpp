// Listado: Apuntador.cpp
//
// Implementación de la clase Apuntador

#include "CommonConstants.h"
#include "Apuntador.h"
#include "Nivel.h"
#include "Imagen.h"
#include "Editor.h"
#include "Universo.h"



// Constructor

Apuntador::Apuntador(Editor * editor):
    x(0), y(0), bloque_actual(0), imagen_rejilla(IMAGEN_PUNTERO){

    
    // Asociamos el apuntador con el editor

    this->editor = editor;
}



void Apuntador::dibujar(SDL_Surface *pantalla){

    // Dibujamos el apuntador en su posición actual

    editor->imagen->dibujar(pantalla, imagen_rejilla, x, y, 1);
}



int Apuntador::pos_x(void) {

    return x;
}


int Apuntador::pos_y(void) {
    
    return y;
}

void Apuntador::actualizar(void)
{
    // Para mantener pulsado el botón del ratón    

    static bool pulsado = false; 

    // Consultamos el estado del ratón

    botones = SDL_GetMouseState(&x, &y);

    // Pulsar sobre la rejilla y algún botón

    if(x < BARRA_HERRAMIENTAS)

	// Pulsa sobre la superficie que define el nivel

	pulsa_sobre_rejilla(botones);

    else {

	// Pulsa en la barra de herramientas
	
	if(botones == SDL_BUTTON(1)) {
	    if(!pulsado) {

		pulsa_sobre_barra(botones);
		pulsado = true;

	    }
	}
	else
	    pulsado = false;
    }
}


void Apuntador::pulsa_sobre_rejilla(int botones)
{
    // Con el botón derecho eliminamos el elemento (-1)
    
    if(botones == SDL_BUTTON(3))
	editor->nivel->editar_bloque(-1, x, y);
    

    // Con el izquierdo colocamos el nuevo elemento
    
    if(botones == SDL_BUTTON(1))
	editor->nivel->editar_bloque(bloque_actual, x, y);
}


void Apuntador::pulsa_sobre_barra(int botones)
{
    int fila = y / TAM_TITLE;
    int columna = (x / TAM_TITLE) - 17; // Varía la escala


    // Acciones segúna la pulsación en pantalla

    if(fila == 0) {

	switch(columna) {
	    
	    // Primera fila

	 case 0:

	     // Flecha anterior

	     editor->nivel->anterior();
	     break;
	     
  	 case 1:
	    
	     // Icono de guardar

	     editor->nivel->guardar();
	     break;
	     
	     
	 case 2:

	     // Flecha de siguiente

	     editor->nivel->siguiente();
	     break;
	}
    }

    if(fila == 1) {

	switch(columna) {

	 case 0:	

	     // Recarga el nivel

	     editor->nivel->cargar();
	     break;

	 case 1:

	     // Sale del editor

	     editor->universo->cambiar_interfaz(Interfaz::ESCENA_MENU);
	     break;

	case 2:

 	     // Limpia la escena

	     editor->nivel->limpiar();
	     break;
	}
    }
	
    // Desplazamiento del scroll

    if(fila == 3 && columna == 1) {

	editor->mover_barra_scroll(-1);
	return;

    }

    if(fila == 14 && columna == 1) {

	editor->mover_barra_scroll(+1);
	return;
    }

    if(fila > 3 && fila < 14)
	
	// Bloque según el icono que pulsemos 
	// en el scroll

	bloque_actual = (fila - 4) * 3 + 
	    editor->barra_scroll() * 3  +
	    columna;
	
}
