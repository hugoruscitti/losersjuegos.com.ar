// Listado: Enemigo.h
//
// Clase Enemigo, heredada de Participante, para el control
// de los adversarios del juego

#ifndef _ENEMIGO_H_
#define _ENEMIGO_H_

#include "Participante.h"

class Juego;

class Enemigo : public Participante {

 public:
    
    // Constructor

    Enemigo(enum tipo_participantes tipo, Juego *juego, int x, int y, int flip = 1);

    // Modificadora

    void actualizar(void);

    // Consultora

    void colisiona_con(Participante *otro);

    virtual ~Enemigo();

};


#endif
