// Listado: Control_Juego.h
//
// La clase Control Juego proporcina un mando lógico sobre el juego
//


#ifndef _CONTROL_JUEGO_H_
#define _CONTROL_JUEGO_H_

#include <SDL/SDL.h>
#include <list>
#include "Participante.h"


// Declaración adelantada 

class Protagonista;
class Enemigo;
class Item;
class Juego;


using namespace std;


class Control_Juego {

 public:
    
    // Constructor

    Control_Juego(Juego *juego);
    
    // Para realizar la actualización lógica 
    // y poder mostrar el resultado en pantalla
    
    void actualizar(void);
    void dibujar(SDL_Surface *pantalla);
    
    Juego *juego;
    
    // Nos permiten establecer a los participantes
    // del juego en el universo del juego

    void enemigo(Participante::tipo_participantes tipo, int x, int y, int flip);
    void protagonista(int x, int y, int flip);
    void item(Participante::tipo_participantes tipo, int x, int y, int flip);
    
    // Destructor

    ~Control_Juego();

 private:

    void avisar_colisiones(void);

    // Galería de personajes y objetos del juego
    
    Protagonista *protagonista_;
    list<Enemigo *> lista_enemigos;
    list<Item *> lista_items;

    // Detección de colisiones
    
    bool hay_colision(int x0, int y0, int x1, int y1, int radio);

    void eliminar_antiguos_items(list<Item *>& lista);
    void eliminar_antiguos_enemigos(list<Enemigo *>& lista);
};

#endif
