// Listado: Participante.cpp
//
// Implementación de la clase Participante


#include <iostream>

#include "Participante.h"
#include "Juego.h"
#include "Nivel.h"
#include "Control_Animacion.h"
#include "Imagen.h"

using namespace std;


Participante::Participante(Juego *juego, int x, int y, int direccion)
{

#ifdef DEBUG
    cout << "Participante::Participante()" << endl;
#endif

    // Inicializamos las variables

    this->juego = juego;
    this->direccion = 1;
    this->x = x;
    this->y = y;
    velocidad_salto = 0.0;
}


int Participante::pos_x(void) {
    
    return x;
};


int Participante::pos_y(void) {
    return y;
};


Participante::~Participante() {

#ifdef DEBUG
    cout << "Participante::~Participante()" << endl;
#endif

}

void Participante::mover_sobre_x(int incremento) {

    if(incremento > 0) {
	if(x < ANCHO_VENTANA * 2 - 30)
	    x += incremento;
    }
    else {
	if(x > 30)
	    x += incremento;
    }
}


int Participante::altura(int rango) {

	return juego->nivel->altura(x, y, rango);
}



bool Participante::pisa_el_suelo(void) {

	if(altura(1) == 0)
		return true;
	else
		return false;
}


bool Participante::pisa_el_suelo(int _x, int _y) {
    
    if(juego->nivel->altura(_x, _y, 1) == 0)
	return true;
    else
	return false;

}


void Participante::dibujar(SDL_Surface *pantalla) {

    imagen->dibujar(pantalla, animaciones[estado]->cuadro(),\
		    x - juego->nivel->ventana->pos_x(),\
		    y - juego->nivel->ventana->pos_y(), direccion);
}


