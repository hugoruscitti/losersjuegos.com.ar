// Listado: Control_Animacion.h
// Esta clase controla la secuencia de animación de los personajes de la 
// aplicación

#ifndef _CONTROL_ANIMACION_H_
#define _CONTROL_ANIMACION_H_

#include <vector>

using namespace std;

class Control_Animacion {
 public:
    
    // Constructor
    Control_Animacion(const char *frames, int retardo);

    // Consultoras
    int cuadro(void);
    bool es_primer_cuadro(void);
    
    // Modificadoras
    int avanzar(void);
    void reiniciar(void);

    // Destructor
    ~Control_Animacion();
    
 private:

    // Establece el retardo entre 
    // cuadros de la animacion

    int delay;

    // Almacena los cuadros que componen la animacion

    vector<int> cuadros;
    
    // Paso actual de la animación
    // que controlemos con esta clase

    int paso;

    // Contador para llevar un control
    // del retardo
    
    int cont_delay;
};

#endif
