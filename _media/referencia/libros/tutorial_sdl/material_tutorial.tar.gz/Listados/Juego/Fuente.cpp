// Listado: Fuente.cpp
//
// Implementación de la clase Fuente

#include <iostream>
#include "Fuente.h"


using namespace std;


// Mediante fuente ttf

Fuente::Fuente(const char *path, int tamano) {
    
    // Iniciamos la librería SDL_ttf

    if(TTF_Init() < 0) {

	cerr << "No se puede iniciar SDL_ttf" << endl;
	exit(1);

    }
    
    // Al terminar cerramos SDL_ttf

    atexit(TTF_Quit);


    // Tamaño en puntos de la fuente

    puntos = tamano;
    

    // Cargamos la fuente que queremos utilizar con un determinado tamaño

    fuente = TTF_OpenFont(path, tamano);

    if(fuente == NULL) {

	cerr << "No se puede abrir la fuente deseada" << endl;
	exit(1);

    }
}



// Mediante fuentes en una rejilla-imagen

Fuente::Fuente(const char *path, bool alpha) {

#ifdef DEBUG
    cout << "Fuente::Fuente(): " << path << endl;
#endif


    // Cargamos la imagen que contiene las letras 
    // renderizadas a utilizar

    imagen = IMG_Load(path);

    if(imagen == NULL) {

	cerr << "Fuente::Fuente(): " << SDL_GetError() << endl;
	exit(1);

    }

    if(!alpha) {

	// A formato de imagen
	
	SDL_Surface *tmp = imagen;
	
	imagen = SDL_DisplayFormat(tmp);
	SDL_FreeSurface(tmp);
	
	if(imagen == NULL) {
	
	    cerr << "Fuente::Fuente(): " << SDL_GetError() << endl;	
	    exit(1);

	}
	
	// Establecemos el color key
	
	Uint32 colorkey = SDL_MapRGB(imagen->format, 255, 0, 255);
	SDL_SetColorKey(imagen, SDL_SRCCOLORKEY, colorkey);
	
    }

    buscar_posiciones();
}




void Fuente::dibujar_palabra(SDL_Surface *superficie, char *palabra, \
			     int x, int y, SDL_Color color) {

    // Renderizamos y almacenamos en una superficie

    imagen = TTF_RenderText_Solid(fuente, palabra, color);


    // Convertimos la imagen obtenida a formato de pantalla

    SDL_Surface *tmp = imagen;
    imagen = SDL_DisplayFormat(tmp);
    SDL_FreeSurface(tmp);


    // Colocamos en la pantalla principal en(x, y)

    SDL_Rect destino;

    destino.x = x;
    destino.y = y;
    destino.w = imagen->w;
    destino.h = imagen->h;

    SDL_BlitSurface(imagen, NULL, superficie, &destino);
    
}


// Construimos frases con fuentes ttf cuyo espacio no sea compatible
// con SDL_ttf

void Fuente::dibujar_frase(SDL_Surface *superficie, char *frase, \
			   int x, int y, SDL_Color color) {

    int offset_x = 0; // Distancia entre una letra y la siguiente

    // Separamos la frase en palabras

    int k = 0;
    
    // Mientras no termine la cadena

    while(frase[k] != '\0') {

	int i = 0;
	char palabra[MAX_LONG_PAL];

	for(int j = 0; j < MAX_LONG_PAL; j++) 
	    palabra[j] = '\0';

	// Por si empieza por espacio

	while(frase[k] == ' ')
	    k++;

	// Hasta encontrar un espacio o el final de la cadena

	while(frase[k] != ' ' && frase[k] != '\0') {
	    palabra[i] = frase[k];
	    i++; k++;
	}
    
	if(frase[k] != '\0')
	    k++;


	// No utilizamos la función anterior para facilitar el 
	// cálculo del offset

	// Renderizamos y almacenamos en una superficie

	imagen = TTF_RenderText_Solid(fuente, palabra, color);


	// Convertimos a formato de pantalla

	SDL_Surface *tmp = imagen;
	imagen = SDL_DisplayFormat(tmp);
	SDL_FreeSurface(tmp);


	// Colocamos en la pantalla principal en (x, y)

	SDL_Rect destino;

	destino.x = x + offset_x;
	destino.y = y;
	destino.w = imagen->w;
	destino.h = imagen->h;

	// Calculamos el offset entre letras

	offset_x = offset_x + imagen->w + puntos / 3;

	SDL_BlitSurface(imagen, NULL, superficie, &destino);
    }
}



Fuente::~Fuente() {

    // Liberamos la superficie

    SDL_FreeSurface(imagen);
}



void Fuente::dibujar(SDL_Surface *superficie, char *texto, int x, int y)
{
    int i;
    int aux = 0;

    for(i = 0; texto[i] != '\0'; i ++) {

	// Dibujamos carácter a carácter la frase

	aux = dibujar(superficie, texto[i], x, y);
	x = x + aux + 2;
    }
}



int Fuente::dibujar(SDL_Surface *superficie, char letra, int x, int y)
{

    static int dep = 0;

    if(letra == ' ') {

	// Espacio en la rejilla

	x += 16; 
	return 16;

    }

    bool encuentra = false;

    int i;

    // Buscamos si disponemos de representación gráfica para el carácter

    for(i = 0; cadena[i] != '\0' && encuentra == false; i++) {

	if(cadena[i] == letra)
	    encuentra = true;
	
	// Realiza un incremento más de i
    }

    i--; // i era el '\0'


    // Comprobamos si el carácter ha sido encontrado

    if(encuentra == false && dep == 0) {

	cerr << "No se encuentra el caracter: " << letra << endl;
	dep = 1;

	return 0;
    }

    SDL_Rect destino; // Lugar donde vamos a posicionar la letra

    destino.x = x;
    destino.y = y;
    destino.w = rect_letras[i].w;
    destino.h = rect_letras[i].h;

    // Hacemos el blitting sobre la superficie

    SDL_BlitSurface(imagen, &rect_letras[i], superficie, &destino);

    // Devolvemos el ancho de la letra

    return rect_letras[i].w;
}



void Fuente::buscar_posiciones(void) {

    const int LEYENDO = 0;
    const int DIVISION = 1;

    int indice = 0;
    Uint32 color = 0;
    Uint32 negro = SDL_MapRGB(imagen->format, 0, 0, 0);
    int estado = DIVISION;


    strcpy(cadena, "abcdefghijklmnopqrstuvwxyz"			\
	   "ABCDEFGHIJKLMNOPQRSYUVWXYZ"				\
	   "1234567890"						\
	   "ñÑáéíóúÁÉÍÓÚäëïöü"					\
	   "!¡?¿@#$%&'+-=><*/,.:;-_()[]{}|^`~\\"  );

    if(SDL_MUSTLOCK(imagen)) {

	if(SDL_LockSurface(imagen) < 0)	{

	    cerr << "No se puede bloquear " << imagen << " con "
		 << "SDL_LockSurface" << endl;
	    return;

	}
    }

    indice = -1;
 
    for(int x = 0; x < imagen->w; x ++) {

	color = tomar_pixel(imagen, x, 0);
	
	if(estado == DIVISION && color == negro) {

	    estado = LEYENDO;

	    indice++;

	    rect_letras[indice].x = x;
	    rect_letras[indice].y = 2; 
	    rect_letras[indice].h = imagen->h - 2;
	    rect_letras[indice].w = 0;			

	}
	
	if(color == negro)
	    rect_letras[indice].w++;
	else
	    estado = DIVISION;
    }

    if(SDL_MUSTLOCK(imagen))
	SDL_UnlockSurface(imagen);
}


// Fuente: SDL_Doc

Uint32 Fuente::tomar_pixel(SDL_Surface *superficie, int x, int y)
{
    int bpp = superficie->format->BytesPerPixel;
    Uint8 *p =(Uint8 *)superficie->pixels + y * superficie->pitch + x * bpp;
    
    switch(bpp)  {
     case 1:
	 return *p;
		
     case 2:
	 return *(Uint16 *)p;

     case 3:
	 if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
	     return p[0] << 16 | p[1] << 8 | p[2];
	 else
	     return p[0] | p[1] << 8 | p[2] << 16;
	 
     case 4:
	 return *(Uint32 *)p;
	 
    default:
	return 0;
    }
}

	
