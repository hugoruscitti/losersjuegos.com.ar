// Listado: Protagonista.h
//
// Esta clase controla los distintos aspectos del proyagonista


#ifndef _PROTAGONISTA_H_
#define _PROTAGONISTA_H_

#include <SDL/SDL.h>
#include "Participante.h"

// Declaración adelantada

class Juego;
class Participante;
class Teclado;

class Protagonista: public Participante {
 
 public:
    
    // Constructor

    Protagonista(Juego *juego, int x, int y, int direccion = 1);
    
    void actualizar(void);
    void colisiona_con(Participante *otro);
    
    // Destructor

    ~Protagonista();
		
 private:
    
    // Dispositivo que controla el personaje

    Teclado *teclado;
    
    int x0, y0;
    
    void reiniciar(void);
    
    // Estados del protagonista
    // Para la implementación del autómata

    void estado_caminar(void);
    void estado_parado(void);
    void estado_disparar(void);
    void estado_saltar(void);
    void estado_morir(void);
    void estado_comenzar_salto(void);

};

#endif
