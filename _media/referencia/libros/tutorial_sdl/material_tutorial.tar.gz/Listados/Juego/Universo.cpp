// Listado: Universo.cpp
//
// Implementación de la clase Universo

#include <iostream>

#include "Universo.h"
#include "Juego.h"
#include "Editor.h"
#include "Menu.h"
#include "Galeria.h"
#include "CommonConstants.h"


using namespace std;


Universo::Universo() {

#ifdef DEBUG
    cout << "Universo::Universo()" << endl;
#endif
	
    iniciar_ventana(false);          // Iniciamos en modo ventana
    
    galeria = new Galeria;           // Creamos todo lo necesario
    
    juego = new Juego(this);
    editor = new Editor(this);
    menu = new Menu(this);
    
    salir = false;                   // No queremos salir (todavía)
    
    actual = juego;                  // Establecemos escena actual

    cambiar_interfaz(Interfaz::ESCENA_MENU);   // Cambiamos a menu

}



void Universo::bucle_principal(void) {

    int rep;
	

    // Bucle que realiza el polling

    while(salir == false && procesar_eventos()) {

	teclado.actualizar();           // Tomamos el estado del teclado

	rep = sincronizar_fps();        // Sincronizamos el tiempo
	
	// Actualizamos lógicamente

	for(int i = 0; i < rep; i ++) {
   
	    actual->actualizar();       // Actualizamos la escena actual

	}

	// Limpiamos la pantalla

	SDL_FillRect(pantalla, NULL, \
		     SDL_MapRGB(pantalla->format, 200, 200, 200));

	// Actualizamos las imágenes

	actual->dibujar();
    }
}


void Universo::iniciar_ventana(bool fullscreen) {

    int banderas = 0;
	
    // Iniciamos todos los subsistemas

    if(SDL_Init(0) < 0) {

	cerr << "Universo::iniciar_ventana:" << SDL_GetError() << endl;
	exit(1);

    }

    // Al salir, cerramos libSDL

    atexit(SDL_Quit);
	
    if(fullscreen)
	banderas |= SDL_FULLSCREEN;

    banderas |= SDL_HWSURFACE | SDL_DOUBLEBUF;


    // Establecemos el modo de video

    pantalla = SDL_SetVideoMode(ANCHO_VENTANA, ALTO_VENTANA, BPP, banderas);

    if(pantalla == NULL) {

	cerr << "Universo::iniciar_ventana:" << SDL_GetError() << endl;
	exit(1);

    }

    SDL_WM_SetCaption("Wiki libSDL", NULL);

    // Ocultamos el cursor

    SDL_ShowCursor(SDL_DISABLE);

    // Inicializamos la librería SDL_Mixer

    if(Mix_OpenAudio(22050, MIX_DEFAULT_FORMAT,\
                     1, 2048) < 0) {

        cerr << "Subsistema de Audio no disponible" << endl;
        exit(1);
    }

    // Al salir cierra el subsistema de audio

    atexit(Mix_CloseAudio);

}



int Universo::procesar_eventos(void) {

    static SDL_Event event; // Con "memoria"

    
    // Hacemos el polling de enventos

    while(SDL_PollEvent(&event)) {

	// Se estudia

	switch(event.type) {

	 case SDL_QUIT:
	     return 0;

	 case SDL_KEYDOWN:

	     // Tecla de salida
 
	     if(event.key.keysym.sym == SDLK_q)
		 return 0;

	     // Tecla paso a pantalla completa
	     
	     if(event.key.keysym.sym == SDLK_f)
	
		 pantalla_completa();
	     
	     break;

	 default: 

	     // No hacemos nada

	     break;
	     
	}
    }

    return 1;
}


void Universo::pantalla_completa(void) {

    // Alterna entre pantalla completa y ventana

    SDL_WM_ToggleFullScreen(pantalla);
}


int Universo::sincronizar_fps(void) {

    static int t0;
    static int tl = SDL_GetTicks();
    static int frecuencia = 1000 / 100;
    static int tmp;

#ifdef FPS
    static int fps = 0;
    static int t_fps = 0;
#endif

    // Tiempo de referencia

    t0 = SDL_GetTicks();

#ifdef FPS
    
    // Actualizamos información cada segundo
    if((t0 - t_fps) >= 1000) {
	cout << "FPS = " << fps << endl;
	fps = 0;
	t_fps += 1000 + 1;
    }
	
    fps++;

#endif

    // Estudio del tiempo
	
    if((t0 - tl) >= frecuencia) {
	
	tmp = (t0 - tl) / frecuencia;
	tl += tmp * frecuencia;
	return tmp;
    }
    else {

	// Tenemos que esperar para cumplir con la frecuencia

	SDL_Delay(frecuencia - (t0 - tl));
	tl += frecuencia;
	
	return 1;
    }
}


void Universo::cambiar_interfaz(Interfaz::escenas nueva) {

    Interfaz *anterior = actual;
    
    // Según sea la escena a la que queremos cambiar
    
    switch(nueva) {

     case Interfaz::ESCENA_MENU:

	 actual = menu;	 
	 break;

     case Interfaz::ESCENA_JUEGO:

	 actual = juego;
	 break;

     case Interfaz::ESCENA_EDITOR:

	 actual = editor;
	 break;
    }

    if(anterior == actual) {
	cout << "Universo: Cambia a la misma escena" << endl;
    }

    // Una vez cambiada a la nueva escena, la reiniciamos

    actual->reiniciar();
}



void Universo::dibujar_rect(int x, int y, int w, int h, Uint32 color) {
    
    SDL_Rect rect;
    
    // Almacenamos la variable en un rectángulo

    rect.x = x;
    rect.y = y;
    rect.h = h;
    rect.w = w;

    // Dibujamos el rectángulo

    SDL_FillRect(pantalla, &rect, color);
}


// Queremos salir de la aplicación

void Universo::terminar(void) {
    
    salir = true; // Afecta al polling
}

// Destructor

Universo::~Universo() {

    delete juego;
    delete galeria;
    delete editor;
    delete menu;
    
#ifdef DEBUG
    cout << "Universo::~Universo()" << endl;
    cout << "Gracias por jugar" << endl;
#endif
	
}
