// Listado: Apuntador.h
//
// La clase Apuntador controla el estado
// y la posición del cursor del ratón en la pantalla. 
//
// Haremos uso del cursor del ratón en el Editor de niveles


#ifndef _APUNTADOR_H_
#define _APUNTADOR_H_

#include <SDL/SDL.h>


class Editor;               // Declaración adelantada


class Apuntador
{

 public:

    // Constructor
    Apuntador(Editor *editor);

    void dibujar(SDL_Surface *pantalla);
    void actualizar(void);

    // Consultoras
    
    int pos_x(void);
    int pos_y(void);

 private:

    // Posición del cursor

    int x, y;

    int bloque_actual;
    
    // Controla la pulsación
    // de los botones del ratón

    int botones;

    // Nos permite asociar el cursor
    // con el editor de niveles

    Editor *editor;
    
    // Discrimina de la zona de pulsación

    void pulsa_sobre_rejilla(int botones);
    void pulsa_sobre_barra(int botones);

    // Indica en que imagen de la rejilla
    // de imágenes auxiliares se posiciona
    // la que representará al cursor
    
    int imagen_rejilla;
};

#endif
