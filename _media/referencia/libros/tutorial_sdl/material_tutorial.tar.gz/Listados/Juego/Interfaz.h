// Listado: Interfaz.h 
//
// Superclase de las diferentes escenas disponibles en la aplicación

#ifndef _INTERFAZ_H_
#define _INTERFAZ_H_


// Declaración adelantada

class Universo;



class Interfaz
{
 public:
    
    // Tres son las escenas que encontramos en la aplicación

    enum escenas {
	
	ESCENA_MENU,
	ESCENA_JUEGO,
	ESCENA_EDITOR
 
    };

    // Constructor

    Interfaz(Universo *universo);
 
    // Funciones virtuales puras comunes a todas las escenas

    virtual void reiniciar(void) = 0;
    virtual void dibujar(void) = 0;
    virtual void actualizar(void) = 0;
    
    Universo *universo;
    
    // Destructor

    virtual ~Interfaz();	
};

#endif
