// Listado: Control_Juego.cpp
// Implementación de la clase Control_Juego


#include <iostream>

#include "Control_Juego.h"
#include "Juego.h"
#include "Item.h"
#include "Enemigo.h"
#include "Protagonista.h"
#include "Enemigo.h"
#include "Universo.h"


using namespace std;


Control_Juego::Control_Juego(Juego *juego): protagonista_(NULL) {

#ifdef DEBUG
    cout << "Control_Juego::Control_Juego()" << endl;
#endif

    this->juego = juego;

}



void Control_Juego::actualizar(void) {


    // Actualizamos el protagonista

    if(protagonista_)
	protagonista_->actualizar();
    
    // Actualizamos todos los enemigos    

    for(list<Enemigo *>::iterator i = lista_enemigos.begin();
	i != lista_enemigos.end(); ++i) {

	(*i)->actualizar();
    
    }


    // Actualizamos todos los items
    
    for(list<Item *>::iterator i = lista_items.begin();
	i != lista_items.end(); ++i){

	(*i)->actualizar();
    }

	

    // Eliminamos los antiguos, marcados con ELIMINAR

    eliminar_antiguos_enemigos(lista_enemigos);
    eliminar_antiguos_items(lista_items);

    // Estudiamos las posibles colisiones

    if(protagonista_ != NULL)
	avisar_colisiones();


}



void Control_Juego::dibujar(SDL_Surface *pantalla) {


    // Dibujamos toda la lista de enemigos

    for(list<Enemigo *>::iterator i = lista_enemigos.begin();
	i != lista_enemigos.end(); ++i){

	(*i)->dibujar(juego->universo->pantalla);

    }

    // Dibujamos al protagonista
  
    if(protagonista_)
	protagonista_->dibujar(juego->universo->pantalla);


    // Dibujamos toda la lista de items
    
    for(list<Item *>::iterator i = lista_items.begin();
	i != lista_items.end(); ++i){
	
	(*i)->dibujar(juego->universo->pantalla);

    }

    
}



void Control_Juego::avisar_colisiones(void) {



    static int radio = 20; 

    int x0, y0;
    int x1, y1;

    // Tomamos la posición del protagonista

    x0 = protagonista_->pos_x();
    y0 = protagonista_->pos_y();
    

    // Comprobamos si hay colisión con los enemigos

    for(list<Enemigo *>::iterator i = lista_enemigos.begin();
	i != lista_enemigos.end(); ++i) {

	// Posición del enemigo

	x1 = (*i)->pos_x();
	y1 = (*i)->pos_y();

	// Comprobamos si hay colisión entre el elemento y el protagonista

	if(hay_colision(x0, y0, x1, y1, radio)) {
	    
	    if(protagonista_->estado_actual() != Participante::GOLPEAR) {

		// Mata al protagonista

		protagonista_->colisiona_con((*i)); 

	    } else {

		// Muere el malo

		(*i)->colisiona_con(protagonista_); // Elimina el enemigo

	    }
	}

    }



    // Comprobamos si hay colisión con los objetos

    for(list<Item *>::iterator i = lista_items.begin();
	i != lista_items.end(); ++i) {

	// Posición del item

	x1 = (*i)->pos_x();
	y1 = (*i)->pos_y();

	
	// Comprobamos si hay colisión entre el elemento y el protagonista
	
	if(hay_colision(x0, y0, x1, y1, radio)) {

	    (*i)->colisiona_con(protagonista_); // Elimina el ítem
	    
	    return;

	}
    }


}


// Creando los enemigos

void Control_Juego::enemigo(Participante::tipo_participantes tipo,
			    int x, int y, int flip) {

    
#ifdef DEBUG    
    cout << "Creando un enemigo tipo " << tipo << "en ( " << x << " - "
	 << y << " )" << endl;
#endif
    

    // Almacenamos en las listas el tipo enemigo que queremos crear

    switch(tipo) {
	
     case Participante::TIPO_ENEMIGO_RATA:

	 lista_enemigos.push_back(new Enemigo(Participante::TIPO_ENEMIGO_RATA, juego, x, y, flip));
	 break;

     case Participante::TIPO_ENEMIGO_MOTA:

	 lista_enemigos.push_back(new Enemigo(Participante::TIPO_ENEMIGO_MOTA, juego, x, y, flip));
	 break;
	 
     default:
	 cerr << "Enemigo desconocido" << endl;
    }


}


void Control_Juego::protagonista(int x, int y, int flip) {


    if(protagonista_ != NULL)

	cerr << "Ya existe un protagonista en el nivel" << endl;

    else

	protagonista_ = new Protagonista(juego, x, y, flip);

    
}


void Control_Juego::item(Participante::tipo_participantes tipo,
			 int x, int y, int flip) {


#ifdef DEBUG    
    cout << "Creando un item en ( " << x << " - "
	 << y << " )" << endl;
#endif   

    // Almacenamos en las listas el tipo de item que queremos crear

    switch(tipo) {

     case Participante::TIPO_DESTORNILLADOR:

	 lista_items.push_back(new Item(Participante::TIPO_DESTORNILLADOR, juego, x, y, flip));
	 break;

     case Participante::TIPO_ALICATE:
	
	 lista_items.push_back(new Item(Participante::TIPO_ALICATE, juego, x, y, flip));    
	 break;
	 
     default:

	 cerr << "Item desconocido" << endl;
	 return;
    }


}


Control_Juego::~Control_Juego() {

    // Borramos las estructuras activas del juego

    delete protagonista_;


#ifdef DEBUG
    cout << "Control_Juego::~Control_Juego()" << endl;
#endif

}

bool Control_Juego::hay_colision(int x0, int y0, int x1, int y1, int radio) {


    if((abs(x0 - x1) < (radio * 2)) &&(abs(y0 - y1) < (radio *2)))
        return true;
    else
        return false;


}

void Control_Juego::eliminar_antiguos_items(list<Item *>& lista) {

    list<Item *>::iterator i;
    bool eliminado = false;

    
    // Eliminamos los items marcados como eliminar

    for(i = lista.begin(); i != lista.end() && eliminado == false; ++i) {

	if((*i)->estado_actual() == Participante::ELIMINAR) {

	    lista.erase(i); // más eficiente que remove(*i) 
	    eliminado = true;

	}
	
    }

}

void Control_Juego::eliminar_antiguos_enemigos(list<Enemigo *>& lista) {

    list<Enemigo *>::iterator i;
    bool eliminado = false;

    // Eliminamos los items cuyo estado sea eliminar

    for(i = lista.begin(); i != lista.end() && eliminado == false; ++i) {

	if((*i)->estado_actual() == Participante::ELIMINAR) {

	    lista.erase(i);
	    eliminado = true;

	}
	
    }
}

