// Listado: Menu.h
//
// Esta clase controla los aspectos relevantes al Menú de la aplicación

#ifndef _MENU_H_
#define _MENU_H_

#include <SDL/SDL.h>
#include "Interfaz.h"
#include "CommonConstants.h"

// Declaraciones adelantadas

class Teclado;
class Control_Movimiento;
class Texto;
class Imagen;


class Menu: public Interfaz {

 public:

    // Constructor

    Menu(Universo *universo);

    // Funciones heradas de Interfaz
    // Operativa de la clase

    void reiniciar (void);
    void actualizar (void);
    void dibujar (void);

    // Destructor

    ~Menu();
    
 private:

    // Controla el dispositivo de entrada

    Teclado *teclado;

    // Controla los movimientos y posición de los elementos del menú

    Control_Movimiento *cursor;
    Control_Movimiento *titulo_tutorial;
    Control_Movimiento *titulo_firma;

    // Aquí almacenamos las frases que componen el menú

    Texto *cadena_opciones[NUM_OPCIONES];

    int x, y;
    int opcion;
    Imagen *imagen;
    
    // Crea las cadenas que se almacenarán en cadena_opciones
    void crear_cadenas(void);

    // Crea los títulos del juego
    void crear_titulos(void);
};

#endif
