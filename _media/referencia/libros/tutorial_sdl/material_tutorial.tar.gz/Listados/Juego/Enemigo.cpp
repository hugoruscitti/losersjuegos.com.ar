// Listado: Enemigo.cpp
//
// Implementación de la clase Enemigo

#include <iostream>

#include "Enemigo.h"
#include "Juego.h"
#include "Universo.h"
#include "Galeria.h"
#include "Sonido.h"
#include "Imagen.h"
#include "Control_Animacion.h"
#include "Nivel.h"


using namespace std;


Enemigo::Enemigo(enum tipo_participantes tipo, Juego *juego, int x, int y, int direccion):
    Participante(juego, x, y, direccion) {

#ifndef DEBUG
    cout << "Enemigo::Enemigo()" << endl;
#endif

    // Creamos las animaciones para el personaje

    animaciones[PARADO] = new Control_Animacion("0", 5);
    animaciones[CAMINAR] = new Control_Animacion("0,1,2", 5);
    animaciones[MORIR] = new Control_Animacion("1,2,1,2,1,2", 1);
    
    // Según el tipo de enemigo que estemos creando

    switch(tipo) {
 
     case TIPO_ENEMIGO_RATA:

	 imagen = juego->universo->galeria->imagen(Galeria::ENEMIGO_RATA);
	 break;
    
     case TIPO_ENEMIGO_MOTA:

	 imagen = juego->universo->galeria->imagen(Galeria::ENEMIGO_MOTA);
	 break;
    
    default:
	cout << "Enemigo::Enemigo() -> Enemigo no contenplado" << endl;

    }

    // Estado inicial para los enemigos

    estado = CAMINAR;
}



void Enemigo::actualizar(void) {

    if(estado == MORIR) {
	
	if(animaciones[estado]->avanzar())
	    estado = ELIMINAR;
    }

    else
	// Hacemos avanzar la animación
	animaciones[estado]->avanzar();
    
    // Tiene que llegar al suelo

    velocidad_salto += 0.1;
    y += altura((int) velocidad_salto);

    if(pisa_el_suelo()) {

	// Hacemos que gire si se acaba el suelo

	if(!pisa_el_suelo( x + direccion, y))
	    direccion *= -1;
	
	x += direccion;
    }
    
}

void Enemigo::colisiona_con(Participante *otro) {

    // Si colisiona y el personaje principal está golpeando
    // muere para desaparecer

    if(estado != MORIR) {

	juego->universo->\
	    galeria->sonidos[Galeria::MATA_MALO]->reproducir();	

	estado = MORIR;
    }


}


Enemigo::~Enemigo() {
 
#ifdef DEBUG    
    cout << "Enemigo::~Enemigo" << endl;
#endif

}
