#ifndef _CONSTANTES_
#define _CONSTANTES_

// Apuntador

const int IMAGEN_PUNTERO = 53;
const int BARRA_HERRAMIENTAS = 544;
const int TAM_TITLE = 32;


// Control_Animacion

const int MAX_FRAMES = 1024;

// Editor

const int FILAS_ZONA_EDITABLE = 15;          // 15 * 32 = 480
const int COLUMNAS_ZONA_EDITABLE = 17;       // 17 * 32 = 544

// Fuente

const int MAX_LONG_PAL = 120;

// Menu

const int NUM_OPCIONES = 3;

// Nivel

const int ANCHO_VENTANA = 640;
const int ALTO_VENTANA = 480;
const int TAMANO_BLOQUE = 32;
const int BPP = 16;

const int FILAS_VENTANA = (int) ALTO_VENTANA / TAMANO_BLOQUE;
const int COLUMNAS_VENTANA = (int) ANCHO_VENTANA / TAMANO_BLOQUE;

const int FILAS_NIVEL = (int) (ALTO_VENTANA * 2) / TAMANO_BLOQUE;
const int COLUMNAS_NIVEL =  (int) (ANCHO_VENTANA * 2) / TAMANO_BLOQUE;

const unsigned BLOQUES_NIVEL = FILAS_NIVEL * COLUMNAS_NIVEL;

// Musica

const unsigned VOLUMEN_MUSICA = 60;

// Texto

const int MAX_TAM_TEXTO = 50;

#endif
