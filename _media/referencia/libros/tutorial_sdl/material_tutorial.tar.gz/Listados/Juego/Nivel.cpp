// Listado: Nivel.cpp 
//
// Implementación de la clase Nivel

#include <iostream>

#include "Nivel.h"
#include "Control_Juego.h"
#include "Universo.h"
#include "Protagonista.h"
#include "Juego.h"
#include "Imagen.h"
#include "Galeria.h"

using namespace std;


Nivel::Nivel(Universo *universo, int filas, int columnas) {

#ifdef DEBUG
    cout << "Nivel::Nivel()" << endl;
#endif

    // Inicializamos las variables
    
    this->universo = universo;
    this->bloques = universo->galeria->imagen(Galeria::TILES);

    this->filas = filas;
    this->columnas = columnas;
    
    numero_nivel = 0;
    fichero = NULL;
    modificado = false;

    ventana = new Ventana(filas, columnas);
    
    // Cargamos el fichero

    abrir_fichero();
    cargar();
    
}

// Dibuja los bloques del nivel

void Nivel::dibujar(SDL_Surface *superficie)
{
    // Columna y fila que se lee del mapa

    int lx, ly; 

    // Zona que se pierde al dibujar el primer bloque si no es múltiplo de 32

    int margen_x, margen_y;

    // Número de bloques a dibujar sobre x e y

    int num_bloques_x, num_bloques_y;

    // 1 bloque - 8 bits

    char bloque;

    // Posicionamos 

    ly = ventana->pos_y() / TAMANO_BLOQUE;
    lx = ventana->pos_x() / TAMANO_BLOQUE;

    // Cálculo del sobrante

    margen_y = ventana->pos_y() % TAMANO_BLOQUE;
    margen_x = ventana->pos_x() % TAMANO_BLOQUE;

    

    // Si hay sobrante necesitamos un bloque más

    if(margen_x == 0)
	num_bloques_x = columnas;
    else 
	num_bloques_x = columnas + 1;

    if(margen_y == 0)
	num_bloques_y = filas;
    else
	num_bloques_y = filas + 1;


    // Dibujamos los bloques

    for(int col = 0; col < num_bloques_x; col++) {
	for(int fil = 0; fil < num_bloques_y; fil++) {

	    bloque = mapa[fil + ly][col + lx];
	    
	    if(bloque != -1 && bloque < 36) {
		bloques->dibujar(superficie, bloque,\
				 col * TAMANO_BLOQUE - margen_x,\
				 fil * TAMANO_BLOQUE - margen_y, 1);
	    }
	}
    }
}



void Nivel::dibujar_actores(SDL_Surface *superficie) {
    
    // Columna y fila que se lee del mapa

    int lx, ly; 

    // Zona que se pierde al dibujar
    // el primer bloque si no es múltiplo de 32

    int margen_x, margen_y;

    // Número de bloques a dibujar sobre x e y

    int num_bloques_x, num_bloques_y;

    // 1 bloque - 8 bits

    char bloque;


    // Posición según bloque

    ly = ventana->pos_y() / TAMANO_BLOQUE;
    lx = ventana->pos_x() / TAMANO_BLOQUE;
    
    // Calculamos el sobrante

    margen_y = ventana->pos_y() % TAMANO_BLOQUE;
    margen_x = ventana->pos_x() % TAMANO_BLOQUE;
    
    

    // Si hay sobrante necesitamos un bloque más

    if(margen_x == 0)
	num_bloques_x = columnas;
    else 
	num_bloques_x = columnas + 1;

    if(margen_y == 0)
	num_bloques_y = filas;
    else
	num_bloques_y = filas + 1;


    Imagen *imagen_tmp;
    Galeria::codigo_imagen codigo_tmp;
    int x0, y0;


    for(int col = 0; col < num_bloques_x; col++) {

	for(int fil = 0; fil < num_bloques_y; fil++) {

	    bloque = mapa[fil + ly][col + lx];
	    
	    if(bloque > 35 && bloque < 45) {

		switch(bloque) {

		 case 36:

		     x0 = 16;
		     y0 = TAMANO_BLOQUE;
		     codigo_tmp = Galeria::ENEMIGO_RATA;
		     break;

		case 37:

		    x0 = 16;
		    y0 = TAMANO_BLOQUE;
		    codigo_tmp = Galeria::ENEMIGO_MOTA;
		    break;

		 case 42: 

		     x0 = 16;
		     y0 = TAMANO_BLOQUE; 
		     codigo_tmp = Galeria::ITEM_ALICATE;
		     break;

		case 43:

		     x0 = 16;
		     y0 = TAMANO_BLOQUE;
		     codigo_tmp = Galeria::ITEM_DESTORNILLADOR;
		     break;

						
		 case 44:

		     x0 = 16;
		     y0 = TAMANO_BLOQUE;
		     codigo_tmp = Galeria::PERSONAJE_PPAL;
		     break;
		
		 default:

		     codigo_tmp = Galeria::TILES; // que componen la escena
		     break;
		}

		if(codigo_tmp != Galeria::TILES) {

		    imagen_tmp = universo->galeria->imagen(codigo_tmp);
		    imagen_tmp->dibujar(superficie, 0,\
					col * TAMANO_BLOQUE - margen_x + x0,\
					fil * TAMANO_BLOQUE - margen_y + y0, 1);
		}
	    }
	}
    }
    
}


// Actualiza la ventana en la que nos encontramos

void Nivel::actualizar(void) {

	ventana->actualizar();
}


// Calcula la altura de un elemento

int Nivel::altura(int x, int y, int rango) {

    // Indicamos si estamos fuera de la ventana

    if(x < 0 || x >= ANCHO_VENTANA * 2 || y < 0 || y >= ALTO_VENTANA * 2)
	return rango;

    int fila, columna;

    
    

    for(int h = 0; h < rango; h++) {

	columna = x / TAMANO_BLOQUE;
	fila = (y + h) / TAMANO_BLOQUE;
	
	if((y + h) % TAMANO_BLOQUE == 0 &&
	   no_es_traspasable(mapa[fila][columna]))
	    return h;
    }

    return rango;
}


// Devuelve true si un elemento no es traspasable

bool Nivel::no_es_traspasable(char codigo)
{

    // Codigo de la rejilla de los bloques
    // En la imagen que almacena los tiles
    // estos elementos son los que están definidos 
    // como no transpasables

    if(codigo >= 0 && codigo <= 5 || codigo >= 30 && codigo <= 35)
	return true;
    else
	return false;

}


// Esta función edita el bloque actual
// Si se le pasa -1 en i, limpia el bloque
// Las posiciones x e y son relativas

void Nivel::editar_bloque(int i, int x, int y)
{
    // Calculamos la posición absoluta

    int fila_destino = (y + ventana->pos_y()) / TAMANO_BLOQUE;
    int columna_destino = (x + ventana->pos_x()) / TAMANO_BLOQUE;
    
    // Marcamos el bloque

    mapa[fila_destino][columna_destino] = i;

    // Si se edita un bloque se activa
    // la opción de guardar el nivel modificado

    modificado = true;
}


// Esta función almacena el mapa en un fichero

void Nivel::guardar(void)
{
    FILE * salida;

    if(modificado == false) {
	cerr << "Nivel::guardar() ->"
	     << " Nivel no modificado, no se almacenará" << endl;
	return;
    }

    salida = fopen("niveles.dat", "rb+");

    // Si no existe, intentamos crear un fichero

    if(salida == NULL) {

	salida = crear_fichero();

	if(salida == NULL) { 
	    
	    // No podemos crearlo
	    
	    cerr << "Nivel::guardar() -> Sin acceso de "
		 << "escritura al sistema de ficheros" << endl;
	    return;
	}
		
    }

    
    if(fseek(salida, BLOQUES_NIVEL * numero_nivel, SEEK_SET)) {

	cerr << "Nivel::guardar() -> Error en el fichero" << endl;
	fclose(salida);
	return;

    }
    else {
	
	if(fwrite(&mapa, sizeof(char), BLOQUES_NIVEL, salida) < BLOQUES_NIVEL) {
	    
	    cerr << "Nivel::guardar() -> Error de "
		 << "escritura en el fichero" << endl;

	    fclose(salida);
	    return;
	}
    }

    modificado = false; // Una vez guardado, ya no está modificado

    fclose(fichero);
    
    fflush(salida);
    fichero = salida;
}


 
// Carga el fichero de niveles

int Nivel::cargar(void) {
    
    if(fseek(fichero, BLOQUES_NIVEL * numero_nivel, SEEK_SET)) {

	cerr << "Sin acceso al fichero de niveles" << endl;
	return 1;
    }
    else {

	if(fread(&mapa, sizeof(char), BLOQUES_NIVEL, fichero) < BLOQUES_NIVEL) {
	    cerr << "No se puede cargar el fichero de niveles" << endl;
	    return 1;

	}
    }
    
    return 0;
}


// Limpia el mapa del nivel

void Nivel::limpiar(void) {

    // Rellena a -1 todas las posiciones

    memset(mapa, -1, BLOQUES_NIVEL);

}


// Pasa de nivel

void Nivel::siguiente(void)
{
    // Un nivel más

    numero_nivel++;
    
   
    if(cargar())

	// Si no podemos acceder a un nivel más (no existe, o fallo)
	numero_nivel--;
}


// Pasa al nivel anterior

void Nivel::anterior(void)
{
    // Nivel inicial es el 0

    if(numero_nivel > 0) {

	numero_nivel--;
	cargar(); // el nivel

    }
}


int Nivel::indice(void) {

    return numero_nivel;

}


void Nivel::generar_actores(Control_Juego * control_juego)
{
    int bloque;
    int x, y;
	
    for(int col = 0; col < COLUMNAS_NIVEL; col ++) {
	for(int fil = 0; fil < FILAS_NIVEL; fil ++) {

	    // Según la información del bloque

	    bloque = mapa[fil][col];
			
	    x = (col * TAMANO_BLOQUE) + 16;
	    y = (fil * TAMANO_BLOQUE) + TAMANO_BLOQUE;
			
	    // Cargamos el actor correspodiente

	    switch(bloque) {

	     case 36:

		 control_juego->enemigo(Participante::TIPO_ENEMIGO_RATA,\
					x, y, 1);
		 break;

	     case 37:
		 control_juego->enemigo(Participante::TIPO_ENEMIGO_MOTA,\
					x, y, 1);
		 break;
		 
	     case 42:
		 control_juego->item(Participante::TIPO_ALICATE,\
				     x, y, 1);
		 break;

	     case 43:
		 control_juego->item(Participante::TIPO_DESTORNILLADOR,\
				     x, y, 1);
		 break;

	     case 44:
		 control_juego->protagonista(x, y, 1);
		 break;
					
	     default:
		 break;

	    }
	}
    }
}


Nivel::~Nivel(void) {
    
#ifdef DEBUG
    cout << "Nivel::~Nivel()" << endl;
#endif
    
    delete ventana;
    cerrar_fichero();
}


void Nivel::abrir_fichero(void) {

    fichero = fopen("niveles.dat", "rb");

    if(fichero == NULL)
	cerr << "No se encuentra el fichero niveles.dat" << endl;

}


void Nivel::cerrar_fichero(void) {

    // Si existe el fichero

    if(fichero) {
	
	fclose(fichero); // Lo cerramos
	fichero = NULL;

    }
    else {

	cerr << "El fichero de niveles no estaba abierto" << endl;
    }
}


FILE * Nivel::crear_fichero(void) {

    FILE * tmp;
    
    tmp = fopen("niveles.dat", "wb+");
    
    if(tmp == NULL)

	cerr << "No se puede crear el fichero niveles.dat" << endl;
    else {

	// Lo copiamos en el nuestro

	copiar_fichero(tmp);
	cout << "Fichero de niveles creado" << endl;
    }
    
    return tmp;
}


// Copiamos el fichero abierto a nuestro fichero de niveles 
// para facilitar la edición

void Nivel::copiar_fichero(FILE * tmp) {

    char mapa_tmp[FILAS_NIVEL][COLUMNAS_NIVEL];

    for(int i = 0; i < COLUMNAS_NIVEL; i ++) {
	
	// Copiamos el fichero, nivel a nivel
	
	fseek(fichero, i * BLOQUES_NIVEL, SEEK_SET);
	fseek(tmp, i * BLOQUES_NIVEL, SEEK_SET);
	
	fread(mapa_tmp, BLOQUES_NIVEL, 1, fichero);
	fwrite(mapa_tmp, BLOQUES_NIVEL, 1, tmp);

    }

    cout << "Almacenado fichero de niveles" << endl;
}
