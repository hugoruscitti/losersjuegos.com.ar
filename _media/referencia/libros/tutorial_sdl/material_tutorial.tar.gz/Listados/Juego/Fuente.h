// Listado: Fuente.h
//
// Esta clase controla la impresión de textos en pantalla
// mediantes fuentes ttf o tira de imágenes


#ifndef _FUENTE_H_
#define _FUENTE_H_

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>

#include "CommonConstants.h"


class Fuente {

 public:

    // Constructores

    Fuente(const char *path, int tamano = 20);    // Fuente ttf
    Fuente(const char *path, bool alpha = false); // Fuente ya renderizada


    // Funciones para escribir sobre una superfice

    void dibujar(SDL_Surface *superficie, char *cadena, int x, int y);


    // Funciones para escribir utilizando una fuente ttf

    void dibujar_palabra(SDL_Surface *superficie, \
			char *palabra, int x, int y, SDL_Color color);

    void dibujar_frase(SDL_Surface *superficie, \
		       char *frase, int x, int y, SDL_Color color);

    // Destructor
    ~Fuente();

 private:

    TTF_Font *fuente;          // Para manejar la fuente TTF
    SDL_Surface *imagen_texto; // Imagen obtenida a partir de la fuente

    // Tamaño de la fuente

    int puntos;


    // Dónde almacenar la imagen resultante para mostrar		

    SDL_Surface *imagen;

    int separacion; // entre las letras


    // Define el orden de las letras en la rejilla-imagen

    char cadena[113 + 1];


    // Mantiene la posición de cada letra en la rejilla-imagen

    SDL_Rect rect_letras[113];
    
    void buscar_posiciones(void);


    // Dibuja una letra única

    int dibujar(SDL_Surface *superficie, char letra, int x, int y);
    

    // Toma un píxel de una superficie

    Uint32 tomar_pixel(SDL_Surface *superficie, int x, int y);
    

};


#endif
