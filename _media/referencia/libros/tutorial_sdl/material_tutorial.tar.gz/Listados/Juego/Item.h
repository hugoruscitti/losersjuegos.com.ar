// Listado: Item.h
//
// Esta clase controla todo lo relativo a los items u objetos del juego

#ifndef _ITEM_H_
#define _ITEM_H_

#include "Participante.h"

class Item: public Participante {

 public:

    //Constructor

    Item(enum tipo_participantes tipo, Juego *juego, int x, int y, int flip = 1);

    void actualizar(void);
    void colisiona_con(Participante *otro);
    
    // Destructor

    virtual ~Item();

};

#endif
