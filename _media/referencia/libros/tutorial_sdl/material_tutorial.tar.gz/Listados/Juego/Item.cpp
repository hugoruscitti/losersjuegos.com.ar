// Listado: Item.cpp
//
// Implementación de la clase Item

#include <iostream>

#include "Item.h"
#include "Juego.h"
#include "Universo.h"
#include "Galeria.h"
#include "Sonido.h"
#include "Imagen.h"
#include "Control_Animacion.h"
#include "Nivel.h"


using namespace std;


Item::Item(enum tipo_participantes tipo, Juego *juego, int x, int y, int flip):
    Participante(juego, x, y, flip) {

#ifdef DEBUG
    cout << "Item::Item()" << endl;
#endif

    // Animaciones de los estado de los objetos

    animaciones[PARADO] = new Control_Animacion("0,0,0,1,2,2,1", 10);
    animaciones[MORIR] = new Control_Animacion("1,2,3,3", 7);

    // Imagen según el tipo de item creado

    switch(tipo) {

     case TIPO_ALICATE:

	 imagen = juego->universo->galeria->imagen(Galeria::ITEM_ALICATE);
	 break;

     case TIPO_DESTORNILLADOR:

	 imagen = juego->universo->galeria->imagen(Galeria::ITEM_DESTORNILLADOR);
	 break;

     default:
	 cerr << "Item::Item(): Caso no contemplado" << endl;
	 break;
    }

    estado = PARADO;
}


void Item::actualizar(void)
{

    // Si el item "muere" lo marcamos para eliminar
    // si no avanzamos la animación

    if(estado == MORIR) {
	
	if(animaciones[estado]->avanzar())
	    estado = ELIMINAR;

    }
    else 
	animaciones[estado]->avanzar();
    
    
    // Por si está colocado en las alturas
    // y tiene que caer en alguna superficie
    // necesita una velocidad de caida
		
    velocidad_salto += 0.1;
    y += altura((int) velocidad_salto);
}



void Item::colisiona_con(Participante *otro) {

    // Si colisiona, muere para desaparecer

    if(estado != MORIR) {

	juego->universo->\
	    galeria->sonidos[Galeria::COGE_ITEM]->reproducir();	

	estado = MORIR;
    }

}


Item::~Item() {

#ifdef DEBUG
    cout << "Item::~Item()" << endl;
#endif

}
