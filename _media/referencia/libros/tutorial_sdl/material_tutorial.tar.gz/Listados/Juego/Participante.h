// Listado: Participante.h
//
// Clase madre que proporciona una interfaz para los participantes
// que componen el juego

#ifndef _PARTICIPANTE_H_
#define _PARTICIPANTE_H_

#include <iostream>
#include <map>
#include <SDL/SDL.h>

class Control_Animacion;
class Imagen;
class Juego;

using namespace std;

class Participante {

 public:

    // Tipos de participantes

    enum tipo_participantes {

	TIPO_PROTAGONISTA,
	TIPO_ENEMIGO_RATA,
	TIPO_ENEMIGO_MOTA,
	TIPO_ALICATE,
	TIPO_DESTORNILLADOR
    };

    // Estados posibles de los participantes

    enum estados {
	
	PARADO,
	CAMINAR,
	SALTAR,
	MORIR,
	ELIMINAR,
	GOLPEAR
    };
    
    // Constructor

    Participante(Juego *juego, int x, int y, int direccion = 1);
  
    // Consultoras 
    int pos_x(void);
    int pos_y(void);


    virtual void actualizar(void) = 0;

    void dibujar(SDL_Surface *pantalla);

    // 
    virtual void colisiona_con(Participante *otro) = 0;

    virtual ~Participante();
    
    estados estado_actual(void) {return estado;};
    
 protected:
    void mover_sobre_x(int incremento);
    bool pisa_el_suelo(void);
    bool pisa_el_suelo(int _x, int _y);
    int altura(int rango);
    
    Imagen *imagen;
    Juego *juego;
    int x, y;
    int direccion;
    float velocidad_salto;
    
    enum estados estado;
    enum estados estado_anterior;
    
    map<estados, Control_Animacion*> animaciones;
};

#endif
