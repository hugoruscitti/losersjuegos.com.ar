// Listado: Ventana.h
//
// Esta clase nos permite navegar por las superficies de los niveles

#ifndef _VENTANA_H_
#define _VENTANA_H_

#include <SDL/SDL.h>

class Ventana {

 public:

    // Constructor
    Ventana(int filas, int columnas);
    
    void actualizar(void);

    void establecer_pos(int x, int y);
    void tomar_pos(int * x, int * y);
    void tomar_pos_final(int * x, int * y);
    
    int pos_x(void);
    int pos_y(void);
    
 private:

    int x, y;
    int x_final, y_final;
    int limite_x, limite_y;
    
    void limitar_movimiento(void);
};

#endif
