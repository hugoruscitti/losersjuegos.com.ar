// Listado: Galeria.cpp
//
// Implementación de la clase galería del videojuego

#include <iostream>

#include "Galeria.h"
#include "Imagen.h"
#include "Fuente.h"
#include "Musica.h"
#include "Sonido.h"

using namespace std;


Galeria::Galeria() {

#ifdef DEBUG
    cout << "Galeria::Galeria()" << endl;
#endif

    // Cargamos las rejillas en la galería para las animaciones
    // y las imágenes fijas
	
    imagenes[PERSONAJE_PPAL] = new Imagen("Imagenes/personaje_principal.bmp",\
					  4, 7, 45, 90, false);
    imagenes[TILES] = new Imagen("Imagenes/bloques.bmp", 10, 6);
    imagenes[ENEMIGO_RATA] = new Imagen("Imagenes/enemigo_rata.bmp", 1, 3, 45, 72, false);
    imagenes[ENEMIGO_MOTA] = new Imagen("Imagenes/enemigo_mota.bmp", 1, 3, 45, 72, false);
    imagenes[TITULO_TUTORIAL] = new Imagen("Imagenes/titulo_tutorial.bmp", 1, 1);
    imagenes[TITULO_FIRMA] = new Imagen("Imagenes/titulo_libsdl.bmp", 1, 1);
    imagenes[ITEM_ALICATE] = new Imagen("Imagenes/alicate.bmp", 1, 4, 25, 57);
    imagenes[ITEM_DESTORNILLADOR] = new Imagen("Imagenes/destornillador.bmp", 1, 4, 40, 18);

    // Cargamos las fuentes en la galería

    fuentes[FUENTE_MENU] = new Fuente("Imagenes/arial_black.png", true);

    // Cargamos la música de la galería

    musicas[MUSICA_MENU] = new Musica("Musica/menu.wav");
    musicas[MUSICA_EDITOR] = new Musica("Musica/editor.wav");
    musicas[MUSICA_JUEGO] = new Musica("Musica/juego.wav");

    // Cargamos los sonidos de efectos

    sonidos[COGE_ITEM] = new Sonido("Sonidos/item.wav");
    sonidos[MATA_MALO] = new Sonido("Sonidos/malo.wav");    
    sonidos[PASA_NIVEL] = new Sonido("Sonidos/nivel.wav");  
    sonidos[EFECTO_MENU] = new Sonido("Sonidos/menu.wav");
    sonidos[MUERE_BUENO] = new Sonido("Sonidos/muere.wav");
}


Imagen *Galeria::imagen(codigo_imagen cod_ima) {

    // Devolvemos la imagen solicitada

    return imagenes[cod_ima];
}


Fuente *Galeria::fuente(codigo_fuente indice) {

    // Devolvemos la fuente solicitada

    return fuentes[indice];
}

Musica *Galeria::musica(codigo_musica cod_music) {

    // Devolvemos la música solicitada

    return musicas[cod_music];

}

Sonido *Galeria::sonido(codigo_sonido cod_sonido) {

    // Devolvemos el sonido solicitado

    return sonidos[cod_sonido];

}


Galeria::~Galeria() {

    // Descargamos la galería

    delete imagenes[PERSONAJE_PPAL];
    delete imagenes[TILES];
    delete imagenes[ENEMIGO_RATA];
    delete imagenes[ENEMIGO_MOTA];
    delete imagenes[TITULO_TUTORIAL];
    delete imagenes[TITULO_FIRMA];
    delete imagenes[ITEM_ALICATE];
    delete imagenes[ITEM_DESTORNILLADOR];

    delete fuentes[FUENTE_MENU];

    delete musicas[MUSICA_MENU];
    delete musicas[MUSICA_JUEGO];
    delete musicas[MUSICA_EDITOR];

    delete sonidos[COGE_ITEM];
    delete sonidos[MATA_MALO];
    delete sonidos[PASA_NIVEL];
    delete sonidos[EFECTO_MENU];
    delete sonidos[MUERE_BUENO];

#ifdef DEBUG
    cout << "Galeria::~Galeria()" << endl;
#endif

}
