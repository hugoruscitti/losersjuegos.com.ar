// Listado: Musica.cpp
//
// Implementación de la clase Música

#include <iostream>

#include "Musica.h"
#include "CommonConstants.h"

using namespace std;

Musica::Musica(char *ruta) {


    // Cargamos la música

    bso = Mix_LoadMUS(ruta);

    if(bso == NULL) {

	cerr << "Música no disponible" << endl;
	exit(1);	

    }

    // Establecemos un volumen predeterminado

    Mix_VolumeMusic(VOLUMEN_MUSICA);

#ifdef DEBUG
    cout << "Música cargada" << endl;
#endif
    
}

void Musica::reproducir() {

   Mix_PlayMusic(bso, -1);

}


void Musica::pausar() {

    Mix_PauseMusic();

}

Musica::~Musica() {

    Mix_FreeMusic(bso);

}
