// Ejercicio 1
//
// Listado: main.cpp
// Programa de pruebas. Control del tiempo
// Emulación de SDL_Delay()


#include <iostream>
#include <SDL/SDL.h>

using namespace std;

void emuSDL_Delay(Uint32 ms);

int main()
{
    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
	
	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
    }

    atexit(SDL_Quit);

    int esperar;

    cout << "Introduzca el tiempo que desea esperar (ms): ";
    cin >> esperar;

    int inicio = SDL_GetTicks();
  
    cout << "Referencia INICIAL: " << inicio << endl;

    emuSDL_Delay(esperar);

    int final = SDL_GetTicks();

    // Información para comprobar la eficacia
    // de la función implementada

    cout << "Referencia FIN: " << final << endl;
    cout << "Ha esperado " << (final - inicio) << " ms" << endl;
    cout << "Se ha producido un error de "
	 << esperar - (final - inicio) << " ms" << endl;
     
    
    return 0;
}


// Esta función provoca la pausa de la aplicación
// durante el tiempo pasado como parámetro

void emuSDL_Delay(Uint32 ms) {

    Uint32 referencia, actual;

    referencia = SDL_GetTicks();

    do {

	actual = SDL_GetTicks();

    } while(ms > (actual - referencia));
}
