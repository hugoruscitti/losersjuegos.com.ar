// Ejemplo 1
//
// Listado: main.cpp
// Programa de pruebas. Control del tiempo


#include <iostream>
#include <SDL/SDL.h>

using namespace std;

int main()
{
    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
	
	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
    }

    atexit(SDL_Quit);

    // Tomamos una señal de tiempo

    Uint32 tiempo_transcurrido;

    tiempo_transcurrido = SDL_GetTicks();


    // Lo mostramos en segundos

    cout << "El tiempo transcurrido es "
	 <<  tiempo_transcurrido / 1000 << " segundos." << endl;

    // Durante 10 segundos

    unsigned int i = 0;

    while(tiempo_transcurrido < 10000) {

	// Una vez por segundo

	 if(tiempo_transcurrido > (i * 1000)) {

	     cout << "Han pasado " << i << " segundo(s)" << endl;
	     i++;
	 }

	 tiempo_transcurrido = SDL_GetTicks();
    }

    cout << "La aplicación termina a " << SDL_GetTicks() 
	 << " ms de haber empezado" << endl;

    return 0;
}
