// Ejemplo 2
//
// Listado: main.cpp
// Programa de pruebas. Control del tiempo


#include <iostream>
#include <SDL/SDL.h>

using namespace std;

int main()
{
    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
	
	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
    }

    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video
    
    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {
	
        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);
	
    }

    // Antes de establecer el modo de video
    // Establecemos el nombre de la ventana

    SDL_WM_SetCaption("Ejemplo 2", NULL);

    SDL_Surface *pantalla;
    
    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);
    
    if(pantalla == NULL) {
	
	cerr << "No se pudo establecer el modo de video: "
	     << SDL_GetError();
	
	exit(1);
    }

    cout << "Pulsa ESC para terminar. " << endl;
    cout << "Pulsa f para cambiar a pantalla completa. " << endl;

    // Variables auxiliares

    SDL_Event evento;
    SDL_Surface *imagen;

    SDL_Rect destino;

    // Inicializamos la variable de posición y tamaño de destino
    // Para la imagen que vamos a cargar

    destino.x = 150; 
    destino.y = 150; 
    destino.w = imagen->w;
    destino.h = imagen->h;

    // Bucle infinito

    for( ; ; ) {

	cout << "Esperamos un segundo" << endl;

	SDL_Delay(1000);


	// Cargagamos un bmp en la superficie
	// para realizar las pruebas

	imagen = SDL_LoadBMP("Imagenes/ajuste.bmp");
	
	if(imagen == NULL) {
	    cerr << "No se puede cargar la imagen: "
		 << SDL_GetError() << endl;
		  exit(1);
	}

	// Blit a la superficie principal

	SDL_BlitSurface(imagen, NULL, pantalla, &destino);
	
	// Actualizamos la pantalla

	SDL_Flip(pantalla);


	// Esperamos que pase un segundo

	cout << "Esperamos un segundo" << endl;	

	SDL_Delay(1000);	
	
	// Cargamos otra imagen en la misma superficie

	imagen = SDL_LoadBMP("Imagenes/ajuste2.bmp");

	if(imagen == NULL) {

	    cerr << "No se puede cargar la imagen: "
		 << SDL_GetError() << endl;
		  exit(1);	    
	
	}
	
	// Blit a la superficie principal

	SDL_BlitSurface(imagen, NULL, pantalla, &destino);
	
	// Actualizamos la pantalla

	SDL_Flip(pantalla);
	
	while(SDL_PollEvent(&evento)) {

	    if(evento.type == SDL_KEYDOWN) {
		
		if(evento.key.keysym.sym == SDLK_ESCAPE) {
		    
		    SDL_FreeSurface(imagen);
		    return 0;
		}
		if(evento.key.keysym.sym == SDLK_f) {
		    
		    // Si pulsamos f pasamos a pantalla completa
		    
		    if(!SDL_WM_ToggleFullScreen(pantalla))
			
			cerr << "No se puede pasar a pantalla completa."
			     << endl;
		}
		
	    }

	    if(evento.type == SDL_QUIT)
		
		return 0;
	}
    }
}
