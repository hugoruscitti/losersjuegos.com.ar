// Ejemplo 3
//
// Listado: main.cpp
// Programa de pruebas. Control del tiempo: TIMERS


#include <iostream>
#include <SDL/SDL.h>

using namespace std;

Uint32 Funcion_Callback(Uint32 intervalo, void *parametros);
Uint32 Funcion_Callback2(Uint32 intervalo);

int main()
{
    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0) {
	
	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
    }

    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video
    
    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {
	
        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);
	
    }

    // Antes de establecer el modo de video
    // Establecemos el nombre de la ventana

    SDL_WM_SetCaption("Ejemplo 3", NULL);

    // Establecemos el modo

    SDL_Surface *pantalla;
    
    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);
    
    if(pantalla == NULL) {
	
	cerr << "No se pudo establecer el modo de video: "
	     << SDL_GetError();
	
	exit(1);
    }

    // Añadimos un Timer

    SDL_TimerID mytimer;

    mytimer = SDL_AddTimer(1000, Funcion_Callback, pantalla);

    if(mytimer == NULL) {
	
	cerr << "No se pudo establecer el timer: "
	     << SDL_GetError();
	
	exit(1);
    }

    // Información en pantalla

    cout << "Pulsa ESC para terminar. " << endl;
    cout << "Pulsa f para cambiar a pantalla completa. " << endl;
    cout << "Pulsa t para establecer un nuevos timer en 1 y 1,5 seg" << endl;

    // Variables auxiliares

    SDL_Event evento;


    // Bucle infinito

    for( ; ; ) {

	while(SDL_PollEvent(&evento)) {

	    if(evento.type == SDL_KEYDOWN) {
		
		if(evento.key.keysym.sym == SDLK_ESCAPE) {
		    
		    // Eliminamos el timer al salir

		    SDL_RemoveTimer(mytimer);

		    cout << "Timer eliminado" << endl;

		    return 0;
		}

		if(evento.key.keysym.sym == SDLK_f) {
		    
		    // Si pulsamos f pasamos a pantalla completa
		    
		    if(!SDL_WM_ToggleFullScreen(pantalla))
			
			cerr << "No se puede pasar a pantalla completa."
			     << endl;
		}

		if(evento.key.keysym.sym == SDLK_t) {
		    
		    // Un nuevo timer en 1 segundos

		    SDL_SetTimer(1000, Funcion_Callback2);

		    // Repetimos el a los 1,5 segundos

		    mytimer = SDL_AddTimer(1500, Funcion_Callback, pantalla);
		}
		
	    }	 
	}
    }
}


Uint32 Funcion_Callback(Uint32 intervalo, void *parametros) {

    
	cout << "Entro en el callback" << endl;
	
	SDL_Rect destino;
	
	SDL_Surface *imagen;

	// Cargagamos un bmp en la superficie
	// para realizar las pruebas
	
	imagen = SDL_LoadBMP("Imagenes/ajuste.bmp");
	
	// Inicializamos la variable de posición y tamaño de destino
	// Para la imagen que vamos a cargar
	
	destino.x = 150; 
	destino.y = 150; 
	destino.w = imagen->w;
	destino.h = imagen->h;
	
	if(imagen == NULL) {
	    cerr << "No se puede cargar la imagen: "
		 << SDL_GetError() << endl;
	    exit(1);
	}
	
	// Blit a la superficie principal
	
	SDL_BlitSurface(imagen, NULL,(SDL_Surface *) parametros, &destino);
	
	SDL_Delay(intervalo);

	// Actualizamos la pantalla

	SDL_Flip((SDL_Surface *) parametros);
	
	
	// Cargamos otra imagen en la misma superficie
	
	imagen = SDL_LoadBMP("Imagenes/ajuste2.bmp");
	
	if(imagen == NULL) {
	    
	    cerr << "No se puede cargar la imagen: "
		 << SDL_GetError() << endl;
	    exit(1);	    
	    
	}
	
	// Blit a la superficie principal
	
	SDL_BlitSurface(imagen, NULL, (SDL_Surface *) parametros, &destino);
	
	SDL_Delay(intervalo);

	// Actualizamos la pantalla

	SDL_Flip((SDL_Surface *) parametros);
	
   

    return 0;
    
}

Uint32 Funcion_Callback2(Uint32 intervalo) {

    cout << "Entro en función callback 2 (1 seg de demora)" << endl;

    return 0;
    
}
