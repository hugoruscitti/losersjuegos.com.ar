// Ejemplo 1 - Subsistema de Audio
//
// Listado: main.cpp
// Programa de pruebas. Generando un sonido aleatorio


#include <iostream>
#include <iomanip>

#include <SDL/SDL.h>

using namespace std;

void funcion_retrollamada(void *userdata, Uint8 *buffer, int len);

int main()
{

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {

	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
	
    }


    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video
    
    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {
	
        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);
	
    }


      // Establecemos el modo de video

    SDL_Surface *pantalla;

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {

        cerr << "No se pudo establecer el modo de video: "
             << SDL_GetError() << endl;

        exit(1);
    }

    // Configuramos el subsistema de audio

    // Especificamos las opciones de audio

    SDL_AudioSpec espec_deseadas;
    SDL_AudioSpec espec_obtenidas;

    espec_deseadas.freq = 11025;
    espec_deseadas.format = AUDIO_S16SYS;
    espec_deseadas.channels = 2;
    espec_deseadas.samples = 4096;
    espec_deseadas.callback = funcion_retrollamada;
    espec_deseadas.userdata = NULL;   

    // Abrimos el dispositivo de audio

    if(SDL_OpenAudio(&espec_deseadas, &espec_obtenidas) < 0) {

	cerr << "No se puede abrir el dispositivo de audio" << endl;
	exit(1);
    }

    cout << "\n - Configuración de Audio conseguida - \n" << endl;

    cout << "Frecuencia : " << (int) espec_obtenidas.freq << endl;
    cout << "Canales    : " << (int) espec_obtenidas.channels << endl;
    cout << "Samples    : " << (int) espec_obtenidas.samples << endl;


    

    // Variables auxiliares
    
    SDL_Event evento;

    cout << "\nPulsa ESC para salir\n" << endl;

    cout << "Pulsa 'p' para reproducir el sonido aleatorio" << endl;

    // Bucle "infinito"

    for( ; ; ) {
	
	while(SDL_PollEvent(&evento)) {
	    
	    if(evento.type == SDL_KEYDOWN) {
	
		if(evento.key.keysym.sym == SDLK_ESCAPE)
		    return 0;

		if(evento.key.keysym.sym == SDLK_p) {

		    if(SDL_GetAudioStatus() == SDL_AUDIO_STOPPED ||
		       SDL_GetAudioStatus() == SDL_AUDIO_PAUSED) {
			
			cout << "Reproduciendo" << endl;
			SDL_PauseAudio(0);
			
		    } else {
			
			cout << "Pausa" << endl;
			SDL_PauseAudio(1);
		    }

		}
	    }
	    
	    if(evento.type == SDL_QUIT)
		return 0;	    
	    
	}
    }
    
}

// Función de retrollamada para el subsistema de audio
// Rellenamos el búffer de audio con valores aleatorios entre 0 y 255

void funcion_retrollamada(void *userdata, Uint8 *buffer, int len) {
 
    for(int i = 0; i < len; i++)
	 buffer[i] = i % 256;
}
