// Listado: main.c
// Programa de prueba,
// Cargar una imagen de un personaje en pantalla, con color key

// Colores: (  R,   G,   B)
// Rojo:    (255,   0,   0)
// Naranja: (255, 168,   0)
// Verde:   (  0, 255,   0)  

#include <stdio.h>
#include <SDL/SDL.h>

int main()
{

    SDL_Surface *pantalla, *semaforo;
    SDL_Rect posicion;
    SDL_Event evento;

    int R, G, B, i;
    int colores[3][3];
    Uint32 negro;

    // Inicializamos la matriz con los posibles valores
   
    // Semáforo en rojo

    colores[0][0] = 255;
    colores[0][1] = 0;
    colores[0][2] = 0;

    // Semáforo en naranja

    colores[1][0] = 255;
    colores[1][1] = 168;
    colores[1][2] = 0;

    // Semáforo en verde
    
    colores[2][0] = 0;
    colores[2][1] = 255;
    colores[2][2] = 0;

    // Iniciamos el subsistema de video SDL

    if( SDL_Init(SDL_INIT_VIDEO) < 0) {
	 fprintf(stderr, "No se pudo iniciar SDL: %s\n", SDL_GetError());
	 exit(1);
    }

    atexit(SDL_Quit);


    // Establecemos el modo de video

    pantalla = SDL_SetVideoMode(160, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {
	 fprintf(stderr, "No se pudo establecer el modo de video: %s\n",\
		 SDL_GetError());
	 exit(1);
    }

    negro = SDL_MapRGB(pantalla->format, 0, 0, 0);

    // Cargamos la imagen del semaforo 

    semaforo = SDL_LoadBMP("Imagenes/semaforo.bmp");

    if(semaforo == NULL) {
	 fprintf(stderr, "No se pudo cargar la imagen: %s\n", SDL_GetError());
	 exit(1);
    }

    // Vamos a inicializar los valores de la posicion y tamaño de la imagen

    posicion.x = 0;
    posicion.y = 0;
    posicion.w = semaforo->w;
    posicion.h = semaforo->h;

    i = 0;

    for(;;) {
	
	// Establecemos el color de la transparencia
	// No será mostrado al realizar el blitting
	if(i > 2)
	    i = 0;

	R = colores[i][0];
	G = colores[i][1];	
	B = colores[i][2];

	i++;

	// Establecemos el color de la transparencia

	SDL_SetColorKey(semaforo, SDL_SRCCOLORKEY | SDL_RLEACCEL,\
			SDL_MapRGB(semaforo->format, R, G, B));

	SDL_FillRect(pantalla, NULL, negro);

	// Copiamos la imagen en la superficie principal
	
	SDL_BlitSurface(semaforo, NULL, pantalla, &posicion);
	
	// Mostramos la pantalla "oculta" del búffer
	
	SDL_Flip(pantalla);

	// Esperamos 2 segundos

	sleep(2);


        // Consultamos los eventos
	
        while(SDL_PollEvent(&evento)) {

            if(evento.type == SDL_QUIT) {
	
		// Liberamos los recursos que no necesitamos
		SDL_FreeSurface(semaforo);

                return 0;
	    }
        }
    }
}
