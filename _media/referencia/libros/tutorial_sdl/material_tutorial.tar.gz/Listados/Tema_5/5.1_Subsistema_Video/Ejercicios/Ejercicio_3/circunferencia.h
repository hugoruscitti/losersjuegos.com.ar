// Listado: circunferencia.h
// Función que crea un círculo en una superficie

#ifndef _CIRCUNFERENCIA_H_
#define _CIRCUNFERENCIA_H_

void Circunferencia(SDL_Surface *superficie, int x, int y, int radio, Uint32 color);

#endif
