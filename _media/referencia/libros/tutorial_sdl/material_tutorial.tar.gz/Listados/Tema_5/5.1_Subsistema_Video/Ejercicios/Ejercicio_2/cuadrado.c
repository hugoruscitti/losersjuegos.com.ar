// Listado: recta.c

#include <SDL/SDL.h>

#include "recta.h"
#include "cuadrado.h"

void Cuadrado(SDL_Surface *superficie, \
	      int x, int y, int lado, Uint32 color) {

    // Dibujamos las verticales paralelas

    Recta(superficie, x, y, x, y + lado, color);
    Recta(superficie, x + lado, y, x + lado, y + lado, color);

    // Dibujamos las horizontales paralelas

    Recta(superficie, x, y, x + lado, y, color);
    Recta(superficie, x, y + lado, x + lado, y + lado, color);
}
