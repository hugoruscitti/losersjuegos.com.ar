// Listado: main.c
// Programa de prueba, 

#include <stdio.h>
#include <SDL/SDL.h>

#include "pixels.h"
#include "recta.h"


int main()
{

    // Vamos a dibujar píxeles en pantalla
    SDL_Surface *pantalla;

    // Variables auxiliares

    Uint32 color1, color2;
    Uint8 *buffer;

    SDL_Event evento;

    // Llama a SDL_Quit() al salir

    atexit(SDL_Quit);

    // Iniciamos SDL

    if(SDL_Init(SDL_INIT_VIDEO) < 0){

	 fprintf(stderr, " No se pudo iniciar SDL: %s\n", SDL_GetError());
	 exit(1);

    }    

    // Es compatible el modo de video?

    if(SDL_VideoModeOK(640, 480, 24, SDL_SWSURFACE) == 0) {

	 fprintf(stderr, "Modo no soportado: %s\n", SDL_GetError());
	 exit(1);

    }   


    // Una vez comprobado establecemos el modo de video

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_SWSURFACE);
    if(pantalla == NULL) {

	printf("SDL_SWSURFACE 640 x 480 x 24 no compatible.\n");
	printf("Error: %s\n", SDL_GetError());
   
    }


    // Si hay que bloquear la superficie se bloquea

    if(SDL_MUSTLOCK(pantalla))
	 SDL_LockSurface(pantalla);


    // Vamos a dibujar rectas de píxeles verdes y rosas

    color1 = SDL_MapRGB(pantalla->format, 0, 255, 0);
    color2 = SDL_MapRGB(pantalla->format, 255, 0, 255);    

    // Dibujamos rectas verticales

    Recta(pantalla, 100, 100, 100, 350, color1);
    Recta(pantalla, 150, 120, 150, 450, color2);

    // Dibujamos rectas horizontales

    Recta(pantalla, 200, 100, 450, 100, color1);
    Recta(pantalla, 100, 200, 390, 200, color2);

    // Actualizamos la pantalla parar mostrar el cambio

    SDL_Flip(pantalla);
        
    // Una vez dibujado procedemos a desbloquear la superficie
    // Siempre y cuando hubiese sido bloqueada
    
    if(SDL_MUSTLOCK(pantalla))
	 SDL_UnlockSurface(pantalla);

    // Ahora mantenemos el resultado en pantalla
    // Hasta pulsar escape

    for(;;) {

        // Consultamos los eventos
	
        while(SDL_PollEvent(&evento)) {
	    
            if(evento.type == SDL_QUIT) // Si es de salida
                return 0;
        }
    }
    
}
