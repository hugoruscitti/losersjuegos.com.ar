// Listado: circunferencia.c
// Creación de un círculo en una superficie de SDL

#include <SDL/SDL.h>
#include <math.h>

#include "pixels.h"

void Circunferencia(SDL_Surface *superficie, int x, int y, int radio, Uint32 color) {

    int puntos = 0;
    float angulo_exacto;
    
    int x0 = x;
    int y0 = y;

    int x_aux, y_aux;

    while(puntos < 256) {

	angulo_exacto = puntos * M_PI / 128;

	x = radio * cos(angulo_exacto);
	y = radio * sin(angulo_exacto);

	x_aux = x + radio + x0;
	y_aux = y + radio + y0;


	// Evitamos dibujar fuera de la superficie
      

	if(!(x_aux < 0 || y_aux < 0				\
	     || x_aux > superficie->w || y_aux > superficie->h))

	    PutPixel(superficie, x_aux, y_aux, color);
	
	puntos++;
    }

}
