// Listado: recta.c

#include <SDL/SDL.h>
#include <math.h>

#include "pixels.h"
#include "recta.h"

void Recta(SDL_Surface *superficie, \
	   int x0, int y0, int x1, int y1, Uint32 color) {

    // Calculamos la longitud de la recta

    int longitud = sqrt(pow((x1 - x0), 2) + pow((y1 - y0), 2));


    // La longitud no debe ser negativa

    if(longitud < 0)
	longitud = -1 * longitud;

    int i = 0;
   
    for(i = 0; i < longitud; i++) {

	// Si es vertical aumento y

	if(x0 == x1) {

	    y0++;

	    PutPixel(superficie, x0, y0, color);
	
	} 

	// Si es horizontal aumento x

	if(y0 == y1) {
	    
	    x0++;

	    PutPixel(superficie, x0, y0, color);
	}
	
	
    }
}
