// Listado: pixels.h
// Fichero de Cabecera
// Funciones para el manejo de píxeles dentro de superficies

#ifndef _PIXELS_H_
#define _PIXELS_H_


enum colores {R, G, B};

// Esta función sustituye el color del píxel (x, y) de la superficie
// surface por el color que recibe en el parámtro pixel

void PutPixel(SDL_Surface *superficie, int x, int y, Uint32 pixel);


// Esta función devuelve el color del píxel de la
// posición (x, y) de la superficie

Uint32 GetPixel(SDL_Surface *superficie, int x, int y);

#endif
