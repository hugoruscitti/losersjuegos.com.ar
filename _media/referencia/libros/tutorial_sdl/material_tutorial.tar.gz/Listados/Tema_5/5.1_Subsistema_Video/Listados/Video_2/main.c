// Listado: main.c
// Programa de prueba, 

#include <stdio.h>
#include <SDL/SDL.h>

#include "pixels.h"


int main()
{

    // Vamos a dibujar píxeles en pantalla
    SDL_Surface *pantalla;

    // Variables auxiliares

    int x, y; // Para la posición
    Uint32 color, comprobacion;
    Uint8 *buffer;

    SDL_Event evento;


    // Iniciamos SDL

    if(SDL_Init(SDL_INIT_VIDEO) < 0){

	 fprintf(stderr, " No se pudo iniciar SDL: %s\n", SDL_GetError());
	 exit(1);

    }    

    // Llama a SDL_Quit() al salir

    atexit(SDL_Quit);

    // Es compatible el modo de video?

    if(SDL_VideoModeOK(640, 480, 24, SDL_SWSURFACE) == 0) {

	 fprintf(stderr, "Modo no soportado: %s\n", SDL_GetError());
	 exit(1);

    }   


    // Una vez comprobado establecemos el modo de video

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_SWSURFACE);
    if(pantalla == NULL) {

	printf("SDL_SWSURFACE 640 x 480 x 24 no compatible.\n");
	printf("Error: %s\n", SDL_GetError());
   
    }


    // Si hay que bloquear la superficie se bloquea

    if(SDL_MUSTLOCK(pantalla))
	 SDL_LockSurface(pantalla);

    // Procedemos a dibujar los píxeles en pantalla
    
    // Posicion, por ejemplo (100, 100)

    x = 100;
    y = 100;

    // Vamos a dibujar un píxel verde

    color = SDL_MapRGB(pantalla->format, 0, 255, 0);

    // Modificamos el píxel (x, y)

    PutPixel(pantalla, x, y, color);

    // Comprobamos que el cambio se ha realizado correctamente

    comprobacion = GetPixel(pantalla, x, y);

    if(comprobacion != color)
	fprintf(stderr, "\nCambio de color KO\n");
    else
	fprintf(stdout, "\nCambio de color OK\n");

    // Actualizamos la pantalla parar mostrar el cambio

    SDL_Flip(pantalla);
        
    // Una vez dibujado procedemos a desbloquear la superficie
    // Siempre y cuando hubiese sido bloqueada
    
    if(SDL_MUSTLOCK(pantalla))
	 SDL_UnlockSurface(pantalla);

    // Ahora mantenemos el resultado en pantalla
    // Hasta pulsar escape

    for(;;) {

        // Consultamos los eventos
	
        while(SDL_PollEvent(&evento)) {
	    
            if(evento.type == SDL_QUIT) // Si es de salida
                return 0;
        }
    }
    
}
