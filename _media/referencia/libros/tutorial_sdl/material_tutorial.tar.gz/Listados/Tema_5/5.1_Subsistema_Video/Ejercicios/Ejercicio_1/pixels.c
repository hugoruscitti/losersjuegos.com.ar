// Listado: pixels.c
// Funciones para el manejo de píxeles dentro de superficies


#include <SDL/SDL.h>
#include "pixels.h"


void PutPixel(SDL_Surface *superficie, int x, int y, Uint32 pixel) {

    // Obtenemos la profundida de color

    int bpp = superficie->format->BytesPerPixel;


    // Obtenemos la posición del píxel a sustituir

    Uint8 *p = (Uint8 *)superficie->pixels + y * superficie->pitch + x*bpp;


    // Según sea la profundidad de color

    switch (bpp) {

     case 1: // 8 bits (256 colores)

	 *p = pixel;
	 break;
	
     case 2: // 16 bits (65536 colores o HigColor)
	 *(Uint16 *)p = pixel;
	 break;

     case 3: // 24 bits (True Color)

	 // Depende de la naturaleza del sistema
	 // Puede ser Big Endian o Little Endian
	 
         if (SDL_BYTEORDER == SDL_BIG_ENDIAN) { 

	     // Calculamos cada una de las componentes de color
	     // 3 bytes, 3 posiciones

	     p[R]=(pixel >> 16) & 0xFF;
	     p[G]=(pixel >> 8) & 0xFF;
	     p[B]=pixel & 0xFF;
	 }
	 else {

	     // Calculamos cada una de las componentes de color
	     // 3 byes, 3 posiciones

	     p[R]=pixel & 0xFF;
	     p[G]=(pixel >> 8) & 0xFF;
	     p[B]=(pixel >> 16) & 0xFF;

	 }
	 break;

     case 4: // 32 bits (True Color + Alpha)

	  *(Uint32 *) p = pixel;
	  break;
   }
}




Uint32 GetPixel(SDL_Surface *superficie, int x, int y) {

    // Obtenemos la profunidad de color

    int bpp = superficie->format->BytesPerPixel;

    
    // Obtenemos la posición del píxel a consultar

    Uint8 *p = (Uint8 *)superficie->pixels + y * superficie->pitch + x * bpp;


    // Según sea la profundidad de color
    
    switch (bpp) {
  
     case 1: // 256 colores

         return *p;

     case 2: // 65536 colores

         return *(Uint16 *)p;

     case 3: // True Color

	 // Según la naturaleza del sistema

         if (SDL_BYTEORDER == SDL_BIG_ENDIAN)

	     // OR entre los distintos componentes del color
	     
	     return p[R] << 16 | p[G] << 8 | p[B];

         else

	     // OR entre los distintos componentes del color

	     return p[R] | p[G] << 8 | p[B] << 16;
	 
     case 4: // True Color + Alpha

         return *(Uint32 *)p;

     default:

         return 0;
   }
}
