// Listado: recta.h
//
// Fichero de cabecera

#ifndef _RECTA_H_
#define _RECTA_H_

// Dibuja una recta entre dos puntos p0 y p1 definidos por (x0, y0) y
// (x1, y1) del color definido por el parámetro color. 

void Recta(SDL_Surface *superficie,\
	   int x0, int y0, int x1, int y1, Uint32 color);

#endif
