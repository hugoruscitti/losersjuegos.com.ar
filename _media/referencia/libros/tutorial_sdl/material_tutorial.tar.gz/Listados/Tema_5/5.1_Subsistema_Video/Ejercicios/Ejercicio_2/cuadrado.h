// Listado: cuadrado.h
//
// Fichero de cabecera

#ifndef _RECTA_H_
#define _RECTA_H_

// Dibuja un cuadrado en la superficie, del color especificado
// en el parámetro color y con su esquina superior izquierda
// en (x, y)

void Cuadrado(SDL_Surface *superficie,\
	   int x, int y, int lado, Uint32 color);

#endif
