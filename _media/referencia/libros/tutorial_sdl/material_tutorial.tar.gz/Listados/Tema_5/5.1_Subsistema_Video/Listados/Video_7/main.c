// Listado: main.c
// Programa de prueba,
// Creación de un degradado parcial, estableciendo un área de clipping

#include <stdio.h>
#include <SDL/SDL.h>

int main()
{
    SDL_Surface *pantalla, *color_base;
    SDL_Rect posicion, clipping;
    SDL_Event evento;
    int i;

    // Iniciamos el subsistema de video SDL
    if( SDL_Init(SDL_INIT_VIDEO) < 0) {
	 fprintf(stderr, "No se pudo iniciar SDL: %s\n", SDL_GetError());
	 exit(1);
    }

    // Establecemos el modo de video
    pantalla = SDL_SetVideoMode(640, 500, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);
    if(pantalla == NULL) {
	 fprintf(stderr, "No se pudo establecer el modo de video: %s\n",\
		 SDL_GetError());
	 exit(1);
    }

    atexit(SDL_Quit);

    // Cargamos la imagen del personaje principal

    color_base = SDL_LoadBMP("Imagenes/color_base.bmp");

    if(color_base == NULL) {
	 fprintf(stderr, "No se pudo cargar la imagen: %s\n", SDL_GetError());
	 exit(1);
    }

    // Establecemos el área de clipping
    clipping.x = 0;
    clipping.y = 0;
    clipping.h = 500;
    clipping.w = 100;

    SDL_SetClipRect(pantalla, &clipping);

    // Vamos a dibujar 10 tiras
    for(i = 1; i <= 50; i++) {
	 // Ajustamos las propiedades del canal alpha para las transparecnias
	 SDL_SetAlpha(color_base, SDL_SRCALPHA|SDL_RLEACCEL, i * 5.1);

	 // Establecemos donde vamos a dibujar las tiras
	 posicion.x = 0;
	 posicion.y = 10 * (i - 1);
	 posicion.w = color_base->w;
	 posicion.h = color_base->h;

	 // Copiamos la imagen en la superficie principal
	 SDL_BlitSurface(color_base, NULL, pantalla, &posicion);
    }

    // Mostramos la pantalla "oculta" del búffer
    SDL_Flip(pantalla);

    // Liberamos los recursos que no necesitamos
    SDL_FreeSurface(color_base);

    // Ahora mantenemos el resultado en pantalla
    // hasta cerrar la ventana

    for(;;) {
	
        while(SDL_PollEvent(&evento)) {
	    
            if(evento.type == SDL_QUIT) // Si es de salida
                return 0;
        }
    }

}
