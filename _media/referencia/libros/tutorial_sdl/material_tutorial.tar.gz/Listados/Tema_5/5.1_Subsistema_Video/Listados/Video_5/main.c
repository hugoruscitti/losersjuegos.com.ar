// Listado: main.c
// Programa de prueba,
// Cargar una imagen de un personaje en pantalla, con color key

#include <stdio.h>
#include <SDL/SDL.h>

int main()
{

    SDL_Surface *pantalla, *personaje;
    SDL_Rect posicion;
    SDL_Event evento;

    // Iniciamos el subsistema de video SDL

    if( SDL_Init(SDL_INIT_VIDEO) < 0) {
	 fprintf(stderr, "No se pudo iniciar SDL: %s\n", SDL_GetError());
	 exit(1);
    }

    atexit(SDL_Quit);


    // Establecemos el modo de video

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {
	 fprintf(stderr, "No se pudo establecer el modo de video: %s\n",\
		 SDL_GetError());
	 exit(1);
    }

    // Cargamos la imagen del personaje principal

    personaje = SDL_LoadBMP("Imagenes/pprincipal.bmp");

    if(personaje == NULL) {
	 fprintf(stderr, "No se pudo cargar la imagen: %s\n", SDL_GetError());
	 exit(1);
    }

    // Establecemos el color de la transparencia
    // No será mostrado al realizar el blitting

    SDL_SetColorKey(personaje, SDL_SRCCOLORKEY|SDL_RLEACCEL,\
		    SDL_MapRGB(personaje->format, 0, 255, 0));

    // Vamos a inicializar los valores de la posicion y tamaño de la imagen

    posicion.x = 140;
    posicion.y = 180;
    posicion.w = personaje->w;
    posicion.h = personaje->h;

    // Copiamos la imagen en la superficie principal

    SDL_BlitSurface(personaje, NULL, pantalla, &posicion);

    // Mostramos la pantalla "oculta" del búffer

    SDL_Flip(pantalla);

    // Liberamos los recursos que no necesitamos

    SDL_FreeSurface(personaje);

    // Ahora mantenemos el resultado en pantalla
    // hasta cerrar la ventana
    
    for(;;) {
	
        // Consultamos los eventos
	
        while(SDL_PollEvent(&evento)) {
	    
            if(evento.type == SDL_QUIT) // Si es de salida
                return 0;
        }
    }
}
