// Listado: main.c
// Programa de prueba, 
// Crear superficies como mostrarlas por pantalla

#include <stdio.h>
#include <SDL/SDL.h>


// Vamos a cargar una imagen en una superficie
// y vamos a mostrarla por pantalla 

int main()
{

    // Declaramos los punteros para la pantalla y la imagen a cargar

    SDL_Surface *pantalla, *imagen;

    SDL_Event evento; 

    // Variable auxiliar dónde almacenaremos la posición dónde colocaremos
    // la imagen dentro de la superficie principal

    SDL_Rect destino;


    // Iniciamos el subsistema de video de SDL

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
	 fprintf(stderr,"No se pudo iniciar SDL: %s\n", SDL_GetError());
	 exit(1);
    }

    atexit(SDL_Quit);


    // Comprobamos que sea compatible el modo de video

    if(SDL_VideoModeOK(640, 480, 24, SDL_SWSURFACE) == 0) {
	
	fprintf(stderr, "Modo no soportado: %s\n", SDL_GetError());
	exit(1);
	
    }
    
    // Establecemos el modo de video y asignamos la superficie
    // principal a la variable pantalla

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE);

    if(pantalla == NULL) {
	 fprintf(stderr, "No se puede inicializar el modo gráfico: %s",\
		 SDL_GetError());
    }

    /*********************************************************************

    En este momento tenemos la librería SDL inicializada con el subsistema
    de video en marcha. Además hemos comprobado y establecido el modo
    video. En este punto se nos mostrará una ventana con una superficie 
    negra. Ahora vamos a cargar la imagen en una superficie

    ********************************************************************/


    // Cargamos un bmp en una nueva superficie para realizar las pruebas

    imagen = SDL_LoadBMP("Imagenes/ajuste.bmp");

    if(imagen == NULL) {
	 fprintf(stderr, "No se puede cargar la imagen: %s\n", SDL_GetError());
	 exit(1);
    }

    // Guardamos el BMP con otro nombre

    if(SDL_SaveBMP(imagen, "./ajuste_sdl.bmp") == -1)
	fprintf(stderr, "No se puede guardar la imagen\n");
    

    // Inicializamos la variable de posición y tamaño de destino
    destino.x = 150; // Posición horizontal con respecto a la esquina sup right
    destino.y = 120; // Posición vertical con respecto a la esq sup right
    destino.w = imagen->w;  // Longitud del ancho de la imagen
    destino.h = imagen->h;  // Longitud del alto de la imagen

    // Copiamos la superficie creada rectángulo en la anterior pantalla
    SDL_BlitSurface(imagen, NULL, pantalla, &destino);

    // Mostramos la pantalla
    SDL_Flip(pantalla);

    // Ya podemos liberar el rectángulo, una vez copiado y mostrado
    SDL_FreeSurface(imagen);

    // Ahora mantenemos el resultado en pantalla
    // hasta cerrar la ventana

    for(;;) {

        // Consultamos los eventos

        while(SDL_PollEvent(&evento)) {

            if(evento.type == SDL_QUIT) // Si es de salida
                return 0;
        }
    }

    

    return 0;
}
