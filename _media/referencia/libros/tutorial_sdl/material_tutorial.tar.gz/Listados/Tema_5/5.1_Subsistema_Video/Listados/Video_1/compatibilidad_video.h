// Listado: compatibilidad_video.h

#ifndef _COMPATIBILIDAD_SDL_
#define _COMPATIBILIDAD_SDL_

// Precondición: Subsistema de video de SDL activo.
// Postcondición: Realiza comprobaciones de compatibilidad de
// SDL con varias opciones de inicialización.


void compatibilidad_video_sdl(int w, int h, int bpp);


#endif
