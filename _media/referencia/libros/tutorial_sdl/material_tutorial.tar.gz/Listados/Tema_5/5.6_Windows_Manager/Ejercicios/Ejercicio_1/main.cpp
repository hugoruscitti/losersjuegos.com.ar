// Ejercicio 1
//
// Listado: main.cpp
// Programa de prueba
// El aspecto fundamental de esta aplicación es capturar el 
// foco de entrada en exclusividad



#include <iostream>
#include <SDL/SDL.h>

using namespace std;

int main()
{

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
	
	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
    }

    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video
    
    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {
	
        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);
	
    }

    
    // Antes de establecer el modo de video
    // Establecemos el icono y el nombre de la ventana

    // Cargamos la imagen del icono

    SDL_Surface *icono;

    icono = SDL_LoadBMP("./Imagenes/icono.bmp");

    if(icono == NULL) {

	cerr <<  "No se puede carga el icono "
	     << SDL_GetError() << endl;
	exit(1);
    }


    // Establecemos el nombre de la ventana y el icono

    SDL_WM_SetCaption("Prueba", NULL);
    SDL_WM_SetIcon(icono, NULL); // Compatible con MS Windows

    // Establecemos el modo de video

    SDL_Surface *pantalla;
   
    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {
	
	cerr << "No se pudo establecer el modo de video: "
	     << SDL_GetError() << endl;

	 exit(1);
    }

    cout << "Pulsa ESC para terminar. " << endl;
    cout << "Pulsa m para minimizar. " << endl;
    cout << "Pulsa f para cambiar a pantalla completa. " << endl;
    cout << "Pulsa g para tomar en exclusividad la entrada." << endl;

    // Variables auxiliares

    SDL_Event evento;

    // Bucle infinito

    for( ; ; ) {

	while(SDL_PollEvent(&evento)) {
	    
	     if(evento.type == SDL_KEYDOWN) {
		 
		  if(evento.key.keysym.sym == SDLK_ESCAPE)
		      return 0;

                  if(evento.key.keysym.sym == SDLK_m) {

		      // Si pulsamos m, minimizamos
		      
                      if(!SDL_WM_IconifyWindow())
			  cout << "No se puede minimizar." << endl;
                  }
                  if(evento.key.keysym.sym == SDLK_f) {

		      // Si pulsamos f pasamos a pantalla completa
		      
                      if(!SDL_WM_ToggleFullScreen(pantalla))
			  
			  cout << "No se puede pasar a pantalla completa." 
			       << endl;
                  }

		  if(evento.key.keysym.sym == SDLK_g) {
		      

		      // Si tenemos la entrada en exclusividad

		      if(SDL_GRAB_ON == SDL_WM_GrabInput(SDL_GRAB_QUERY)) {

			  SDL_WM_GrabInput(SDL_GRAB_OFF);

			  cout << "Entrada exclusiva OFF" << endl;

		      } else {

			  SDL_WM_GrabInput(SDL_GRAB_ON);

			  cout << "Entrada exclusiva ON" << endl;
		      }
		      
		  }
      
	     }
	}
	
    }
    
}
