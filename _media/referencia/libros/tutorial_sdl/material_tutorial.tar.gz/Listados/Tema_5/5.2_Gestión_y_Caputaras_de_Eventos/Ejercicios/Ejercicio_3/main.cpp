// Ejercicio 3
//
// Listado: main.cpp
//
// Programa de pruebas. Eventos de teclado
// Esta aplicación carga una imagen y nos permite moverla

#include <iostream>
#include <iomanip>

#include <SDL/SDL.h>

using namespace std;

int main()
{
    // Iremos definiendo las variables según las necesitemos

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
	cerr << "No se pudo iniciar SDL: %s\n" << SDL_GetError() << endl;;
	exit(1);
    }

    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video

    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {

        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);
	
    }


    // Establecemos el modo de video   

    SDL_Surface *pantalla;
        
    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {

	cerr << "No se pudo establecer el modo de video: "
	     << SDL_GetError() << endl;
	exit(1);

    }

    // Cargamos una imagen en una superficie

    SDL_Surface *personaje = SDL_LoadBMP("Imagenes/personaje.bmp");

    if(personaje == NULL) {

	cerr << "No se pudo cargar la imagen: "
	     << SDL_GetError() << endl;

        exit(1);
    }

    // Establecemos el color de la transparencia
    // No será mostrado al realizar el blitting

    SDL_SetColorKey(personaje, SDL_SRCCOLORKEY|SDL_RLEACCEL,\
                    SDL_MapRGB(personaje->format, 0, 255, 0));

    // Posición inicial del personaje

    SDL_Rect posicion;

    posicion.x = 300;
    posicion.y = 220;
    posicion.w = personaje->w;
    posicion.h = personaje->h;
   

    // Activamos la repetición de las teclas
    

    int repeat = SDL_EnableKeyRepeat(1,
				     SDL_DEFAULT_REPEAT_INTERVAL);

    if(repeat < 0) {
	
	cerr << "No se pudo establecer el modo repetición "
	     << SDL_GetError() << endl;
	exit(1);
    }
    

    // Copiamos la imagen en la superficie principal

    SDL_BlitSurface(personaje, NULL, pantalla, &posicion);

    // Mostramos la pantalla "oculta" del búffer

    SDL_Flip(pantalla);


    // Gestionamos la pulsancion de las teclas cursoras
    // Si se pulsa ESC salimos de la aplicación
    
    SDL_Event evento;

    for( ; ; ) {

	 while(SDL_PollEvent(&evento)) {

	     if(evento.type == SDL_KEYDOWN) {

		  switch(evento.key.keysym.sym) {

 		   case SDLK_UP:

		       posicion.y -= 4;

		       if(posicion.y < 0)
			   posicion.y = 0;

		       break;

 		   case SDLK_DOWN:

		       posicion.y += 4;

		       if(posicion.y > 380)
			   posicion.y = 380;

		       break;

		   case SDLK_RIGHT:
		       
		       posicion.x += 4;
		       
		       if(posicion.x > 560)
			   posicion.x = 560;

 		       break;

		   case SDLK_LEFT:

		       posicion.x -= 4;

		       if(posicion.x < 0)
			   posicion.x = 0;

		       break;

		   case SDLK_ESCAPE:
		       
		       SDL_FreeSurface(personaje);
		       return 0;

		   case SDLK_f:
		       
		       SDL_WM_ToggleFullScreen(pantalla);
		       break;

  		   default:
		       cout << "Ha pulsado otra tecla" << endl;
		  }
 
		  // Limpiamos la pantalla 

		  SDL_FillRect(pantalla, NULL, 0);

		  // Cambiamos la posición del personaje

		  SDL_BlitSurface(personaje, NULL, pantalla, &posicion);

		  // Actualizamos la pantalla principal
		  
		  SDL_Flip(pantalla);
		  
		  cout << " Valor x: " << setw(3) << posicion.x
		       << " Valor y: " << setw(3) << posicion.y << endl;
	     }

	     if(evento.type == SDL_QUIT) {
		
		 SDL_FreeSurface(personaje);
		 return 0;
	     }
	 }
    }

    return 0;
}
