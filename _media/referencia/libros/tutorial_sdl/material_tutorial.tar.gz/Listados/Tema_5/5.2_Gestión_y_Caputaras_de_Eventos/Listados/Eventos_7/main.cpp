// Ejemplo 7
//
// Listado: main.cpp
// Programa de pruebas. Eventos de dispositivo de juegos


#include <iostream>
#include <SDL/SDL.h>

using namespace std;

int main()
{

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK) < 0) {
	 
	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
    }

    atexit(SDL_Quit);

   // Comprobamos que sea compatible el modo de video

    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {

        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);

    }


    // Establecemos el modo de video

    SDL_Surface *pantalla;

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {

        cerr << "No se pudo establecer el modo de video: "
             << SDL_GetError() << endl;

	 exit(1);
    }

    cout << "\n\nPulse ESC para salir." << endl;
    
    SDL_Joystick *joy;
    
    // Abrimos el joystick 0
    
    joy = SDL_JoystickOpen(0);
    
    // Bucle infinito
    // Gestionamos los eventos

    SDL_Event evento;

    for( ; ; ) {

        while(SDL_PollEvent(&evento)) {

	    if(evento.type == SDL_KEYDOWN) {

                if(evento.key.keysym.sym == SDLK_ESCAPE)
                    return 0;

            }
          
	    if(evento.type == SDL_QUIT)
                return 0;
	 
	    if(evento.type == SDL_JOYAXISMOTION)
		    cout << "Eje : " << (int) evento.jaxis.axis 
			 << " -> Valor: " << evento.jaxis.value << endl;
	    
	    if(evento.type == SDL_JOYBUTTONDOWN)
		if(evento.jbutton.type == SDL_JOYBUTTONDOWN)
		    cout << "Boton: " << (int) evento.jbutton.button << endl;

	}   

    }

}
