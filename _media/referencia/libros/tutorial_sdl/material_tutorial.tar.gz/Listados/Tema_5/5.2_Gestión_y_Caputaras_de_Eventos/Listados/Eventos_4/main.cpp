// Listado 4 - Eventos
//
// Listado: main.cpp
// Programa de pruebas. Eventos de ratón
// Este programa comprueba si se ha realizado un evento de ratón 
// y muestra por consola los eventos de ratón que se van produciendo

#include <iostream>
#include <iomanip>

#include <SDL/SDL.h>

using namespace std;

int main()
{

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {

	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
	
    }


    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video
    
    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {
	
        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);
	
    }


      // Establecemos el modo de video

    SDL_Surface *pantalla;

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {

        cerr << "No se pudo establecer el modo de video: "
             << SDL_GetError() << endl;

        exit(1);
    }

    SDL_Event evento;

    // Bucle "infinito"

    for( ; ; ) {
	
	while(SDL_PollEvent(&evento)) {
	    
	    if(evento.type == SDL_KEYDOWN) {
	
		if(evento.key.keysym.sym == SDLK_ESCAPE)
		    return 0;

	    }

	    if(evento.type == SDL_QUIT)
		return 0;
	    
	    if(evento.type == SDL_MOUSEMOTION){

		cout << "X: " << setw(3) << evento.motion.x
		     << " - Y: " << setw(3) << evento.motion.y << endl;
		
	    }
	    
	    if(evento.type == SDL_MOUSEBUTTONDOWN) {

		if(evento.button.type == SDL_MOUSEBUTTONDOWN) {
		    cout << "X: " << setw(3) << evento.button.x
			 << " - Y: " << setw(3) << evento.button.y
			 << " Botón pulsado " << (int) evento.button.button << endl;
		   
		}
		
	    }
	}
    }
    
}
