// Ejercicio 5
//
// Listado: main.cpp
//
// Programa de pruebas. Eventos de teclado
// Nos permite configurar que teclas queremos utilizar
// y nos pedirá confirmación
// Esta aplicación carga una imagen y nos permite moverla

#include <iostream>
#include <iomanip>

#include <SDL/SDL.h>
#include "teclado.h"

using namespace std;

int main()
{
    // Iremos definiendo las variables según las necesitemos

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
	cerr << "No se pudo iniciar SDL: %s\n" << SDL_GetError() << endl;;
	exit(1);
    }

    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video

    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {

        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);

    }

    // Establecemos el modo de video

    SDL_Surface *pantalla;

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {

        cerr << "No se pudo establecer el modo de video: "
             << SDL_GetError() << endl;
        exit(1);

    }


    // Configuramos las teclas (versión consola)

    SDLKey teclas[6];

    configura_teclado(teclas);

    
    // Activamos la repetición de las teclas
    
    int repeat = SDL_EnableKeyRepeat(1,
				     SDL_DEFAULT_REPEAT_INTERVAL);

    if(repeat < 0) {
	
	cerr << "No se pudo establecer el modo repetición "
	     << SDL_GetError() << endl;
	exit(1);
    }

    SDL_Rect posicion;

    posicion.x = 0;
    posicion.y = 0;
    posicion.w = 1;
    posicion.h = 1;

    // Gestionamos la pulsancion de las teclas cursoras
    // Si se pulsa ESC salimos de la aplicación
    
    SDL_Event evento;

    for( ; ; ) {

	 while(SDL_PollEvent(&evento)) {

	     if(evento.type == SDL_KEYDOWN) {

		 if(teclas[UP] == evento.key.keysym.sym) {

		     posicion.y -= 4;
		     
		     if(posicion.y < 0)
			 posicion.y = 0;
		     
		 } else if(teclas[DOWN] == evento.key.keysym.sym) {

		     posicion.y += 4;
		     
		     if(posicion.y > 480)
			 posicion.y = 480;
		     
		 } else if(teclas[RIGHT] == evento.key.keysym.sym) {

		       posicion.x += 4;
		       
		       if(posicion.x > 640)
			   posicion.x = 640;

		 } else if(teclas[LEFT] == evento.key.keysym.sym) {

		       posicion.x -= 4;

		       if(posicion.x < 0)
			   posicion.x = 0;

		 } else if(teclas[QUIT] == evento.key.keysym.sym) {

		       return 0;

		 } else if(teclas[FS] == evento.key.keysym.sym) {
		 
		     cout << "Pantalla completa" << endl;
		 
		 }else {
		     
		     cout << "Tecla desconocida" << endl;
		 }

		 cout << " Valor x: " << setw(3) << posicion.x
		      << " Valor y: " << setw(3) << posicion.y << endl;
	     }
	     
	     if(evento.type == SDL_QUIT) {
		 
		 return 0;
	     }
	 }
    }

    return 0;
}
