// Listado: teclado.cpp
//
// Implementación de las funciones


#include <iostream>

#include "teclado.h"

using namespace std;



int configura_teclado(SDLKey *teclas) {

    cout << " == Configurador de teclado == \n Pulse ARRIBA"
	 << endl;
    
	
    // Evento auxiliar para guardar la tecla presionada
    
    SDL_Event evento; 
    
    
    // Configuramos las teclas principales
    
    // ARRIBA
    
    cout << "ARRIBA: ";
    
    do {
	
	SDL_WaitEvent(&evento);          // Esperamos un evento
	
    } while(evento.type != SDL_KEYDOWN); // Pero sólo de tecla presionada
    
    teclas[UP] = evento.key.keysym.sym;  // Almacenamos el símbolo
    
    cout << "OK\n Pulse ABAJO:" << endl;
    
    
    // ABAJO
    
    do {
	
	SDL_WaitEvent(&evento);
	
    } while(evento.type != SDL_KEYDOWN);
    
    teclas[DOWN] = evento.key.keysym.sym;
    
    cout << "OK \n Pulse IZQUIERDA" << endl;
    
    
    // IZQUIERDA
    
    do {
	
	SDL_WaitEvent(&evento);
	
    } while(evento.type != SDL_KEYDOWN);
    
    teclas[LEFT] = evento.key.keysym.sym;
    
    cout << "OK \n Pulse DERECHA" << endl;
    
    
    // DERECHA
    
    do {
	
	SDL_WaitEvent(&evento);
	
    } while(evento.type != SDL_KEYDOWN);
    
    teclas[RIGHT] = evento.key.keysym.sym;
    
    cout << "OK \n Pulse SALIR" << endl;
    
    // SALIR
    
    do {
	
	SDL_WaitEvent(&evento);
	
    } while(evento.type != SDL_KEYDOWN);
    
    teclas[QUIT] = evento.key.keysym.sym;
    
    cout << "OK \n Pulse PANTALLA COMPLETA" << endl;
    
    // PANTALLA COMPLETA
    
    do {
	
	SDL_WaitEvent(&evento);
	
    } while(evento.type != SDL_KEYDOWN);
    
    teclas[FS] = evento.key.keysym.sym;
    
    cout << "OK" << endl;   
    
    return 0;
}
