// Ejemplo 1
//
// Listado: main.cpp
// Programa de prueba, 
// Gestiona eventos de para salir de la aplicación

#include <iostream>
#include <SDL/SDL.h>

using namespace std;

// Este programa carga una imagen y la muestra por pantalla
// Gestiona mediante eventos la salida del programa principal

int main()
{

    // Declaramos los punteros para la pantalla y la imagen a cargar

    SDL_Surface *pantalla, *imagen;


    // Variable para la gestión del evento de salida

    SDL_Event evento;


    // Variable auxiliar dónde almacenaremos la posición dónde colocaremos
    // la imagen cargada dentro de la superficie principal

    SDL_Rect destino;

    // Iniciamos el subsistema de video de SDL

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {

	cerr << "No se pudo iniciar SDL: " <<  SDL_GetError() << endl;;
	exit(1);
    }

    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video

    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {

        cerr << "Modo no soportado: " << SDL_GetError(); 
        exit(1);

    }
  
    // Establecemos el modo de video y asignamos la superficie
    // principal a la variable pantalla

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {
	cerr << "No se pudo establecer el modo de video: \n"
	     <<  SDL_GetError() << endl;
	    
	 exit(1);
    }

    
    // Cargamos ajuste.bmp en la superficie imagen

    imagen = SDL_LoadBMP("Imagenes/ajuste.bmp");

    if(imagen == NULL) {

	cerr << "No se puede cargar la imagen: " << endl;
	exit(1);
    }
    

    // Inicializamos la variable de posición y tamaño de destino

    destino.x = 150; // Posición horizontal con respecto
                     // a la esquina superior derecha

    destino.y = 150; // Posición vertical con respecto a la
                     // esquina superior derecha

    destino.w = imagen->w;  // Longitud del ancho de la imagen
    destino.h = imagen->h;  // Longitud del alto de la imagen

    // Copiamos la superficie en la pantalla principal

    SDL_BlitSurface(imagen, NULL, pantalla, &destino);

    // Mostramos la pantalla

    SDL_Flip(pantalla);

    // Ya podemos liberar el rectángulo, una vez copiado y mostrado

    SDL_FreeSurface(imagen);

    // Gestionamos el evento pulsar una tecla
    // Esperamos que se pulsa una tecla para salir

    while(true) { // o bien for( ; ; )

	 while(SDL_PollEvent(&evento)) {

	     // ¿Se ha pulsado una tecla o es un evento de salida?

	     if(evento.type == SDL_KEYDOWN || evento.type == SDL_QUIT)
		     return 0;
	 }
    }
  

}
