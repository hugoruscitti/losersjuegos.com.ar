// Ejemplo 8
//
// Listado: main.cpp
// Programa de pruebas. Información acerca del joystick
// Abriendo un dispositivo


#include <iostream>
#include <SDL/SDL.h>

using namespace std;

int main()
{
    // Iniciamos el subsistema de video
    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK) < 0) {

	cerr << "No se pudo iniciar SDL: %s\n" << SDL_GetError();
	exit(1);
    }

    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video
    
    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {
	
        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);

    }

 
    // Consultamos el número de joysticks existentes

    int num_joysticks = SDL_NumJoysticks();

    // Si no hay joysticks conectados

    if(num_joysticks < 1) {

	cerr << "Conecte un dispositivo de juego antes de ejecutar" << endl;
	exit(1);

    } else {

	// Al menos hay uno

	cout << "Hay conectados " << num_joysticks
	     << " joysticks. " << endl;
    }

    // Mostramos información de cada uno de los joysticks

    for(int i = 0; i < num_joysticks; i++) {

	// Obtenemos el nombre del joystick

	const char *nombre = SDL_JoystickName(i);

	// Lo abrimos

	SDL_Joystick *joy = SDL_JoystickOpen(i);

	// Mostramos en pantalla toda la información 
	// disponible del joystick

	cout << "Abrimos el joystick " << nombre
	     << " - " << i << endl;
	cout << "\tTiene " << SDL_JoystickNumAxes(joy)
	     << " ejes" << endl;
	cout << "\tTiene " << SDL_JoystickNumButtons(joy)
	     << " botones" << endl;

	// Cerramos el joystick

	SDL_JoystickClose(joy);
    }
    
    return 0;
}
