// Listado 3
//
// Listado: main.cpp
//
// Programa de pruebas. Manejando el teclado conociendo su estado


#include <iostream>
#include <iomanip>
#include <SDL/SDL.h>


using namespace std;


int main()
{

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
	
	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
    }

    atexit(SDL_Quit);


    // Comprobamos que sea compatible el modo de video

    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {

        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);

    }

    // Establecemos el modo de video

    SDL_Surface *pantalla;

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {
	 
	cerr << "No se pudo establecer el modo de video: " 
	     << SDL_GetError() << endl;

	exit(1);
    }

    // Si se pulsa ESC salimos de la aplicación
    
    int x = 0;
    int y = 0;

    Uint8 *teclado;

    // Para que no imprima los valores cuando no haya cambios

    bool cambio = false;

    for( ; ; ) {

	// Actualiza el estado de los dispositivos

	SDL_PumpEvents();

	// Tomamos el estado 

	teclado = SDL_GetKeyState(NULL);

	cambio = false;

	if(teclado[SDLK_UP]) {
	    ++y;
	    cambio = true;
	}

	if(teclado[SDLK_DOWN]) {
	    --y;
	    cambio = true;
	}

	if(teclado[SDLK_RIGHT]) {
	    ++x;
	    cambio = true;
	}

	if(teclado[SDLK_LEFT]) {
	    --x;
	    cambio = true;
	}

	if(teclado[SDLK_ESCAPE] || teclado[SDLK_q]) {

	    return 0;
	}
	
	if(cambio == true)
	    cout << "Valor x: " << setw(7) << x
		 << " Valor y:" << setw(7) << y << endl;
	
    }

}
