// Listado: cursor.h
//
// Funciones para personalizar el cursor mediante una imagen XPM
//

#ifndef _CURSOR_H_
#define _CURSOR_H_

#include <SDL/SDL.h>

// Tamaño del apuntador o cursor

const int TAMANO = 32;


// Pasamos una matriz con una imagen XPM y nos devuelve 
// un cursor que utilizar con SDL
    
SDL_Cursor *Cursor_personalizado_XPM(const char *matriz[]);

#endif

