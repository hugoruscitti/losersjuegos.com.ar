// Listado: cursor.cpp
//
// Implementación

#include <iostream>
#include "cursor.h"


SDL_Cursor *Cursor_personalizado_XPM(const char *matriz[])
{
    // Variables auxiliares
    int i, fila, col;

    Uint8 data[4 * TAMANO]; // (h * w / 8)
    Uint8 mask[4 * TAMANO];
    
    //int hot_x, hot_y; 

    i = -1;

    // Recorremos toda la matriz

    for ( fila = 0; fila < TAMANO; ++fila ) { 

	for ( col = 0; col < TAMANO; ++col ) {

	    // Si no es múltiplo de 8, desplazamos

	    if ( col % 8 ) {
		
		data[i] <<= 1;
		mask[i] <<= 1;

	    } else {
		
		++i;
		data[i] = mask[i] = 0;
	    
	    }
	    
	    switch(matriz[4 + fila][col]) {
	    
	     case 'X':
		 data[i] |= 0x01;
		 mask[i] |= 0x01;
		 break;

	     case '.':
		 mask[i] |= 0x01;
		 break;

	     case ' ':
		 break;
	    }
	}
    }

  return SDL_CreateCursor(data, mask, TAMANO, TAMANO, 15, 15);
}
