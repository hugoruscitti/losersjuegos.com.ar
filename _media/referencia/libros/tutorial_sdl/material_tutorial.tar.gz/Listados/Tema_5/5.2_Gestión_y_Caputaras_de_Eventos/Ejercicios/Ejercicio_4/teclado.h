// Listado: teclado.h
//
// Funciones para la configuración del teclado


#ifndef _TECLADO_H_
#define _TECLADO_H_

#include <SDL/SDL.h>

enum Teclas {
    
    UP,
    DOWN,
    LEFT,
    RIGHT,
    QUIT,
    FS, // FullScreen
};

#define NUM_TECLAS 6

// Nos permite personalizar las teclas que queremos utiliza
// en nuestra aplicación. 
//
// Recibe el número de teclas a configurar y devuelve 
// en teclas un vector con las teclas personalizadas
//
// Para un correcto funcionamiento no debe estar activada
// la repetición de teclas en SDL


int configura_teclado(SDLKey *teclas);

#endif
