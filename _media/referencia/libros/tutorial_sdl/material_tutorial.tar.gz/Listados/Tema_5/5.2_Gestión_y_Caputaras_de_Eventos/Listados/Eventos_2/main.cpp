// Ejemplo 2
//
// Listado: main.cpp
//
// Programa de pruebas. Eventos de teclado
// Este programa comprueba si se ha realizado un evento de teclado
// en las teclas cursoras

#include <iostream>
#include <iomanip>

#include <SDL/SDL.h>

using namespace std;

int main()
{

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;;
	exit(1);
    }

    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video

    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {

        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);
	
    }


    // Establecemos el modo de video
    
    SDL_Surface *pantalla;

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {
	cerr << "No se pudo establecer el modo de video: " 
	     << SDL_GetError() << endl;
	exit(1);
    }

    // Gestionamos la pulsancion de las teclas cursoras
    // Si se pulsa ESC salimos de la aplicación

    SDL_Event evento;
    
    int x = 0;
    int y = 0;

    for( ; ; ) {

	 while(SDL_PollEvent(&evento)) {

	     if(evento.type == SDL_KEYDOWN) {

		  switch(evento.key.keysym.sym) {
 		   case SDLK_UP:
		       ++y;
		       break;

 		   case SDLK_DOWN:
		       --y;
		       break;

		   case SDLK_RIGHT:
		       ++x;
		       break;

		   case SDLK_LEFT:
		       --x;
		       break;
		   case SDLK_ESCAPE:
		       return 0;

  		   default:
		       cout << "Ha pulsado otra tecla" << endl;
		  }
		  cout << "Valor x: " << setw(2) << x << " Valor y: "
		       << setw(2) <<  y << endl;
	     }

	     if(evento.type == SDL_QUIT)
		 return 0;
	 }
    }

    return 0;
}
