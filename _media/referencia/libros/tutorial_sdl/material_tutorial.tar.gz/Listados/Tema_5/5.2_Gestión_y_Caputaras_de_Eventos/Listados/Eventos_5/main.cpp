// Listado 5 - Eventos
//
// Listado: main.cpp
// Programa de pruebas. Eventos de ratón
// Este programa comprueba si se ha realizado un movimiento de ratón
// y muestra por consola los movimientos que el ratón va produciendo
// Si pulsas un botón del ratón la aplicación termina

#include <iostream>
#include <SDL/SDL.h>

using namespace std;


int main()
{


    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
        
	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
    }

    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video

    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {

        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);

    }

    // Establecemos el modo de video

    SDL_Surface *pantalla;

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {

        cerr << "No se pudo establecer el modo de video: "
             << SDL_GetError() << endl;

	 exit(1);
    }

    // Variables auxiliares

    int x, y;

    Uint8 botones = 0;

    cout << "Pulsa un botón del ratón para salir" << endl;

    for( ; ; ) {

	// Actualiza el estado de los dispositivos
	
        SDL_PumpEvents();
	
	// Referencia para no pintar siempre la posición
	
	int x0 = x;
	int y0 = y;

	// Tomo el estado del dispositivo

	botones = SDL_GetMouseState(&x, &y);

	// Si existen cambios los muestro por consola

	if(x0 != x || y0 != y)
	    cout <<  "x: " << x << " y: " << y << endl;

	
	// Si pulso un botón salgo

	if(botones != 0)
	    return 0;


    }
}
