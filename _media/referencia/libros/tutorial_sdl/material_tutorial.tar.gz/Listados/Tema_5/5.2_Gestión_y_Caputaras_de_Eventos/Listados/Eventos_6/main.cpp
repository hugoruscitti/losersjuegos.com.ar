// Listado 6 - Eventos
//
// Listado: main.cpp
// Programa de pruebas. Eventos de ratón. Personalización del cursor
// Este programa prueba diferentes funciones 
// referentes al manejo del ratón

#include <iostream>
#include <iomanip>

#include <SDL/SDL.h>
#include "cursor.h"



using namespace std;

int main()
{

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {

	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
	
    }


    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video
    
    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {
	
        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);
	
    }


    // Establecemos el modo de video

    SDL_Surface *pantalla;

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {

        cerr << "No se pudo establecer el modo de video: "
             << SDL_GetError() << endl;

        exit(1);
    }

    // Imagen en XPM para personalizar el cursor
    
    const char *punto_mira[] = {
	
	// ancho alto  num_colors bytes_per_pixel */
	"    32    32        3           1",
	
	// definición de los colores 
	". c #000000"
	"X c #ffffff",
	"  c None",
	
	// píxels 
	"                                ", //1
	"                                ",
	"                                ",
	"                                ",
	"                                ", //5
	"                                ",
	"                                ",
	"             XXXXXX             ",
	"         XXXX  X   XXXX         ",
	"      XXX              XXX      ", //10
	"    XX                    XX    ",
	"   X           X            X   ",
	"   X           X            X   ",
	"   X           X            X   ",
	"   XX     XXXXXXXXXXX      XX   ", //15
	"   X           X            X   ",
	"   X           X            X   ",
	"   X           X            X   ",
	"   X           X            X   ",
	"    XX                    XX    ", //20
	"      XXX              XXX      ",
	"         XXXX  X   XXXX         ",
	"             XXXXXX             ",
	"                                ",
	"                                ", //25
	"                                ",
	"                                ",
	"                                ",
	"                                ",
	"                                ", // 30
	"                                ",
	"                                ", // 32
	"0,0"
    };

    // Rellenamos la pantalla de un color diferente al negro

    Uint32 color = SDL_MapRGB(pantalla->format, 25, 100, 155);

    // Sólo en el rango que vamos a permitir para el ratón

    SDL_Rect delimitador;

    delimitador.x = 100;
    delimitador.y = 100;
    delimitador.w = 440;
    delimitador.h = 280;

    SDL_FillRect(pantalla, &delimitador, color);

    // Actualizamos la pantalla

    SDL_Flip(pantalla);

    // Guardamos el cursor original

    SDL_Cursor *original = SDL_GetCursor();


    SDL_Event evento;

    // Bucle "infinito"

    for( ; ; ) {
	
	while(SDL_PollEvent(&evento)) {
	    
	    if(evento.type == SDL_KEYDOWN) {
	
		if(evento.key.keysym.sym == SDLK_ESCAPE) {
		    
		    SDL_FreeCursor(original);
		    		    
		    return 0;
		}

	    }

	    if(evento.type == SDL_QUIT)
		return 0;

	    // Movemos el ratón

	    if(evento.type == SDL_MOUSEMOTION){

		if(evento.motion.x > 540 || evento.motion.x < 100 ||
		   evento.motion.y > 380 || evento.motion.y < 100 ) {

		    // Si se sale de este rango
		    // Vuelve dentro de él
		        
		    cout << "Te has salido del rectángulo azul" << endl;

		    SDL_WarpMouse(250, 200);
		}

		cout << "X: " << setw(3) << evento.motion.x
		     << " - Y: " << setw(3) << evento.motion.y << endl;
		
	    }

	    // Pulsamos un botón del ratón

	    if(evento.type == SDL_MOUSEBUTTONDOWN) {

		if(evento.button.button == 1) {
		    cout << "X: " << setw(3) << evento.button.x
			 << " - Y: " << setw(3) << evento.button.y
			 << " Botón izquierdo pulsado, cursor personalizado" <<  endl;

		    // Personalizamos el cursor
		    
		    SDL_Cursor *apuntador;
		    
		    apuntador = Cursor_personalizado_XPM(punto_mira);
		    
		    // Lo establecemos
		    
		    SDL_SetCursor(apuntador);
	    
		    // Nos aseguramos de que se muestra

		    SDL_ShowCursor(1);
		   
		} else if(evento.button.button == 2) {   
	    
		    // Mostramos el cursor

		    SDL_ShowCursor(1);

		    // Reestablecemos el original

		    SDL_SetCursor(original);

		    cout << "Botón central, vuelta al cursor original" << endl;
		
		} else {

		    // Ocultamos el cursor
		    
		    SDL_ShowCursor(0);

		    cout << "Botón derecho pulsado, se oculta el cursor" << endl;
		}		
	    }
	}
    }
    
    return 0;
}

