// Ejemplo 10
//
// Listado: main.cpp
// Programa de pruebas. Joystick captura de movimientos
// Consultando el estado del joystick directamente
// Ignoramos los eventos de ratón y creamos un filtro 
// Para los ventos que producen la salida de la aplicación


#include <iostream>
#include <SDL/SDL.h>

using namespace std;

// Filtra los eventos de salida para no tener que
// gestionarlos en el game loop

int FiltroSalida(const SDL_Event* event);


// Programa principal
//

int main()
{

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK) < 0) {

        cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);

    }

    atexit(SDL_Quit);


   // Comprobamos que sea compatible el modo de video

    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {

        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);

    }

    // Establecemos el modo de video

    SDL_Surface *pantalla;
   
    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {
	
	cerr << "No se pudo establecer el modo de video: "
	    << SDL_GetError() << endl;

       exit(1);
    }

    // Cargamos una imagen por superficie

    SDL_Surface *personaje = SDL_LoadBMP("Imagenes/personaje.bmp");
    SDL_Surface *pausa = SDL_LoadBMP("Imagenes/pausa.bmp");
    SDL_Surface *activa = SDL_LoadBMP("Imagenes/activa.bmp");

    if(personaje == NULL) {

        cerr << "No se pudo cargar la imagen: "
             << SDL_GetError() << endl;

        exit(1);
    }
   // Establecemos el color de la transparencia
    // No será mostrado al realizar el blitting

    SDL_SetColorKey(personaje, SDL_SRCCOLORKEY|SDL_RLEACCEL,\
                    SDL_MapRGB(personaje->format, 0, 255, 0));

    // Posición inicial del personaje

    SDL_Rect posicion;

    posicion.x = 300;
    posicion.y = 220;
    posicion.w = personaje->w;
    posicion.h = personaje->h;


    // Copiamos la imagen en la superficie principal

    SDL_BlitSurface(personaje, NULL, pantalla, &posicion);
    
    // Mostramos la pantalla "oculta" del búffer
    
    SDL_Flip(pantalla);
    
    
    // Si hay un joystick conectado lo abrimos

    SDL_Joystick *joy;

    if(SDL_NumJoysticks() > 0) {

	joy = SDL_JoystickOpen(0);
	cout << "\nAbrimos el joystick " << SDL_JoystickName(0) 
	     << " para la prueba. " << endl;

    } else {
	
	cout << "Para llevar acabo esta prueba debe haber un joystick "
	     << "conectado. Si es así compruebe su configuración" << endl;

	exit(1);

    }

    // Mostramos información del dispositivo

    int num_ejes = SDL_JoystickNumAxes(joy);
    int num_botones = SDL_JoystickNumButtons(joy);

    cout << "Este joystick tiene " << num_ejes << " ejes y "
	 << num_botones << " botones." << endl;

    cout << "\nPulse ESC para salir.\n" << endl;


    // Desactivamos los eventos de ratón

    cout << "Estado evento de Ratón -> Movimiento     : " 
	 << (SDL_EventState(SDL_MOUSEMOTION, SDL_QUERY) ? "activado" : "desactivado")
	 << endl;

    cout << "Estado evento de Ratón -> Pulsación      : "  
	 << (SDL_EventState(SDL_MOUSEBUTTONDOWN, SDL_QUERY) ? "activado" : "desactivado")
	 << endl;

    cout << "Estado evento de Ratón -> Botón liberado : "  
	 << (SDL_EventState(SDL_MOUSEBUTTONUP, SDL_QUERY) ? "activado" : "desactivado")
	 << endl;
    cout << "\n == Desactivando los eventos de ratón == \n" << endl;

    SDL_EventState(SDL_MOUSEBUTTONDOWN, SDL_IGNORE);
    SDL_EventState(SDL_MOUSEBUTTONUP, SDL_IGNORE);
    SDL_EventState(SDL_MOUSEMOTION, SDL_IGNORE); 

    cout << "Estado evento de Ratón -> Movimiento     : " 
	 << (SDL_EventState(SDL_MOUSEMOTION, SDL_QUERY) ? "activado" : "desactivado")
	 << endl;

    cout << "Estado evento de Ratón -> Pulsación      : "  
	 << (SDL_EventState(SDL_MOUSEBUTTONDOWN, SDL_QUERY) ? "activado" : "desactivado")
	 << endl;

    cout << "Estado evento de Ratón -> Botón liberado : "  
	 << (SDL_EventState(SDL_MOUSEBUTTONUP, SDL_QUERY) ? "activado" : "desactivado")
	 << endl;

    
    // Establecemos el filtro creado

    SDL_SetEventFilter(FiltroSalida);


    // Variables auxiliares

    SDL_Event evento;

    // Bucle Infinito

    for( ; ; ) {
	
	
	// Actualizamos el estado del joystick
	
	SDL_JoystickUpdate();
	
	// Recorremos todos los ejes en búsqueda de cambios de estado

	for(int i = 0; i < num_ejes; i++) {
	    
	    int valor_eje = SDL_JoystickGetAxis(joy, i);
	    
	    //cout << "Eje " << i << " -> " << valor_eje << endl;
	    
	    if(valor_eje != 0) {
		
		if(i == 0) {
		    
		    if(valor_eje > 0)
			posicion.x++;
		    
		    if(valor_eje < 0)
			posicion.x--;
			
		} else {
		    
		    if(valor_eje > 0)
			posicion.y++;
		    
		    if(valor_eje < 0)
			posicion.y--;    
		}
	    }
	}
	    
	
	
	// Limpiamos la pantalla
	    
	SDL_FillRect(pantalla, NULL, 0);
	
	// Cambiamos la posición del personaje
	
	SDL_BlitSurface(personaje, NULL, pantalla, &posicion);
	
	// Actualizamos la pantalla principal
	    
	SDL_Flip(pantalla);
	
	
	
	// Recorremos todos los botones en búsqueda acciones
	
	for(int i = 0; i < num_botones; i++) {
	    
	    int pulsado = SDL_JoystickGetButton(joy, i);
	    
	    if(pulsado) {
		
		cout << "Ha pulsado el botón " << i << endl;
		
	    }
	}
	
	
	// Bucle que controla eventos de salida
	
	while(SDL_PollEvent(&evento)) {
	    
	    if(evento.type == SDL_KEYDOWN) {
		
		if(evento.key.keysym.sym == SDLK_ESCAPE) {
		    
		    SDL_JoystickClose(joy);
		    return 0;
		}
	    }
	    
	    if(evento.type == SDL_ACTIVEEVENT) {
		
		if(evento.active.gain == 0) {
		    
		    SDL_BlitSurface(pausa, NULL, pantalla, NULL);
		    
		} else {
		    
		    SDL_BlitSurface(activa, NULL, pantalla, NULL);
		    
		}
		
		SDL_Flip(pantalla);
		sleep(1);
		
	    }

	    if(evento.type == SDL_MOUSEBUTTONDOWN ||
	       evento.type == SDL_MOUSEBUTTONUP ||
	       evento.type == SDL_MOUSEMOTION) {

		cerr << "Este evento debería ser ignorado" << endl;

	    }
	    
	    if(evento.type == SDL_QUIT) {
		
		SDL_JoystickClose(joy);
		return 0;		
		
	    }
	}
    }

    SDL_JoystickClose(joy);
    return 0;
}


// Implementación de Filtro Salida

int FiltroSalida(const SDL_Event* event) {

    if(event->type == SDL_QUIT) {
	
	cout << "Cerrando aplicación" << endl;
	exit(0);		
	
    }
    
    if(event->type == SDL_KEYDOWN) {
		
	if(event->key.keysym.sym == SDLK_ESCAPE) {
		    
	    cout << "Cerrando aplicación" << endl;	    
	    exit(0);

	} else {
	    
	    cout << "Evento gestionado por el filtro" << endl;
	}
    }

    return 1;
}
