// Ejercicio 2
//
// Listado: main.cpp
//
// Programa de pruebas. Eventos de teclado
// Este programa indica si la tecla presionada
// se asocia a un carácter UNICODE o ASCII

#include <iostream>
#include <iomanip>

#include <SDL/SDL.h>

using namespace std;

int main()
{
    // Iremos definiendo las variables según las necesitemos

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
	cerr << "No se pudo iniciar SDL: %s\n" << SDL_GetError() << endl;;
	exit(1);
    }

    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video

    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {

        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);
	
    }


    // Establecemos el modo de video   

    SDL_Surface *pantalla;
        
    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {
	cerr << "No se pudo establecer el modo de video: "
	     << SDL_GetError() << endl;
	exit(1);
    }

    // Activamos los carácteres UNICODE
    
    SDL_EnableUNICODE(1);

    // Si se pulsa ESC salimos de la aplicación

    cout << "Pulsa ESC para terminar" << endl;
    
    SDL_Event evento;

    for( ; ; ) {

	 while(SDL_PollEvent(&evento)) {

	     if(evento.type == SDL_KEYDOWN) {

		 if(evento.key.keysym.unicode < 128 &&
		    evento.key.keysym.unicode != 0) {

		     cout << "Carácter  ASCII  nº "
			  << setw(3) << evento.key.keysym.unicode << endl;

		 }
 	
		 if(evento.key.keysym.unicode > 127) {

		     cout << "Carácter UNICODE nº "
			  << setw(3) << evento.key.keysym.unicode << endl;		     
		 }

		 // Tecla ESC

		 if(evento.key.keysym.unicode == 27)
		     return 0;
	     }

	     if(evento.type == SDL_QUIT)
		 return 0;
	 }
    }

    return 0;
}
