// Ejemplo 1 - Subsistema de CDROM
//
// Listado: main.cpp
// Programa de pruebas. Muestra la información del CD introducido en la unidad.


#include <iostream>
#include <SDL/SDL.h>

using namespace std;



int main()
{

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_CDROM) < 0) {

	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
	
    }


    atexit(SDL_Quit);

    // Comprobamos el número de unidades de CD

    if(SDL_CDNumDrives() < 1) {

	cout << "Debe existir alguna unidad de CD conectada" << endl;
	exit(1);

    }

    SDL_CD *unidad = SDL_CDOpen(0);

    // Mostramos la información 

    if(unidad->status != CD_TRAYEMPTY) {
	
	cout << "\nID: " << unidad->id << endl;
	cout << "Número de pistas: " << unidad->numtracks << endl;

	for(int i = 0; i < unidad->numtracks; i++) {

	    cout << "\n\tPista: " << unidad->track[i].id << endl;
	    cout << "\tLongitud: " << unidad->track[i].id / CD_FPS << endl;  
	}
	    
    } else {
	
	cout << "\nDebe introducir un CD de Audio antes" 
	     << " de ejecutar esta aplicación. " << endl;
    }
	   


    SDL_CDClose(unidad);
    
    return 0;	  
		
    
}

