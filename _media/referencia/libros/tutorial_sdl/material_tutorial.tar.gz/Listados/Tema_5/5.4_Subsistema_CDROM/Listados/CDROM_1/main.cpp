// Ejemplo 1 - Subsistema de CDROM
//
// Listado: main.cpp
// Programa de pruebas. Información CD Device


#include <iostream>
#include <iomanip>

#include <SDL/SDL.h>

using namespace std;



int main()
{

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_CDROM) < 0) {

	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
	
    }


    atexit(SDL_Quit);


    // Comprobamos el número de unidades de CD

    int num_drives = SDL_CDNumDrives();

    cout << "\nNúmero de unidades de CD: " 
	 << num_drives << endl;

    // Mostramos el nombre de las unidades de CD

    for(int i = 0; i < num_drives; i++) {

	cout << "Unidad " << i << " nombre "
	     << SDL_CDName(i) << endl;

    }

    
}

