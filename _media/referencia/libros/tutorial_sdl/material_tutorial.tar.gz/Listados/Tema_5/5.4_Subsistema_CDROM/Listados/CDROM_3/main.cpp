// Ejemplo 1 - Subsistema de CD
//
// Listado: main.cpp
// Programa de pruebas. Controlando la reproducción


#include <iostream>

#include <SDL/SDL.h>

using namespace std;



int main()
{

    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_CDROM) < 0) {

	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
	
    }


    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video
    
    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {
	
        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);
	
    }


      // Establecemos el modo de video

    SDL_Surface *pantalla;

    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);

    if(pantalla == NULL) {

        cerr << "No se pudo establecer el modo de video: "
             << SDL_GetError() << endl;

        exit(1);
    }

    // Comprobamos si existe alguna unidad de CD conectada

    if(SDL_CDNumDrives() < 1) {

	cout << "Debe existir alguna unidad de CD conectada" << endl;
	exit(1);

    }

    // Si es así abrimos por omisión la primera
 
    SDL_CD *unidad = SDL_CDOpen(0);

    // Mostramos la información 

    if(unidad->status != CD_TRAYEMPTY) {
	
	cout << "\nID: " << unidad->id << endl;
	cout << "Número de pistas: " << unidad->numtracks << endl;

	for(int i = 0; i < unidad->numtracks; i++) {

	    cout << "\n\tPista: " << unidad->track[i].id << endl;
	    cout << "\tLongitud: " << unidad->track[i].length / CD_FPS << endl;  
	}
	    
    } else {

	// Si el dispositivo de CDROM está vacío
	
	cout << "\nDebe introducir un CD de Audio antes" 
	     << " de ejecutar esta aplicación. " << endl;
    }   


    // Variables auxiliares
    
    SDL_Event evento;

    cout << "\nPulsa ESC para salir\n" << endl;
    cout << " s: Play \n t: Stop \n p: Pause - Resume \n e: Eject" << endl;

    // Bucle "infinito"

    for( ; ; ) {
	
	while(SDL_PollEvent(&evento)) {
	    
	    if(evento.type == SDL_KEYDOWN) {
		
		if(evento.key.keysym.sym == SDLK_ESCAPE) {

		    SDL_CDClose(unidad);
		    return 0;

		}

		if(evento.key.keysym.sym == SDLK_s) {
		    
		    SDL_CDPlayTracks(unidad, 0, 0,
				     unidad->numtracks,
				     unidad->track[unidad->numtracks].offset);
		}

		if(evento.key.keysym.sym == SDLK_p) {
		    
		    if(unidad->status == CD_PAUSED) {
			
			SDL_CDResume(unidad);
			
		    } else {
			
			SDL_CDPause(unidad);

		    }

		}

		if(evento.key.keysym.sym == SDLK_t) {
		    
		    SDL_CDStop(unidad);
		}

		if(evento.key.keysym.sym == SDLK_e) {

		    SDL_CDEject(unidad);

		}

		
		    


	    }
	    
	    if(evento.type == SDL_QUIT) {

		SDL_CDClose(unidad);
		return 0;	    
	    }
	    
	}
    }
    
}

