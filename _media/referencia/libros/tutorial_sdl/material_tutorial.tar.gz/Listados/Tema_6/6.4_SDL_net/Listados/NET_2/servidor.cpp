// Listado: servidor.cpp
//
// Servidor UDP usando SDL_net

#include <iostream>
#include <SDL/SDL.h>

#include <SDL/SDL_net.h>

using namespace std;

int main() {

    // Inicializamos SDL_net

    if(SDLNet_Init() < 0)  {
	
	cerr << "SDL_Init(): " << SDLNet_GetError();
	exit(1);
    
    }

    atexit(SDLNet_Quit);

    // Abrimos una conexión en el puerto 2000
    
    UDPsocket socket;

    socket = SDLNet_UDP_Open(2000);

    if(!socket) {

	cerr << "SDLNet_UDP_Open(): " << SDLNet_GetError();
	exit(1);
    }


    cout << "Servidor activo" << endl;

    // Reservamos espacio para los paquetes
    
    UDPpacket *p;

    if (!(p = SDLNet_AllocPacket(512))) {

	cerr << "SDLNet_AllocPacket:" << SDLNet_GetError() << endl;
	exit(1);
    }  

    // Bucle de control de la conexión

    bool salir = false;

    while(salir == false) {
	
	if (SDLNet_UDP_Recv(socket, p)) {

	    // Mostramos información de los datos recibidos

	    cout << "Paquete UDP recibido" << endl;
	    cout << "\tCanal:     " << p->channel << endl;
	    cout << "\tDatos:     " << (char *)p->data << endl;;
	    cout << "\tLongitud:  " << p->len << endl;
	    cout << "\tMaxlen:    " << p->maxlen << endl;
	    cout << "\tEstado:    " << p->status << endl;
	    cout << "\tDirección: " << p->address.host << " " << p->address.port << endl;
		
	    // Si el paquete contiene la palabre quit, salimos

	    if (!strcmp((char *)p->data, "quit"))

		salir = true;
	}		

    }
    

    // Liberamos memoria y salimos

    SDLNet_FreePacket(p);
    SDLNet_Quit();
    
    return 0;
}
