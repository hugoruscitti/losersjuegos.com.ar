// Listado: cliente.cpp
//
// Cliente UDP usando SDL_net


#include <iostream>
#include <SDL/SDL_net.h>

using namespace std;

 
int main(int argc, char **argv)
{

    // Comprobamos los parámetros
	
    if (argc < 3) {
	
	cerr << "Uso: "<< argv[0] << " servidor puerto" << endl;
	exit(1);
	
    }
 
    // Inicializamos SDL_net
	
    if (SDLNet_Init() < 0) {
	
	cerr << "SDLNet_Init(): " << SDLNet_GetError() << endl ;
	exit(1);
    }

    // Abrimos un socket en un puerto aleatorio (0)
    
    UDPsocket socket;

    if (!(socket = SDLNet_UDP_Open(0))) {

	cerr << "SDLNet_UDP_Open(): " << SDLNet_GetError() << endl;
	exit(1);
    }

    // Resolvemos el host (servidor)

    IPaddress ip_server;

    if (SDLNet_ResolveHost(&ip_server, argv[1], atoi(argv[2])) < 0) {
	
	cerr << "SDLNet_ResolveHost(): "<< SDLNet_GetError() << endl;
	exit(1);

    }

    // Reservamos memoria para los paquetes

    UDPpacket *p;

    if (!(p = SDLNet_AllocPacket(512))) {

	cerr << "SDLNet_AllocPacket(): " << SDLNet_GetError() << endl;
	exit(1);

    }

    // Enviamos los mensajes

    bool terminar = false;
    
    while(terminar == false) {

	cout << "Rellena el búffer :> " ;
	cin >> ((char *) p->data);
 
	p->address.host = ip_server.host;  // Establecemos el destino
	p->address.port = ip_server.port;  // y el puerto
	
	// Longitud + 1

	p->len = strlen((char *)p->data) + 1;

	SDLNet_UDP_Send(socket, -1, p);        // Establecemos el canal
 
	// Si el paquete contiene "quit" salimos

	if (!strcmp((char *)p->data, "quit"))
	    
	    terminar = true;
    }
    
    SDLNet_FreePacket(p);
    SDLNet_Quit();
    
    return 0;
}
