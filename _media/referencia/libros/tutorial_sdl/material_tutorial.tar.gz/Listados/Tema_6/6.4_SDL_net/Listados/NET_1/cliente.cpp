// Listado: cliente.cpp
//
// Cliente TCP usando SDL_net


#include <iostream>
#include <SDL/SDL_net.h>

using namespace std;

 
int main(int argc, char **argv)
{

    // Comprobamos los parámetros
	
    if (argc < 3) {
	
	cerr << "Uso: "<< argv[0] << " servidor puerto" << endl;
	exit(1);
	
    }
 
    // Inicializamos SDL_net
	
    if (SDLNet_Init() < 0) {
	
	cerr << "SDLNet_Init(): " << SDLNet_GetError() << endl ;
	exit(1);
    }

    // Resolvemos el host (servidor)

    IPaddress ip;

    if (SDLNet_ResolveHost(&ip, argv[1], atoi(argv[2])) < 0) {
	
	cerr << "SDLNet_ResolveHost(): "<< SDLNet_GetError() << endl;
	exit(1);

    }

    // Abrimos una conexión con la IP provista
    
    TCPsocket socket;

    if (!(socket = SDLNet_TCP_Open(&ip))) {

	cerr << "SDLNet_TCP_Open: " << SDLNet_GetError() << endl;
	exit(1);
    }
 
    // Enviamos los mensaje

    bool terminar = false;
    char buffer[512];
    int longitud;
    
    while(terminar == false) {

	cout << "Escribe algo :> " ;
	cin >> buffer;
 
	// Lo escrito + terminador
	
	longitud = strlen(buffer) + 1;

	// Lo enviamos

	if (SDLNet_TCP_Send(socket, (void *)buffer, longitud) < longitud) {
	    
	    cerr << "SDLNet_TCP_Send: " << SDLNet_GetError() << endl;;
	    exit(1);
	}

	// Si era salir o cerrar, terminamos con la conexión
 
	if(strcmp(buffer, "exit") == 0)
	    terminar = true;

	if(strcmp(buffer, "quit") == 0)
	    terminar = true;
    }
    
    SDLNet_TCP_Close(socket);
    SDLNet_Quit();
    
    return 0;
}
