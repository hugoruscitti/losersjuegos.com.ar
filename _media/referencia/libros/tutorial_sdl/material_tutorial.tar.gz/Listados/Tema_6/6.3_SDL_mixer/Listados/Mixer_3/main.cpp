// Ejemplo 3
//
// Listado: main.cpp
// Programa de pruebas. Reproduciendo sonidos en grupos


#include <iostream>
#include <SDL/SDL.h>

#include <SDL/SDL_mixer.h>

using namespace std;

int main()
{
    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
	
	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
    }

    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video
    
    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {
	
        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);
	
    }

    // Antes de establecer el modo de video
    // Establecemos el nombre de la ventana

    SDL_WM_SetCaption("Prueba. SDL_mixer", NULL);

    // Establecemos el modo

    SDL_Surface *pantalla;
    
    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);
    
    if(pantalla == NULL) {
	
	cerr << "No se pudo establecer el modo de video: "
	     << SDL_GetError();
	
	exit(1);
    }

    // Inicializamos la librería SDL_Mixer

    if(Mix_OpenAudio(MIX_DEFAULT_FREQUENCY, MIX_DEFAULT_FORMAT,\
		     MIX_DEFAULT_CHANNELS, 4096) < 0) {
	
	cerr << "Subsistema de Audio no disponible" << endl;
	exit(1);
    }

    // Cargamos un sonido

    Mix_Chunk *sonido1, *sonido2;

    sonido1 = Mix_LoadWAV("./Sonidos/space.wav");
    sonido2 = Mix_LoadWAV("./Sonidos/aplauso.wav");

    if(sonido1 == NULL || sonido2 == NULL) {
	
	cerr << "Error al cargar los sonidos" << endl;
	exit(1);

    }
    

    // Establecemos el volumen para el sonido

    int volumen = 100;

    Mix_VolumeChunk(sonido1, volumen);
    Mix_VolumeChunk(sonido2, volumen);

    
    // Creamos cuatro canales

    Mix_AllocateChannels(4);

    
    // Reservo los cuatro canales
    // Para que no estén a disposición de SDL_mixer

    Mix_ReserveChannels(4);
	    
    // Creamos dos grupos de canales

    // UNO: Canales 0 y 1

    Mix_GroupChannel(0, 1);
    Mix_GroupChannel(1, 1);

    // DOS: Canales 2 y 3

    Mix_GroupChannels(2, 3, 2);

    cout << "Canales creados" << endl;

    // Mostramos información de los grupos

    cout << "Información de los canales" << endl;

    cout << "---------------------- " << endl;

    cout << "Grupo 1: " << Mix_GroupCount(1) << " canales" << endl;
    cout << "Grupo 2: " << Mix_GroupCount(2) << " canales" << endl;

    cout << "---------------------- " << endl;


    // Introducimos los sonidos en canales
    
    Mix_PlayChannel(1, sonido1, -1);
    Mix_PlayChannel(3, sonido2, -1);

    // Variables auxiliares

    SDL_Event evento;
    SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY,\
			SDL_DEFAULT_REPEAT_INTERVAL);

    cout << "Pulse ESC para salir" << endl;
    cout << "Pulse Q para subir el volumen" << endl;
    cout << "Pulse A para bajar el volumen" << endl;
    cout << "Pulse P para pausar la reproducción del grupo 1" << endl;
    cout << "Pulse O para pausar la reproducción del grupo 2" << endl;
    cout << "Pulse F para producir un fade out del grupo 1" << endl;
    cout << "Pusel I para producir un fade out del grupo 2" << endl;
    cout << "Pulse H para mostrar la ayuda" << endl;

    // Bucle infinito 
    
    for( ; ; ) {

	// RECUERDA: -1 en SDL_Mixer en las llamadas a función
	// simboliza infinito

        while(SDL_PollEvent(&evento)) {

            if(evento.type == SDL_KEYDOWN) {

                if(evento.key.keysym.sym == SDLK_ESCAPE) {

		    // Liberamos los sonidos
		    
		    Mix_FreeChunk(sonido1);
		    Mix_FreeChunk(sonido2);		    
		    
		    // Cerramos el sistema de audio
		    // al terminar de trabajar con él
		    
		    atexit(Mix_CloseAudio);

		    cout << "Gracias" << endl;
	 

		    return 0;
		}

		// Manejo del Volumen

		if(evento.key.keysym.sym == SDLK_q) {
		    
		    volumen += 2;
		    
		    if(volumen < 128) {
			Mix_VolumeChunk(sonido1, volumen);
			Mix_VolumeChunk(sonido2, volumen);
		    }
		    else
			volumen = 128;

		    cout << "Volumen actual: " << volumen << endl;

		}

		if(evento.key.keysym.sym == SDLK_a) {
		    
		    volumen -= 2;
		    
		    if(volumen > -1) {
			Mix_VolumeChunk(sonido1, volumen);
			Mix_VolumeChunk(sonido2, volumen);
		    }
		    else
			volumen = 0;
		    
		    cout << "Volumen actual: " << volumen << endl;
		    
		}
		
		// Manejo de la reproducción
		
		if(evento.key.keysym.sym == SDLK_p) {
		    
		    Mix_HaltGroup(1);
		    cout << "Grupo 1 parado" << endl;
		}

		if(evento.key.keysym.sym == SDLK_o) {
		    
		    Mix_HaltGroup(2);
		    cout << "Grupo 2 parado" << endl;
		}
		
		// Efectos
		
		if(evento.key.keysym.sym == SDLK_f) {

		    int num;

		    num = Mix_FadeOutGroup(1, 5000);
		    
		    cout << "FadeOut 1: " << num << " canales" << endl;
		    
		}
		
		if(evento.key.keysym.sym == SDLK_i) {

		    int num;

		    num = Mix_FadeOutGroup(2, 5000);
		    
		    cout << "FadeOut 2: " << num << " canales" << endl;
		
		}

		if(evento.key.keysym.sym == SDLK_h) {

		    cout << "\n == AYUDA == " << endl;


		    cout << "Pulse ESC para salir" << endl;
		    cout << "Pulse Q para subir el volumen" << endl;
		    cout << "Pulse A para bajar el volumen" << endl;
		    cout << "Pulse P para pausar la reproducción del grupo 1" << endl;
		    cout << "Pulse O para pausar la reproducción del grupo 2" << endl;
		    cout << "Pulse F para producir un fade out del grupo 1" << endl;
		    cout << "Pusel I para producir un fade out del grupo 2" << endl;
		    cout << "Pulse H para mostrar la ayuda" << endl;
		    
		    
		}
		
	    }
	    
	}
    }
    
}
