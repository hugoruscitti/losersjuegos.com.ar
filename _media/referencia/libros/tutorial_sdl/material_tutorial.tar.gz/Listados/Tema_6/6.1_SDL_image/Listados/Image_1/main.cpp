// Ejemplo 1
//
// Listado: main.cpp
// Programa de pruebas. Utilizando SDL_image


#include <iostream>
#include <SDL/SDL.h>

#include <SDL/SDL_image.h>

using namespace std;

int main()
{
    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
	
	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
    }

    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video
    
    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {
	
        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);
	
    }

    // Antes de establecer el modo de video
    // Establecemos el nombre de la ventana

    SDL_WM_SetCaption("Ejemplo 1. SDL_image", NULL);

    // Establecemos el modo

    SDL_Surface *pantalla;
    
    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);
    
    if(pantalla == NULL) {
	
	cerr << "No se pudo establecer el modo de video: "
	     << SDL_GetError();
	
	exit(1);
    }

    // Variables auxiliares

    SDL_Event evento;

    // Cargamos la imagen en formato GIF

    SDL_Surface *imagen = IMG_Load("Imagenes/negritos.gif");

    // La mostramos por pantalla

    SDL_BlitSurface(imagen, NULL, pantalla, NULL);
    SDL_Flip(pantalla);

    cout << "\n Cargada imagen en formato GIF" << endl;
    cout << "Pulsa una tecla para cargar otro formato de imagen. " << endl;


    // Esperamos que se produzca un evento de teclado

    do {
	
	SDL_WaitEvent(&evento);
		
    } while(evento.type != SDL_KEYDOWN);


    /****************************************************************/

    // Cargamos la imagen en formato JPG

    imagen = IMG_Load("Imagenes/negritos.jpg");

    // La mostramos por pantalla

    SDL_BlitSurface(imagen, NULL, pantalla, NULL);
    SDL_Flip(pantalla);

    cout << "\n Cargada imagen en formato JPG" << endl;
    cout << "Pulsa una tecla para cargar otro formato de imagen. " << endl;


    // Esperamos que se produzca un evento de teclado

    do {
	
	SDL_WaitEvent(&evento);
		
    } while(evento.type != SDL_KEYDOWN);


    /****************************************************************/

    // Cargamos la imagen en formato png

    imagen = IMG_Load("Imagenes/negritos.png");

    // La mostramos por pantalla

    SDL_BlitSurface(imagen, NULL, pantalla, NULL);
    SDL_Flip(pantalla);

    cout << "\n Cargada imagen en formato PNG" << endl;
    cout << "Pulsa una tecla para cargar otro formato de imagen. " << endl;

    // Esperamos que se produzca un evento de teclado

    do {
	
	SDL_WaitEvent(&evento);
		
    } while(evento.type != SDL_KEYDOWN);


    /****************************************************************/

    // Cargamos la imagen en formato tga

    imagen = IMG_Load("Imagenes/negritos.tga");

    // La mostramos por pantalla

    SDL_BlitSurface(imagen, NULL, pantalla, NULL);
    SDL_Flip(pantalla);

    cout << "\n Cargada imagen en formato TGA" << endl;
    cout << "Pulsa una tecla para cargar otro formato de imagen. " << endl;

    // Esperamos que se produzca un evento de teclado

    do {
	
	SDL_WaitEvent(&evento);
		
    } while(evento.type != SDL_KEYDOWN);

    /****************************************************************/

    // Cargamos la imagen en formato XPM

    imagen = IMG_Load("Imagenes/negritos.xpm");

    // La mostramos por pantalla

    SDL_BlitSurface(imagen, NULL, pantalla, NULL);
    SDL_Flip(pantalla);

    cout << "\n Cargada imagen en formato XPM" << endl;
    cout << "Pulsa una tecla para terminar. " << endl;

    // Esperamos que se produzca un evento de teclado

    do {
	
	SDL_WaitEvent(&evento);
		
    } while(evento.type != SDL_KEYDOWN);

    return 0;
}
