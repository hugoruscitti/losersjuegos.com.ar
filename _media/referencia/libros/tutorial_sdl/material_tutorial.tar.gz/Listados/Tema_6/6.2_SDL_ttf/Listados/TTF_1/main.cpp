// Ejemplo 1
//
// Listado: main.cpp
// Programa de pruebas. Utilizando fuentes ttf


#include <iostream>
#include <SDL/SDL.h>

#include <SDL/SDL_ttf.h>

using namespace std;

int main()
{
    // Iniciamos el subsistema de video

    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
	
	cerr << "No se pudo iniciar SDL: " << SDL_GetError() << endl;
	exit(1);
    }

    atexit(SDL_Quit);

    // Comprobamos que sea compatible el modo de video
    
    if(SDL_VideoModeOK(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF) == 0) {
	
        cerr << "Modo no soportado: " << SDL_GetError() << endl;
        exit(1);
	
    }

    // Inicializamos la librería TTF

    if(TTF_Init() == 0) {

	atexit(TTF_Quit);
        cout << "TTF inicializada" << endl;
	
    }
  
    // Antes de establecer el modo de video
    // Establecemos el nombre de la ventana

    SDL_WM_SetCaption("Hola Mundo. SDL_ttf", NULL);

    // Establecemos el modo

    SDL_Surface *pantalla;
    
    pantalla = SDL_SetVideoMode(640, 480, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);
    
    if(pantalla == NULL) {
	
	cerr << "No se pudo establecer el modo de video: "
	     << SDL_GetError();
	
	exit(1);
    }

    // Cargamos la fuente que vamos a utilizar de tamaño 40
    
    TTF_Font *fuente;

    fuente = TTF_OpenFont("Fuentes/ep.ttf", 40);

    // Mostramos información acerca de la fuente cargada

    cout << "El tamaño de la fuente es " <<  TTF_FontHeight(fuente) << endl;
    cout << "El ascendente de la fuente es " << TTF_FontAscent(fuente) << endl;
    cout << "El descendente de la fuente es " << TTF_FontDescent(fuente) << endl;
    cout << "La separación entre líneas es " << TTF_FontLineSkip(fuente) << endl;
    
    int w, h;

    TTF_SizeUTF8(fuente, "Hola Mundo", &w, &h);

    cout << "El mensaje Hola Mundo ocupará " << w << " píxeles de ancho"
	 << " y " << h << " de alto." << endl;

    // Vamos a escribir HolaMundo

    SDL_Surface *texto;
    SDL_Color color;

    // Establecemos el color para la fuente

    color.r = 25;
    color.g = 150;
    color.b = 180;

    // Renderizamos

    texto = TTF_RenderText_Blended(fuente, "Hola Mundo", color);

    // Establecemos la posición

    SDL_Rect dest;

    dest.x = 150;
    dest.y = 100;
    dest.h = texto->h;
    dest.w = texto->w;

    // Mostramos el texto por pantalla

    SDL_BlitSurface(texto, NULL, pantalla, &dest);
  
    SDL_Flip(pantalla);

    // Mostramos el resultado durante 5 seg

    SDL_Delay(5000);
    
    
    return 0;
}
