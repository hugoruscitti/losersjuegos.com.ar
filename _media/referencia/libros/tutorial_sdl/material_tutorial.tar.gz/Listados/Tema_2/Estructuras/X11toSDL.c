// Códig de X11 migrado a SDL


int init_x (int X, int Y, int W, int H, int bpp, const char *Name)
{

    int i;
    if ( SDL_Init(SDL_INIT_VIDEO) < 0 ) {
	    fprintf ( stderr , "Erreur :\n" );
	    fprintf ( stderr , " Impossible de se connecter au Display\n");
	    exit (1);
    }

    screen = SDL_SetVideoMode(W, H, bpp, SDL_SWSURFACE|SDL_HWPALETTE);

    if ( screen == NULL ) {
	    fprintf ( stderr , "Erreur :\n" );
	    fprintf ( stderr , " Impossible de se connecter au Display\n");
	    exit (1);
    }

    SDL_WM_SetCaption ( Name, Name );

    for ( i=SDL_NOEVENT; i<SDL_NUMEVENTS; ++i )
	if ( (i != SDL_KEYDOWN) && (i != SDL_QUIT) )
	    SDL_EventState(i, SDL_IGNORE);

    depth = screen->format->BitsPerPixel;
    width = screen->w;
    height = screen->h;
    buffer = (unsigned char *)screen->pixels;
    return (depth);
}
