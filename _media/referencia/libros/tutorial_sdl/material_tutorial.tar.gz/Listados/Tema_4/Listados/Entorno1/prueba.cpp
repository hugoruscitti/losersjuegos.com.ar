// Listado: prueba.cpp
// Hola Mundo

#include <stdio.h>
#include <SDL/SDL.h>             // Incluimos la librería SDL


int main() {

    SDL_Surface *pantalla;       // Definimos una superficie
    SDL_Event evento;            // Definimos una variable de ventos


    // Inicializamos SDL

    if(SDL_Init(SDL_INIT_VIDEO)) {
	
	// En caso de error
	
	fprintf(stderr, "Error al inicializar SDL: %s\n", SDL_GetError());
	exit(1);

    }

    atexit(SDL_Quit);            // Al salir, cierra SDL

    // Establecemos el modo de pantalla

    pantalla = SDL_SetVideoMode(640, 480, 0, SDL_ANYFORMAT);

    if(pantalla == NULL) {

	// Si no hemos podido inicializar la superficie
	
	fprintf(stderr, "Error al crear la superficie: %s\n", SDL_GetError());
	exit(1);
    
    }

    // Personalizamos el título de la ventana

    SDL_WM_SetCaption("HOLA MUNDO", NULL);

    
    // Bucle infinito

    for(;;) {
	
	// Consultamos los eventos

	while(SDL_PollEvent(&evento)) {

	    if(evento.type == SDL_QUIT) // Si es de salida
		return 0;
	}
    }

}
