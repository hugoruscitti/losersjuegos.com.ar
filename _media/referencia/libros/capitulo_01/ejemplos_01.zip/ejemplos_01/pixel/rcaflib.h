#ifndef RCAFLIB_H
#define RCAFLIB_H

#include <SDL/SDL.h>

void showerror(char *msg);
void putpixel(SDL_Surface *screen, int x, int y, SDL_Color color);
SDL_Color getpixel(SDL_Surface *screen, int x, int y);
void lock(SDL_Surface *screen);
void unlock(SDL_Surface *screen);

#endif
