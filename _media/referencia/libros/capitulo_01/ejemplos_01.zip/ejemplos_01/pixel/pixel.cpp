/*

  NOMBRE: pixel.cpp

  DESCRIPCION: Coloca pixeles al azar en la pantalla.

  AUTOR: Roberto Albornoz Figueroa
         rcaf@latinmail.com 

*/

#include <SDL/SDL.h>
#include <stdlib.h>
#include "rcaflib.h"

#define SCREEN_W 640
#define SCREEN_H 480
#define BPP 16
SDL_Surface *screen;

void init();
void game();

int main(int argc, char **argv)
{
  init();
  game();

  return 0;
}

void init()
{
  if(SDL_Init(SDL_INIT_VIDEO) < 0) showerror("al inicializar SDL");
  atexit(SDL_Quit);

  SDL_WM_SetCaption("Colocando pixeles al azar", 0);

  screen=SDL_SetVideoMode(SCREEN_W, SCREEN_H, BPP, SDL_HWSURFACE|SDL_DOUBLEBUF);
  if(!screen) showerror("al inicializar modo grafico");
}

void game()
{
  SDL_Event event;
  SDL_Color color;
  int salir=0;

  while(!salir)
  {
    while(SDL_PollEvent(&event))
    {
      if(event.type==SDL_QUIT) salir=1;
    }
    lock(screen);
    color.r=rand()%256;
    color.g=rand()%256;
    color.b=rand()%256;
    putpixel(screen, rand()%SCREEN_W, rand()%SCREEN_H, color);
    unlock(screen);
    SDL_Flip(screen);
  }
}

