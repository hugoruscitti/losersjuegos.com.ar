#include "rcaflib.h"
#include <stdlib.h>

// Muestra un mensaje de error y sale del programa
void showerror(char *msg)
{
  fprintf(stderr, "Error %s: %s", msg, SDL_GetError());
  exit(1);
}

// Coloca un pixel en una posicion determinada de screen
void putpixel(SDL_Surface *screen, int x, int y, SDL_Color color)
{
  // Convertimos color
  Uint32 col=SDL_MapRGB(screen->format, color.r, color.g, color.b);

  // Determinamos posicion de inicio
  char *buffer=(char*) screen->pixels;

  // Calculamos offset para y
  buffer+=screen->pitch*y;

  // Calculamos offset para x
  buffer+=screen->format->BytesPerPixel*x;

  // Copiamos el pixel
  memcpy(buffer, &col, screen->format->BytesPerPixel);
}

// Obtiene un pixel de una posicion determinada de screen
SDL_Color getpixel(SDL_Surface *screen, int x, int y)
{
  SDL_Color color;
  Uint32 col;

  // Determinamos posicion de inicio
  char *buffer=(char *) screen->pixels;

  // Calculamos offset para y
  buffer+=screen->pitch*y;

  // Calculamos offset para x
  buffer+=screen->format->BytesPerPixel*x;

  // Obtenemos el pixel
  memcpy(&col, buffer, screen->format->BytesPerPixel);

  // Descomponemos el color
  SDL_GetRGB(col, screen->format, &color.r, &color.g, &color.b);

  // Devolvemos el color
  return color;
}

// Bloque la superficie si es necesario
void lock(SDL_Surface *screen)
{
  if(SDL_MUSTLOCK(screen))
    SDL_LockSurface(screen);
}

// Desbloquea la superficie si es necesario
void unlock(SDL_Surface *screen)
{
  if(SDL_MUSTLOCK(screen))
    SDL_UnlockSurface(screen);
}

