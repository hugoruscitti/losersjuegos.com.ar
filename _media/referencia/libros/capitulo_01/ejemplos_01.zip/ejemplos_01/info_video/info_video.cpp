/*

  NOMBRE: info_video.cpp

  DESCRIPCION: Muestra como obtener informacion de la tarjeta de video,
               conocer si algun modo de video en particular se
               encuentra disponible y ver, si es posible, una lista de modos
               de video.

  AUTOR: Roberto Albornoz Figueroa
         rcaf@latinmail.com

*/

#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>

int main(int argc, char **argv)
{
	const SDL_VideoInfo *info;
  SDL_Rect **modos;
  char nombre_driver[81];

  if(SDL_Init(SDL_INIT_VIDEO) < 0)
  {
    printf("Error al inicializar la libreria SDL\n");
    exit(1);
  }

  if(SDL_VideoModeOK(640, 480, 16, SDL_HWSURFACE))
    printf("El modo 640x480x16 esta disponible\n");
	else
    printf("El modo 640x480x16 no esta disponible\n");

  info=SDL_GetVideoInfo();
  printf("Total memoria de video: %d Kb\n", info->video_mem);
  if(info->blit_hw==1)
    printf("Aceleracion de volcados de superficies disponible\n");
  else
    printf("Aceleracion de volcados de superficies no disponible\n");

  SDL_VideoDriverName(nombre_driver, 81);
	printf("Driver tarjeta de video: %s\n", nombre_driver);

  modos=SDL_ListModes(NULL, SDL_FULLSCREEN);
  if(modos==(SDL_Rect **)0)
    printf("No existen modos disponibles\n");
  else if(modos==(SDL_Rect **)-1)
    printf("Todos los modos disponibles\n");
  else
	{
    printf("Lista de modos disponibles:\n");
    for(int i=0; modos[i]; i++)
      printf("%dx%dx%d\n", modos[i]->w, modos[i]->h,
        info->vfmt->BitsPerPixel);
	}

	SDL_Quit();
	
	return 0;
}

