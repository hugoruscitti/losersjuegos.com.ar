/*
 * mouse: basado en el ejemplo `mouse_event` de www.losersjuegos.com.ar
 * 
 * Copyright (C) 2006 Hugo Ruscitti
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <stdlib.h>
#include "SDL.h"

typedef struct mouse
{
	int x;
	int y;
	SDL_Surface * ima;
} Mouse;


#define R 92
#define G 110
#define B 137

SDL_Surface * iniciar_sdl (int w, int h, char * titulo);
void terminar_programa (Mouse * mouse);
int mouse_crear (Mouse * mouse);
void mouse_imprimir (Mouse * mouse, SDL_Surface * screen);


int main (int argc, char * argv [])
{
	SDL_Surface * screen;
	SDL_Event event;
	Mouse mouse;

	screen = iniciar_sdl (320, 240, "Mouse");

	if (! screen)
		exit (1);

	SDL_ShowCursor (SDL_DISABLE);
	
	if (mouse_crear (& mouse))
		exit (1);

	
	/* con `SDL_WaitEvent` se bloquea el programa hasta
	 * que se produce un evento. */
	
	while (SDL_WaitEvent (&event))
	{
		switch (event.type)
		{
			case SDL_QUIT:
				terminar_programa (& mouse);
				break;

			case SDL_MOUSEMOTION:
				mouse.x = event.motion.x;
				mouse.y = event.motion.y;
				
				mouse_imprimir (& mouse, screen);
				break;
			
			default:
				break;
		}
	}

	terminar_programa (& mouse);
	return 0;
}


void terminar_programa (Mouse * mouse)
{
	SDL_FreeSurface (mouse->ima);
	exit (0);
}


int mouse_crear (Mouse * mouse)
{
	mouse->ima = SDL_LoadBMP ("ima/cursor.bmp");

	if (! mouse->ima)
	{
		printf ("%s\n", SDL_GetError ());
		return 1;
	}

	return 0;
}


void mouse_imprimir (Mouse * mouse, SDL_Surface * screen)
{
	static SDL_Rect rect_anterior = {0, 0, 0, 0};
	SDL_Rect rect;

	rect.x = mouse->x - 30;
	rect.y = mouse->y - 29;

	SDL_BlitSurface (mouse->ima, NULL, screen, & rect);

	SDL_UpdateRects (screen, 1, & rect_anterior);
	SDL_UpdateRects (screen, 1, & rect);
	
	SDL_FillRect (screen, &rect,SDL_MapRGB (screen->format, R, G, B));
	rect_anterior = rect;
}


SDL_Surface * iniciar_sdl (int w, int h, char * titulo)
{
	int flags = SDL_SWSURFACE;
	SDL_Surface * screen;
	Uint32 color;
	
	if (SDL_Init (SDL_INIT_VIDEO) == -1)
	{
		printf ("%s\n", SDL_GetError ());
		return NULL;
	}

	atexit (SDL_Quit);

	SDL_WM_SetCaption (titulo, NULL);
	
	screen = SDL_SetVideoMode (w, h, 16, flags);
	
	if (! screen)
	{
		printf ("%s\n", SDL_GetError ());
		return NULL;
	}

	color = SDL_MapRGB (screen->format, R, G, B);
	SDL_FillRect (screen, NULL, color);
	SDL_Flip (screen);
	
	return screen;
}
