/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#include "pelota.h"

#define MASK 255, 0, 255

int pelota_iniciar (Pelota ** _pelota)
{
	Pelota * pelota;

	pelota = (Pelota *) malloc (sizeof (Pelota));

	if (pelota == NULL)
	{
		printf ("No se puede crear la pelota del juego.\n");
		return 1;
	}

	pelota->x = 20;
	pelota->y = 80;
	pelota->velocidad = 0;
	pelota->direccion = 1;
	
	pelota->imagen = cargar_imagen ("ima/pelota.bmp", 1);

	if (pelota->imagen == NULL)
	{
		free (pelota);
		return 1;
	}

	(*_pelota) = pelota;
	return 0;
}

void pelota_actualizar (Pelota * pelota)
{
	pelota->velocidad += GRAVEDAD;
	pelota->y += (pelota->velocidad >> 4);

	pelota->x += pelota->direccion * 2;

	if (pelota->x > 590)
		pelota->direccion = -1;

	if (pelota->x < 0)
		pelota->direccion = 1;
	
	if (pelota->y > 375)
	{
		pelota->y = 375;
		pelota->velocidad = -100;
	}
}

void pelota_imprimir (Pelota * pelota, Dirty * dirty, SDL_Surface * screen)
{
	SDL_Rect area;

	area.x = pelota->x;
	area.y = pelota->y;
	
	SDL_BlitSurface (pelota->imagen, NULL, screen, & area);
	dirty_agregar (dirty, & area);
}



void pelota_terminar (Pelota * pelota)
{
	SDL_FreeSurface (pelota->imagen);
	free (pelota);
	printf ("- Liberando la Pelota\n");
}
