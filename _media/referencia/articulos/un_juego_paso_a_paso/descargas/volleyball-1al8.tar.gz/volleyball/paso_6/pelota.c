/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#include "pelota.h"

int pelota_iniciar (Pelota ** _pelota)
{
	Pelota * pelota;

	pelota = (Pelota *) malloc (sizeof (Pelota));

	if (pelota == NULL)
	{
		printf ("No se puede crear la pelota del juego.\n");
		return 1;
	}

	pelota->imagen = cargar_imagen ("ima/pelota.bmp", 1);

	if (pelota->imagen == NULL)
	{
		free (pelota);
		return 1;
	}

	pelota->x = 100;
	pelota->y = 50;

	pelota->vy = 0.1;
	pelota->vx = 0.1;
	
	pelota->angulo = PI / 2;
	(*_pelota) = pelota;
	return 0;
}

float suma (float angulo_1, float angulo_2, float angulo_3)
{
	return (angulo_3 + angulo_2 - angulo_1);
}

void pelota_actualizar (Pelota * pelota, Personaje * p1, Personaje * p2)
{
	
	pelota->vy -= 0.04;

	pelota->x += pelota->vx;
	pelota->y -= pelota->vy;

	if (pelota->x < PELOTA_RADIO)
	{
		pelota->x = PELOTA_RADIO;
		pelota->vx *= -1;
	}

	if (pelota->x > 640 - PELOTA_RADIO)
	{
		pelota->x = 640 - PELOTA_RADIO;
		pelota->vx *=  -1;
	}

	if (pelota->y > LIMITE_INFERIOR - PELOTA_RADIO)
	{
		pelota->y = LIMITE_INFERIOR - PELOTA_RADIO;
		pelota->vy *= -1;
		return;
	}

	if (pelota->y < PELOTA_RADIO)
	{
		pelota->y = PELOTA_RADIO;
		pelota->vy *= -1;
	}

	pelota_verificar_colision (pelota, p1);
	pelota_verificar_colision (pelota, p2);
}

void pelota_imprimir (Pelota * pelota, Dirty * dirty, SDL_Surface * screen)
{
	SDL_Rect area;

	area.x = pelota->x - PELOTA_RADIO;
	area.y = pelota->y - PELOTA_RADIO;
	
	SDL_BlitSurface (pelota->imagen, NULL, screen, & area);
	dirty_agregar (dirty, & area);
}

void pelota_terminar (Pelota * pelota)
{
	SDL_FreeSurface (pelota->imagen);
	free (pelota);
	printf ("- Liberando la Pelota\n");
}

void pelota_verificar_colision (Pelota * pelota, Personaje * personaje)
{
	int suma_radios = PERSONAJE_RADIO + PELOTA_RADIO;
	int xp, yp;
	int co, ca;
	double angulo;

	xp = personaje->x - 6;
	yp = personaje->y - 70;
	
	if (colisionan (xp, yp, & (pelota->x), & (pelota->y), suma_radios))
	{
		ca = abs (xp - pelota->x);
		co = abs (yp - pelota->y);
		angulo = (double) co / ca;
		
		if (pelota->x > xp)
			pelota->angulo = atan (angulo);
		else
			pelota->angulo = PI - atan (angulo);

		pelota->vy = sin (pelota->angulo) * 5;
		pelota->vx = cos (pelota->angulo) * 3;
			
		
	}
	
}
