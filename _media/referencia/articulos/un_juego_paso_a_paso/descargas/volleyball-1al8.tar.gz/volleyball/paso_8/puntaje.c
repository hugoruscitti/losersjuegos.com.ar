/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#include "puntaje.h"

int puntaje_crear (Puntaje ** puntaje)
{
	Puntaje * nuevo;

	nuevo = (Puntaje *) malloc (sizeof (Puntaje));

	if (nuevo == NULL)
	{
		printf ("No se puede crear el Puntaje\n");
		return 1;
	}

	nuevo->imagen = cargar_imagen ("ima/fuente.bmp", 1);

	if (nuevo->imagen == NULL)
	{
		free (nuevo);
		return 1;
	}

	nuevo->puntos_p1 = 0;
	nuevo->puntos_p2 = 0;

	(* puntaje) = nuevo;
	return 0;
}

void puntaje_terminar (Puntaje * puntaje)
{
	SDL_FreeSurface (puntaje->imagen);
	free (puntaje);
	printf ("- Liberando el Puntaje\n");
}

void puntaje_imprimir (Puntaje * puntaje, Dirty * dirty, SDL_Surface * screen)
{
	puntaje_imprimir_numero (puntaje, puntaje->puntos_p1, 20, dirty, screen);
	puntaje_imprimir_numero (puntaje, puntaje->puntos_p2, 550, dirty, screen);
}

void puntaje_anotar (Puntaje * puntaje, int jugador)
{
	if (jugador == 1)
		puntaje->puntos_p1 ++;
	else
		puntaje->puntos_p2 ++;
}

void puntaje_imprimir_numero (Puntaje * puntaje, int numero, int x, \
		Dirty * dirty, SDL_Surface *screen)
{
	SDL_Rect area = {x, 10, 0, 0};
	
	imprimir_grilla (puntaje->imagen, numero / 10, screen, &area, 10);
	dirty_agregar (dirty, & area);

	area.x += 35;

	imprimir_grilla (puntaje->imagen, numero % 10, screen, &area, 10);
	dirty_agregar (dirty, & area);
}
