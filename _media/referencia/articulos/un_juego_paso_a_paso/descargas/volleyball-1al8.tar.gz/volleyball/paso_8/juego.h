/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#ifndef _JUEGO_H
#define _JUEGO_H

#include <stdlib.h>
#include <SDL.h>
#include "dirty.h"
#include "pelota.h"
#include "personaje.h"
#include "puntaje.h"

typedef struct Juego
{
	Pelota * pelota;
	Dirty * dirty;
	Personaje * personaje_1;
	Personaje * personaje_2;
	Puntaje * puntaje;
	SDL_Surface * fondo;
	SDL_Surface * screen;
} Juego;

int juego_iniciar (Juego * juego);
int juego_cargar_fondo (Juego * juego);
int juego_iniciar_procesos (Juego * juego);
void juego_ciclo_logico (Juego * juego);
void juego_ciclo_grafico (Juego * juego);
void juego_terminar (Juego * juego);

#endif
