/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#include <SDL.h>
#include "util.h"

int main (int argc, char * argv [])
{
	SDL_Surface * screen;
	SDL_Surface * fondo;
	SDL_Event event;
	
	creditos ();
	
	if (iniciar_sdl (& screen))
		return 1;

	fondo = SDL_LoadBMP ("ima/fondo.bmp");

	if (fondo == NULL)
	{
		printf ("Error al cargar fondo %s\n", SDL_GetError() );
		return 1;
	}
	
	SDL_BlitSurface (fondo , NULL, screen, NULL);
	SDL_Flip (screen);

	while (SDL_WaitEvent (&event))
	{
		switch (event.type)
		{
			case SDL_KEYDOWN:
			case SDL_QUIT:
				return 0;

			default:
				break;
		}
	}

	SDL_FreeSurface (fondo);
	SDL_Quit ();
	
	return 0;
}
