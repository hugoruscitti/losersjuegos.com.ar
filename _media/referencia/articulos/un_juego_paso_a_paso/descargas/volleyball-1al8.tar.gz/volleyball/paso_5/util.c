/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#include "util.h"

/*
 * retorna: 1 en caso de error
 */
int iniciar_sdl (SDL_Surface ** screen)
{
	if (SDL_Init (SDL_INIT_VIDEO))
	{
		printf ("No se puede inicializar SDL: %s\n", SDL_GetError ());
		return 1;
	}

	* screen = SDL_SetVideoMode (640, 480, 16, SDL_HWSURFACE);

	if (* screen == NULL)
	{
		printf ("Fall� al iniciar el video: %s\n", SDL_GetError ());
		return 1;
	}

	SDL_WM_SetCaption (TITULO, NULL);

	return 0;
}


/*
 * retorna: 0 si el programa debe terminar, 1 en otro caso.
 */
int procesar_eventos (void)
{
	static SDL_Event event;

	while (SDL_PollEvent (&event))
	{
		if (event.type == SDL_QUIT)
			return 0;

		if (event.type == SDL_KEYDOWN)
		{
			switch (event.key.keysym.sym)
			{
				case SDLK_ESCAPE:
					return 0;
					break;

				default:
					break;
			}
		}
	}

	return 1;
}


SDL_Surface * cargar_imagen (char * ruta, int con_color_clave)
{
	SDL_Surface * tmp;
	SDL_Surface * tmp2;

	tmp = SDL_LoadBMP (ruta);

	if (tmp == NULL)
	{
		printf ("No se puede cargar: '%s'\n", ruta);
		return NULL;
	}

	
	/* Optimiza la imagen */
	tmp2 = SDL_DisplayFormat (tmp);

	if (tmp2 == NULL)
		printf ("Imposible optimizar la imagen, continuando\n");
	else
	{
		SDL_FreeSurface (tmp);
		tmp = tmp2;
	}

	
	/* Aplica la transparencia (COLOR_KEY) */
	if (con_color_clave)
	{
		SDL_SetColorKey (tmp, SDL_SRCCOLORKEY, \
				SDL_MapRGB (tmp->format, 255, 0, 255));
	}

	printf ("+ cargando: %s\n", ruta);

	return tmp;
}

void creditos (void)
{
	printf ("\n");
	printf ("Volleyball - video game similary to GNU Arcade Volleyball\n");
	printf ("Copyright (C) 2005 Hugo Ruscitti\n");
	printf ("Web: http://www.losersjuegos.com.ar\n");
	printf ("\n");
	printf (" This is free software; see the source for copying ");
	printf ("conditions. There is NO \n");
	printf (" warranty; not even for MERCHANTABILITY or FITNESS FOR A");
	printf ("PARTICULAR PURPOSE.\n");
	printf ("\n");
}
