/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#include "personaje.h"

int personaje_crear (Personaje ** personaje, int numero_jugador)
{
	Personaje * nuevo;

	nuevo = (Personaje *) malloc (sizeof (Personaje));

	if (nuevo == NULL)
	{
		printf ("No se puede crear el personaje %d\n", numero_jugador);
		return 1;
	}

	if (numero_jugador == 1)
	{
		nuevo->x = 160;
		nuevo->limite_izquierdo = 20;
		nuevo->limite_derecho = 320 - 20;
		
		nuevo->imagen = cargar_imagen ("ima/personaje_1.bmp", 1);
		
		nuevo->tecla_izquierda = SDLK_a;
		nuevo->tecla_derecha = SDLK_d;
	}
	else
	{
		nuevo->x = 480;
		nuevo->limite_izquierdo = 320 + 20;
		nuevo->limite_derecho = 640 - 20;
		
		nuevo->imagen = cargar_imagen ("ima/personaje_2.bmp", 1);

		nuevo->tecla_izquierda = SDLK_LEFT;
		nuevo->tecla_derecha = SDLK_RIGHT;
	}
	
	nuevo->y = 430;

	if (nuevo->imagen == NULL)
	{
		free (nuevo);
		return 1;
	}
	
	(* personaje) = nuevo;
	
	return 0;
}

void personaje_actualizar (Personaje * personaje, Uint8 * teclas)
{
	if (personaje->x > personaje->limite_izquierdo)
	{
		if (teclas [personaje->tecla_izquierda])
			personaje->x -= 2;
	}

	if (personaje->x < personaje->limite_derecho)
	{
		if (teclas [personaje->tecla_derecha])
			personaje->x += 2;
	}
}

void personaje_imprimir (Personaje * personaje, Dirty * dirty, SDL_Surface * screen)
{
	SDL_Rect area;

	area.x = personaje->x - EJE_X;
	area.y = personaje->y - EJE_Y;
	
	SDL_BlitSurface (personaje->imagen, NULL, screen, & area);
	dirty_agregar (dirty, & area);
}

void personaje_terminar (Personaje * personaje)
{
	SDL_FreeSurface (personaje->imagen);
	free (personaje);
	printf ("- Liberando un Personaje\n");
}
