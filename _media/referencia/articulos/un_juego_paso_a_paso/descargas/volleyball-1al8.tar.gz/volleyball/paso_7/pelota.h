/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#ifndef _PELOTA_H
#define _PELOTA_H

#include <SDL.h>
#include "personaje.h"

#define LIMITE_DERECHO 640
#define LIMITE_IZQUIERDO 0
#define LIMITE_SUPERIOR 0
#define LIMITE_INFERIOR 430
#define PELOTA_RADIO 25
#define PERSONAJE_RADIO 23
#define PI 3.1415

typedef struct Pelota
{
	float x;
	float y;
	float angulo;
	float velocidad;
	float incremento_animacion;
	float vy;
	float vx;
	SDL_Surface * imagen;
} Pelota;

int pelota_iniciar (Pelota ** pelota);
void pelota_actualizar (Pelota * pelota, Personaje * p1, Personaje * p2);
void pelota_imprimir (Pelota * pelota, Dirty * dirty, SDL_Surface * screen);
void pelota_terminar (Pelota * pelota);
void pelota_verificar_colision (Pelota * pelota, Personaje * p);
int pelota_mover (Pelota * pelota);
int colisionan (int x0, int y0, float * x1, float * y1, int suma_radios);

#endif
