/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#ifndef _JUEGO_H
#define _JUEGO_H

#include <SDL.h>
#include "pelota.h"

struct Juego
{
	struct Pelota * pelota;
	SDL_Surface * fondo;
};

int juego_iniciar (struct Juego * juego, SDL_Surface * screen);
void juego_ciclo_logico (struct Juego * juego);
void juego_ciclo_grafico (struct Juego * juego, SDL_Surface * screen);
void juego_terminar (struct Juego * juego);

#endif
