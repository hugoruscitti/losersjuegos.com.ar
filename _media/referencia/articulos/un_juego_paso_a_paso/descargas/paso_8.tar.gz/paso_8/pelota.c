/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */


#include "pelota.h"

int pelota_iniciar (Pelota ** _pelota)
{
	Pelota * pelota;

	pelota = (Pelota *) malloc (sizeof (Pelota));

	if (pelota == NULL)
	{
		printf ("No se puede crear la pelota del juego.\n");
		return 1;
	}

	pelota->imagen = cargar_imagen ("ima/pelota.bmp", 1);

	if (pelota->imagen == NULL)
	{
		free (pelota);
		return 1;
	}

	pelota->x = 500;
	pelota->y = 10;
	pelota->angulo = PI/2;
	
	pelota_cambiar_estado (pelota, INICIANDO);

	pelota->vy = 0.1;
	pelota->vx = 0.1;
	pelota->fuerza = 3;

	(*_pelota) = pelota;
	return 0;
}

float suma (float angulo_1, float angulo_2, float angulo_3)
{
	return (angulo_3 + angulo_2 - angulo_1);
}

void pelota_actualizar (Pelota * pelota, Personaje * p1, Personaje * p2, Puntaje * puntaje)
{
	switch (pelota->estado)
	{
		case REBOTANDO:
			pelota_rebotando (pelota, p1, p2, puntaje);
			break;
			
		case EN_EL_SUELO:
			pelota_en_el_suelo (pelota);
			break;

		case INICIANDO:
			pelota_iniciando (pelota);
			break;
			
		case ESPERA:
			pelota_espera (pelota, p1, p2);
			break;
			
		default:
			printf ("pelota: el estado %d es inv�lido\n", \
					pelota->estado);
			break;
	}

}

void pelota_imprimir (Pelota * pelota, Dirty * dirty, SDL_Surface * screen)
{
	static float paso = 0.0;
	SDL_Rect area;

	area.x = pelota->x - PELOTA_RADIO;
	area.y = pelota->y - PELOTA_RADIO;

	paso += pelota->incremento_animacion;

	if (paso < 0.0)
		paso = 23.0;
	else
		if (paso > 23.0)
			paso = 0.0;
	
	imprimir_grilla (pelota->imagen, (int) paso, screen, &area, 24);
	dirty_agregar (dirty, & area);
}

void pelota_terminar (Pelota * pelota)
{
	SDL_FreeSurface (pelota->imagen);
	free (pelota);
	printf ("- Liberando la Pelota\n");
}

void pelota_verificar_colision (Pelota * pelota, Personaje * personaje)
{
	int suma_radios = PERSONAJE_RADIO + PELOTA_RADIO;
	int xp, yp;
	int co, ca; /* catetos */
	double angulo;

	xp = personaje->x - 6;
	yp = personaje->y - 70;
	
	if (colisionan (xp, yp, pelota->x, pelota->y, suma_radios))
	{
		ca = abs (xp - pelota->x);
		co = abs (yp - pelota->y);
		angulo = (double) co / ca;
		
		if (pelota->x > xp)
			pelota->angulo = atan (angulo);
		else
			pelota->angulo = PI - atan (angulo);

		/* evita que se superpongan los radios */
		pelota->y = yp - sin (pelota->angulo) * suma_radios;
		pelota->x = xp + cos (pelota->angulo) * suma_radios;

		pelota->vy = sin (pelota->angulo) * pelota->fuerza;
		pelota->vx = cos (pelota->angulo) * pelota->fuerza;

		/* eval�a la nueva fuerza de la pelota */
		switch (personaje->estado)
		{
			case PARADO:
				pelota->fuerza *= 0.8;
				break;

			case IZQUIERDA:
				if (pelota->x < personaje->x)
					pelota->fuerza *= 1.5;
				else
					pelota->fuerza *= 0.5;
				break;

			case DERECHA:
				if (pelota->x > personaje->x)
					pelota->fuerza *= 1.5;
				else
					pelota->fuerza *= 0.5;
				break;

			case SALTANDO:
				pelota->fuerza *= 1.2;
				break;

			default:
				break;
		}


		if (pelota->fuerza > 7.0)
			pelota->fuerza = 7.0;

		if (pelota->fuerza < 2.0)
			pelota->fuerza = 2.0;

		personaje_colisiona_con_pelota (personaje, pelota->x);
		
		pelota->estado = REBOTANDO;
	}
	
}

void pelota_rebotando (Pelota * pelota, Personaje * p1, Personaje * p2, Puntaje * puntaje)
{
	if (pelota_mover (pelota))
	{
		if (pelota->x < 320)
			puntaje_anotar (puntaje, 2);
		else
			puntaje_anotar (puntaje, 1);
		
		pelota_cambiar_estado (pelota, EN_EL_SUELO);
	}
	
	pelota->incremento_animacion = cos (pelota->angulo);
	
	pelota_verificar_colision (pelota, p1);
	pelota_verificar_colision (pelota, p2);
}

/* retorna 1 si la pelota toca el suelo */
int pelota_mover (Pelota * pelota)
{
	pelota->vy -= 0.04;
	pelota->x += pelota->vx;
	pelota->y -= pelota->vy;

	pelota_colision_barra (pelota);

	if (pelota->x < PELOTA_RADIO)
	{
		pelota->x = PELOTA_RADIO;
		pelota->vx *= -1;
	}

	if (pelota->x > 640 - PELOTA_RADIO)
	{
		pelota->x = 640 - PELOTA_RADIO;
		pelota->vx *=  -1;
	}

	if (pelota->y > LIMITE_INFERIOR - PELOTA_RADIO)
	{
		pelota->y = LIMITE_INFERIOR - PELOTA_RADIO;
		pelota->vy /= -2;
		pelota->vx /= 2;
		return 1;
	}

	if (pelota->y < PELOTA_RADIO)
	{
		pelota->y = PELOTA_RADIO;
		pelota->vy *= -1;
	}

	return 0;
}

void pelota_espera (Pelota * pelota, Personaje * p1, Personaje * p2)
{
	pelota_verificar_colision (pelota, p1);
	pelota_verificar_colision (pelota, p2);
}

void pelota_en_el_suelo (Pelota * pelota)
{
	pelota_mover (pelota);
	
	if (pelota->delay < 1)
		pelota_cambiar_estado (pelota, INICIANDO);
	else
		pelota->delay --;

	SDL_SetAlpha (pelota->imagen, \
			SDL_RLEACCEL | SDL_SRCALPHA, pelota->delay * 2);
}

void pelota_iniciando (Pelota * pelota)
{
	int amplitud = pelota->delay;

	pelota->angulo += 0.1;

	if (pelota->delay < 1)
		pelota_cambiar_estado (pelota, ESPERA);
	else
	{
		pelota->delay --;
		pelota->x = cos (pelota->angulo) * amplitud + pelota->x_inicial;

		pelota->y = cos (pelota->angulo + PI/3) * amplitud + \
			    pelota->y_inicial;
	}

	SDL_SetAlpha (pelota->imagen, \
			SDL_RLEACCEL | SDL_SRCALPHA, 255 - pelota->delay * 2);

}


void pelota_cambiar_estado (Pelota * pelota, enum estados_pelota nuevo)
{	
	switch (nuevo)
	{
		case EN_EL_SUELO:
			pelota->delay = 128;
			break;

		case INICIANDO:

			pelota->incremento_animacion = 0;
			pelota->fuerza = 3;
			
			if (pelota->x > 320)
			{
				pelota->x_inicial = 150;
				pelota->y_inicial = 280;
			}
			else
			{
				pelota->x_inicial = 320 + 150;
				pelota->y_inicial = 280;
			}

			pelota->delay = 128;
			break;

		default:
			break;
	}

	pelota->estado = nuevo;
}


void pelota_colision_barra (Pelota * pelota)
{
	if (pelota->x + PELOTA_RADIO > 315 \
			&& pelota->x - PELOTA_RADIO < 325
			&& pelota->y + PELOTA_RADIO > 240)
	{

		if (pelota->y < 240)
		{
			pelota->y = 240 - PELOTA_RADIO;
			pelota->vy *= -1.2;
		}
		else
		{
			pelota->vx *= -1;

			if (pelota->x > 320)
				pelota->x = 325 + PELOTA_RADIO;
			else
				pelota->x = 315 - PELOTA_RADIO;
		}
		
	}
}
