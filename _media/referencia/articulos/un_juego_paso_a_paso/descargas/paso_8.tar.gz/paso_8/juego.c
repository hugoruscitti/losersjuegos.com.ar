/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#include <stdlib.h>
#include "juego.h"

int juego_iniciar (Juego * juego)
{
	if (juego_cargar_fondo (juego))
		return 1;

	if (juego_iniciar_procesos (juego))
		return 1;
	
	SDL_BlitSurface (juego->fondo, NULL, juego->screen, NULL);
	SDL_Flip (juego->screen);
	
	return 0;
}

int juego_cargar_fondo (Juego * juego)
{
	juego->fondo = cargar_imagen ("ima/fondo.bmp", 0);
	
	if (juego->fondo == NULL)
	{
		printf ("No se puede crear el fondo.\n");
		return 1;
	}

	return 0;
}

int juego_iniciar_procesos (Juego * juego)
{
	if (pelota_iniciar (& juego->pelota))
		return 1;

	if (dirty_iniciar (& juego->dirty))
		return 1;

	if (personaje_crear (& juego->personaje_1, 1))
		return 1;

	if (personaje_crear (& juego->personaje_2, 2))
		return 1;

	if (puntaje_crear (& juego->puntaje))
		return 1;
	
	return 0;
}


void juego_ciclo_logico (Juego * juego)
{
	Uint8 * teclas = SDL_GetKeyState (NULL);

	if (teclas [SDLK_f])
		SDL_WM_ToggleFullScreen (juego->screen);
	
	personaje_actualizar (juego->personaje_1, teclas);
	personaje_actualizar (juego->personaje_2, teclas);

	pelota_actualizar (juego->pelota, juego->personaje_1, \
			juego->personaje_2, juego->puntaje);
}

void juego_ciclo_grafico (Juego * juego)
{
	dirty_limpiar (juego->dirty, juego->screen, juego->fondo);
	
	personaje_imprimir (juego->personaje_1, juego->dirty, juego->screen);
	personaje_imprimir (juego->personaje_2, juego->dirty, juego->screen);
	pelota_imprimir (juego->pelota, juego->dirty , juego->screen);
	
	puntaje_imprimir (juego->puntaje, juego->dirty, juego->screen);
	
	dirty_actualizar (juego->dirty, juego->screen);
}

void juego_terminar (Juego * juego)
{
	pelota_terminar (juego->pelota);
	personaje_terminar (juego->personaje_1);
	personaje_terminar (juego->personaje_2);
	dirty_terminar (juego->dirty);
	puntaje_terminar (juego->puntaje);
	SDL_FreeSurface (juego->fondo);
}
