/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#ifndef _PELOTA_H
#define _PELOTA_H

#include <SDL.h>
#include "personaje.h"
#include "puntaje.h"

#define LIMITE_DERECHO 640
#define LIMITE_IZQUIERDO 0
#define LIMITE_SUPERIOR 0
#define LIMITE_INFERIOR 430
#define PELOTA_RADIO 25
#define PERSONAJE_RADIO 23
#define PI 3.1415

enum estados_pelota { REBOTANDO, EN_EL_SUELO, INICIANDO, ESPERA };

typedef struct Pelota
{
	enum estados_pelota estado;
	float x;
	float y;
	int x_inicial;
	int y_inicial;
	float angulo;
	float incremento_animacion;
	int delay;
	SDL_Surface * imagen;

	float vy;
	float vx;
	float fuerza;
} Pelota;

int pelota_iniciar (Pelota ** pelota);
void pelota_actualizar (Pelota * pelota, Personaje * p1, Personaje * p2, Puntaje * puntaje);
void pelota_imprimir (Pelota * pelota, Dirty * dirty, SDL_Surface * screen);
void pelota_terminar (Pelota * pelota);
void pelota_verificar_colision (Pelota * pelota, Personaje * p);
void pelota_verificar_colision_limites (Pelota * pelota, Puntaje * puntaje);

void pelota_rebotando (Pelota * pelota, Personaje * p1, Personaje * p2, Puntaje * puntaje);
void pelota_espera (Pelota * pelota, Personaje * p1, Personaje * p2);
void pelota_en_el_suelo (Pelota * pelota);
void pelota_iniciando (Pelota * pelota);
void pelota_cambiar_estado (Pelota * pelota, enum estados_pelota nuevo);
int pelota_mover (Pelota * pelota);
void pelota_colision_barra (Pelota * pelota);
int pelota_colision_vertical (Pelota * pelota);
int pelota_colision_horizontal (Pelota * pelota);
#endif
