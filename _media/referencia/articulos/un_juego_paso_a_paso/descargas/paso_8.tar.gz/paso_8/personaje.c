/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#include "personaje.h"

int personaje_crear (Personaje ** personaje, int numero_jugador)
{
	Personaje * nuevo;

	nuevo = (Personaje *) malloc (sizeof (Personaje));

	if (nuevo == NULL)
	{
		printf ("No se puede crear el personaje %d\n", numero_jugador);
		return 1;
	}

	if (numero_jugador == 1)
	{
		nuevo->x = 90;
		nuevo->limite_izquierdo = -20;
		nuevo->limite_derecho = 320;
		
		nuevo->imagen = cargar_imagen ("ima/personaje_1.bmp", 1);
		
		nuevo->tecla_izquierda = SDLK_a;
		nuevo->tecla_derecha = SDLK_d;
		nuevo->tecla_saltar = SDLK_w;
	}
	else
	{
		nuevo->x = 480;
		nuevo->limite_izquierdo = 320;
		nuevo->limite_derecho = 640 + 20;
		
		nuevo->imagen = cargar_imagen ("ima/personaje_2.bmp", 1);

		nuevo->tecla_izquierda = SDLK_LEFT;
		nuevo->tecla_derecha = SDLK_RIGHT;
		nuevo->tecla_saltar = SDLK_UP;
	}
	
	nuevo->y = 430;
	nuevo->delay_golpe = 0;

	if (nuevo->imagen == NULL)
	{
		free (nuevo);
		return 1;
	}
	
	personaje_cambiar_estado (nuevo, PARADO);
	(* personaje) = nuevo;
	
	return 0;
}

void personaje_actualizar (Personaje * personaje, Uint8 * teclas)
{
	personaje_avanzar_animacion (personaje);

	if (personaje->delay_golpe > 0)
	{
		personaje->delay_golpe --;

		if (personaje->delay_golpe == 0)
			personaje->golpe = NINGUNO;
	}
	
	switch (personaje->estado)
	{
		case PARADO:
			personaje_parado (personaje, teclas);
			break;
			
		case IZQUIERDA:
			personaje_izquierda (personaje, teclas);
			break;

		case DERECHA:
			personaje_derecha (personaje, teclas);
			break;

		case SALTANDO:
			personaje_saltando (personaje, teclas);
			break;

		default:
			printf ("error del estado: %d\n", personaje->estado);
			break;
	}
}

void personaje_imprimir (Personaje * personaje, Dirty * dirty, SDL_Surface * screen)
{
	SDL_Rect area;

	area.x = personaje->x - EJE_X;
	area.y = personaje->y - EJE_Y;

	imprimir_grilla (personaje->imagen, personaje->cuadro, screen, &area, 10);

	dirty_agregar (dirty, & area);
}

void personaje_terminar (Personaje * personaje)
{
	SDL_FreeSurface (personaje->imagen);
	free (personaje);
	printf ("- Liberando un Personaje\n");
}

void personaje_parado (Personaje * personaje, Uint8 * teclas)
{
	if (teclas [personaje->tecla_izquierda])
		personaje_cambiar_estado (personaje, IZQUIERDA);

	if (teclas [personaje->tecla_derecha])
		personaje_cambiar_estado (personaje, DERECHA);
	
	if (teclas [personaje->tecla_saltar])
		personaje_cambiar_estado (personaje, SALTANDO);
}

void personaje_izquierda (Personaje * personaje, Uint8 * teclas)
{
	personaje_mover (personaje, -2);

	if (! teclas [personaje->tecla_izquierda])
		personaje_cambiar_estado (personaje, PARADO);

	if (teclas [personaje->tecla_saltar])
		personaje_cambiar_estado (personaje, SALTANDO);
}

void personaje_derecha (Personaje * personaje, Uint8 * teclas)
{
	personaje_mover (personaje, +2);

	if (! teclas [personaje->tecla_derecha])
		personaje_cambiar_estado (personaje, PARADO);

	if (teclas [personaje->tecla_saltar])
		personaje_cambiar_estado (personaje, SALTANDO);
}

/*
 * retorna el cuadro de la animaci�n que se debe mostrar en pantalla
 */
void personaje_avanzar_animacion (Personaje * personaje)
{
	static int animaciones [_ESTADOS][15] = {\
		{5, -1},\
		{1, 2, 3, 4, 3, 0, 2, -1},\
		{1, 2, 3, 4, 3, 0, 2, -1},\
		{6, -1}};

	if (personaje->delay < 1)
	{
		personaje->delay = 5;
	
		if (animaciones [personaje->estado] [personaje->paso + 1] == -1)
			personaje->paso = 0;
		else
			personaje->paso ++;
	}
	else
		personaje->delay --;

	if (personaje->golpe != NINGUNO)
		personaje->cuadro = 6 + personaje->golpe;
	else
		personaje->cuadro = animaciones [personaje->estado][personaje->paso];
}

void personaje_cambiar_estado (Personaje * personaje, enum estados nuevo)
{
	personaje->estado = nuevo;
	personaje->paso = 0;
	personaje->delay = 5;

	if (nuevo == SALTANDO)
		personaje->velocidad_inicial = -20;
}

void personaje_saltando (Personaje * personaje, Uint8 * teclas)
{
	personaje->y += personaje->velocidad_inicial >> 2;
	personaje->velocidad_inicial ++;

	if (teclas [personaje->tecla_izquierda])
		personaje_mover (personaje, -2);

	if (teclas [personaje->tecla_derecha])
		personaje_mover (personaje, +2);
	
	if (personaje->y > 430)
	{
		personaje->y = 430;
		personaje_cambiar_estado (personaje, PARADO);
	}
}

void personaje_mover (Personaje * personaje, int incremento_x)
{
	if (incremento_x < 0)
	{
		if (personaje->x - EJE_X > personaje->limite_izquierdo)
			personaje->x += incremento_x;
	}
	else
	{
		if (personaje->x + EJE_X < personaje->limite_derecho)
			personaje->x += incremento_x;
	}
}

void personaje_colisiona_con_pelota (Personaje * personaje, int x_pelota)
{
	int diferencia = personaje->x - x_pelota;

	if (x_pelota < 320)
	{
		/* golpea al jugador 1 */

		if (diferencia > 20)
			personaje->golpe = ATRAS;
		else
			if (diferencia < - 20)
				personaje->golpe = ADELANTE;
			else
				personaje->golpe = CENTRO;
	}
	else
	{
		/* golpea al jugador 2 */
		
		if (diferencia > 20)
			personaje->golpe = ADELANTE;
		else
			if (diferencia < -20)
				personaje->golpe = ATRAS;
			else
				personaje->golpe = CENTRO;
	}
	
	personaje->delay_golpe = 20;
}
