/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#include "juego.h"

int dirty_iniciar (Dirty ** dirty)
{
	Dirty * tmp;

	tmp = (Dirty *) malloc (sizeof (Dirty));

	if (tmp == NULL)
	{
		printf ("Imposible crear la estructura Dirty Rectangles\n");
		return 1;
	}

	tmp->limite_actual = 0;
	tmp->limite_anterior = 0;

	(*dirty) = tmp;
	printf ("+ Creando la estructura 'Dirty Rectangles'\n");
	return 0;
}

void dirty_agregar (Dirty * dirty, SDL_Rect * rect)
{
	dirty->actual [dirty->limite_actual ++] = * rect;
}

void dirty_limpiar (Dirty * dirty, SDL_Surface * dst, SDL_Surface* fondo)
{
	int i;
	
	for (i = 0; i < dirty->limite_anterior; i ++)
		SDL_BlitSurface (fondo, dirty->anterior + i, dst, \
				dirty->anterior + i);

}

void dirty_actualizar (Dirty * dirty, SDL_Surface * screen)
{
	SDL_Rect todos [40];
	int limite_todos;

	limite_todos = dirty_extraer_todos (dirty, todos);
	SDL_UpdateRects (screen, limite_todos, todos);
	
	dirty_reiniciar (dirty);
}

int dirty_extraer_todos (Dirty * dirty, SDL_Rect * rect)
{
	int retorno = 0;
	int i;

	for (i = 0; i < dirty->limite_anterior; i ++)
		rect [retorno ++] = dirty->anterior [i];

	for (i = 0; i < dirty->limite_actual; i ++)
		rect [retorno ++] = dirty->actual [i];

	return retorno;
}

void dirty_reiniciar (Dirty * dirty)
{
	int i;
	
	for (i = 0; i < dirty->limite_actual; i ++)
		dirty->anterior [i] = dirty->actual [i];

	dirty->limite_anterior = i;
	dirty->limite_actual = 0;
}

void dirty_terminar (Dirty * dirty)
{
	free (dirty);
	printf ("- Liberando la estructura 'Dirty Rectangles'\n");
}
