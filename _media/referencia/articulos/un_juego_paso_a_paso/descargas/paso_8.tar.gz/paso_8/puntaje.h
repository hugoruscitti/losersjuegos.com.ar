/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#ifndef _PUNTAJE_H
#define _PUNTAJE_H

#include "util.h"

typedef struct puntaje
{
	SDL_Surface * imagen;
	int puntos_p1;
	int puntos_p2;
} Puntaje;


int puntaje_crear (Puntaje ** puntaje);
void puntaje_imprimir (Puntaje * puntaje, Dirty * dirty, SDL_Surface * screen);
void puntaje_terminar (Puntaje * puntaje); 
void puntaje_anotar (Puntaje * puntaje, int jugador);
void puntaje_imprimir_numero (Puntaje * puntaje, int numero, int x, \
		Dirty * dirty, SDL_Surface *screen);

#endif
