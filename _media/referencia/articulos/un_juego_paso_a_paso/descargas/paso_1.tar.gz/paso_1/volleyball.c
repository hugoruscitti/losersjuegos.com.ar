/*
 * Volleyball - video game similary to GNU Arcade Volleyball
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 * web site: http://www.loosersjuegos.com.ar
 * 
 * This file is part of Volleyball.
 *
 * Volleyball is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Volleyball is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 */

#include <SDL.h>

int main (int argc, char * argv [])
{
	SDL_Surface * screen;
	SDL_Event event;

	if (SDL_Init (SDL_INIT_VIDEO))
	{		
		printf ("No se puede inicializar SDL: %s\n", SDL_GetError ());
		return 1;
	}

	screen = SDL_SetVideoMode (640, 480, 16, SDL_HWSURFACE);

	if (screen == NULL)
	{
		printf ("Fall� al iniciar el video: %s\n", SDL_GetError ());
		return 1;
	}

	SDL_WM_SetCaption ("Volleyball - paso 1", NULL);

	while (SDL_WaitEvent (&event))
	{
		switch (event.type)
		{
			case SDL_KEYDOWN:
			case SDL_QUIT:
				return 0;

			default:
				break;
		}
	}

	SDL_Quit ();
	
	return 0;
}
