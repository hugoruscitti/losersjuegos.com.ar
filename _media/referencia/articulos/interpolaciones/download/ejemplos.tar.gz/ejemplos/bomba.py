import pytweener
import pygame

class Sprite:

    def __init__(self, image, x, y):
        self.x = x
        self.y = y
        self.image = image
        self.width = self.image.get_width()
        self.height = self.image.get_height()

    def draw(self, screen):
        x, y = self.x - self.width / 2, self.y - self.height / 2

        screen.blit(self.image, (x, y))



screen = pygame.display.set_mode((640, 480))
quit = False
grey = (255, 255, 255)

image = pygame.image.load("bomba.png")

sprite = Sprite(image, 320, 240)

clock = pygame.time.Clock()
tweener = pytweener.Tweener()
pygame.font.init()
font = pygame.font.Font(None, 26)
text_message = font.render("Pulse sobre la pantalla con el mouse para desplazar la bomba.", 1, (0, 0, 0))

while not quit:

    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key in [pygame.K_q, pygame.K_ESCAPE]:
                quit = True
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                x, y = event.pos
                tweener.addTween(sprite, x=x, y=y, tweenTime=1.0, 
                        tweenType=pytweener.Easing.Elastic.easeOut)

    dt = clock.tick(100)
    tweener.update(dt / 1000.0)

    screen.fill(grey)
    screen.blit(text_message, (20, 440))
    sprite.draw(screen)
    pygame.display.flip()
