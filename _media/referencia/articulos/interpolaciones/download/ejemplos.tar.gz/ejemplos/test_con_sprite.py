import pytweener
import pygame

class Sprite:

    def __init__(self, image, x, y):
        self.x = x
        self.y = y
        self.image = image

    def draw(self, screen):
        screen.blit(self.image, (self.x, self.y))


screen = pygame.display.set_mode((640, 480))
quit = False
grey = (255, 255, 255)

image = pygame.image.load("auto.png")

sprite_1 = Sprite(image, 100, 0)
sprite_2 = Sprite(image, 100, 180)
sprite_3 = Sprite(image, 100, 360)

clock = pygame.time.Clock()


tweener = pytweener.Tweener()

tweener.addTween(sprite_1, x=450, tweenTime=4.0, tweenType=pytweener.Easing.Linear.easeNone)
tweener.addTween(sprite_2, x=450, tweenTime=4.0, tweenType=pytweener.Easing.Elastic.easeIn)
tweener.addTween(sprite_3, x=450, tweenTime=4.0, tweenType=pytweener.Easing.Elastic.easeInOut)

while not quit:

    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key in [pygame.K_q, pygame.K_ESCAPE]:
                quit = True

    dt = clock.tick(100)
    tweener.update(dt / 1000.0)

    screen.fill(grey)
    sprite_1.draw(screen)
    sprite_2.draw(screen)
    sprite_3.draw(screen)
    pygame.display.flip()
