import pytweener
import pygame

class Sprite:

    def __init__(self, image, x, y):
        self.x = x
        self.y = y
        self.width = image.get_width()
        self.height = image.get_height()
        self.image = image
        self.original_image = image

    def update(self):
        size = (self.width, self.height)
        self.image = pygame.transform.smoothscale(self.original_image, size)

    def draw(self, screen):
        screen.blit(self.image, (self.x, self.y))


screen = pygame.display.set_mode((640, 480))
quit = False
grey = (255, 255, 255)

image = pygame.image.load("bomba.png")

sprite = Sprite(image, 280, 200)

clock = pygame.time.Clock()
tweener = pytweener.Tweener()
tweener.addTween(sprite, width=68 * 2, height=63 * 2, tweenTime=4.0, 
        tweenType=pytweener.Easing.Elastic.easeOut)


while not quit:

    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key in [pygame.K_q, pygame.K_ESCAPE]:
                quit = True

    dt = clock.tick(100)
    tweener.update(dt / 1000.0)
    sprite.update()

    screen.fill(grey)
    sprite.draw(screen)
    pygame.display.flip()
