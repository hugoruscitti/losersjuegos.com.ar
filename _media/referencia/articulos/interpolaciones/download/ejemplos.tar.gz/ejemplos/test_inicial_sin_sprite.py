import pytweener
import pygame

class Position:

    def __init__(self, x, y):
        self.x = x
        self.y = y

screen = pygame.display.set_mode((640, 480))
quit = False

image = pygame.image.load("logo.png")
position = image.get_rect()
grey = (255, 255, 255)

clock = pygame.time.Clock()
position = Position(0, 0)
tweener = pytweener.Tweener()

tweener.addTween(position, x=500, tweenTime=4.0,
        tweenType=pytweener.Easing.Elastic.easeOut)


while not quit:

    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key in [pygame.K_q, pygame.K_ESCAPE]:
                quit = True

    dt = clock.tick(100)
    tweener.update(dt / 1000.0)

    screen.fill(grey)
    screen.blit(image, (position.x, position.y))
    pygame.display.flip()

