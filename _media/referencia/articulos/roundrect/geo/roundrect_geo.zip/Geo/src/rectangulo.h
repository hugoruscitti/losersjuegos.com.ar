#ifndef RECTANGULO_H
#define RECTANGULO_H

#include <SDL.h>

void rectRedondeado(SDL_Surface *surface, int x1, int y1, int x2, int y2,
	int radio, SDL_Color color);
int rectRelleno(SDL_Surface *surface, int x1, int y1, int x2, int y2,
  SDL_Color color);
  
#endif
