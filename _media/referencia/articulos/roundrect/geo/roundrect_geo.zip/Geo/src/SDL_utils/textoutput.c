/** \file textoutput.c
 * Text output related functions.
 * These functions are part of SDL_utils, a set of (simple) helpful
 * functions to be used with the SDL library.
 */

#include "SDL_utils.h"
#include <SDL_ttf.h>
#include <stdio.h>
#include <stdarg.h>

/*!
 * \brief Writes the string text onto the surface dest at position x,y
 *
 * \param dest destination surface
 * \param font TTF_Font to use
 * \param x x-position
 * \param y y-position
 * \param fg color
 * \param text string to be written
 */
void textout(SDL_Surface *dest, TTF_Font *font, Sint16 x, Sint16 y,
	SDL_Color color, const char *text) {
	SDL_Surface *textSurface;
	SDL_Rect rect = {x, y, 0, 0};

	if ( !text ) return;

	textSurface = TTF_RenderText_Solid(font, text, color);
	SDL_BlitSurface(textSurface, NULL, dest, &rect);

	SDL_FreeSurface(textSurface);
}
/*!
 * \brief Writes the string text onto the surface dest centered at position x,y
 *
 * \param dest destination surface
 * \param font TTF_Font to use
 * \param x x-position
 * \param y y-position
 * \param fg color
 * \param text string to be written
 */
void textout_center(SDL_Surface *dest, TTF_Font *font, Sint16 x, Sint16 y,
	SDL_Color color, const char *text) {
	SDL_Surface *textSurface;
	SDL_Rect rect = {x, y, 0, 0};
	int textW, textH;

	if ( !text ) return;

	TTF_SizeText(font, text, &textW, &textH);
	rect.x = rect.x - textW / 2;

	textSurface = TTF_RenderText_Solid(font, text, color);
	SDL_BlitSurface(textSurface, NULL, dest, &rect);

	SDL_FreeSurface(textSurface);
}

/*!
 * \brief Writes the string text onto the surface dest at position (x,y)
 * interpreting the x coordinate as the right rather than the left edge.
 *
 * \param dest destination surface
 * \param font TTF_Font to use
 * \param x x-position
 * \param y y-position
 * \param fg color
 * \param text string to be written
 */
void textout_right(SDL_Surface *dest, TTF_Font *font, Sint16 x, Sint16 y,
	SDL_Color color, const char *text) {
	SDL_Surface *textSurface;
	SDL_Rect rect = {x, y, 0, 0};
	int textW, textH;

	if ( !text ) return;

	TTF_SizeText(font, text, &textW, &textH);
	rect.x = rect.x - textW;

	textSurface = TTF_RenderText_Solid(font, text, color);
	SDL_BlitSurface(textSurface, NULL, dest, &rect);

	SDL_FreeSurface(textSurface);
}

void textoutbg(SDL_Surface *dest, TTF_Font *font, Sint16 x, Sint16 y,
	SDL_Color color, SDL_Color bg, const char *text) {
	SDL_Surface *textSurface;
	SDL_Rect rect = {x, y, 0, 0};

	if ( !text ) return;

	textSurface = TTF_RenderText_Shaded(font, text, color, bg);
	SDL_BlitSurface(textSurface, NULL, dest, &rect);

	SDL_FreeSurface(textSurface);
}

void textprintf(SDL_Surface *dest, TTF_Font *font, Sint16 x, Sint16 y,
	SDL_Color color, const char *format, ...) {
	SDL_Surface *textSurface;
	SDL_Rect rectDest = {x, y, 0, 0};
	char buf[512];

	va_list ap;

	if ( !format ) return;

	va_start( ap , format );
	vsprintf( buf , format , ap );
	va_end( ap );

	textSurface = TTF_RenderText_Solid(font, buf, color);
	SDL_BlitSurface(textSurface, NULL, dest, &rectDest);

	SDL_FreeSurface(textSurface);
}
