SDL_utils
version 0.5 (alpha)
COpyright (C) 2005 Jos� Jorge Enr�quez Rodr�guez
<jenriquez@users.sourceforge.net>

SDL_utils is a set of (simple) helper C functions to be used with the SDL
library (http://www.libsdl.org). SDL_utils includes functions for text
output, reading the keyboard, and some other miscellaneous functions.

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


You can either link with the library either dinamically or statically (but you
may need to create the library itself since it is being distributed mainly as
source code). Even, you can just grab de source code (or a portion of it) and
include it within your programs (compile it as part of your project), as long
as you keep this README file in the distribution of your program that makes use of
SDL_utils.