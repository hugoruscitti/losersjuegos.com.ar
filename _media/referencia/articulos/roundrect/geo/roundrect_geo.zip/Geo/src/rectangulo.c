#include "rectangulo.h"
#include <math.h>

#define PI 3.1416
// Convertir de radianes a grados y viceversa
#define rad2deg(x) (180 * x) / PI
#define deg2rad(x) (PI * x) / 180

/* rectRedondeado
 * Dibuja un rect�ngulo con esquinas redondeadas.
 * x1,y1 son las coordenadas de la esquina superior izquierda
 * x2,y2 las coordenadas de la esquina inferior derecha
 * radio es el radio del c�rculo cuyo cuarto de arco es la esquina del rect�ngulo
 * color el color del rect�ngulo
 *
 */
void rectRedondeado(SDL_Surface *surface, int x1, int y1, int x2, int y2,
	int radio, SDL_Color color) {

	// contadores
	int i, j;
	// inicio y fin de l�neas rectas
	int start, end;
	// coordenadas "ordenadas" de menor a mayor
	int xmin = x1, xmax = x2;
	int ymin = y1, ymax = y2;
	
	// Color
	Uint32 col = SDL_MapRGB(surface->format, color.r, color.g, color.b);
	
	// Componentes x,y para cada �ngulo
	int xaux, yaux;
	// coordenadas de origen de los c�rculos para cada esquina
	int xArIz, yArIz;
	int xArDe, yArDe;
	int xAbIz, yAbIz;
	int xAbDe, yAbDe;
	
	if ( x2 < x1 ) {
		xmin = x2; xmax = x1;
	}
	if ( y2 < y1) {
		ymin = y2; ymax = y1;
	}
	
	// l�neas horizontales
	start = xmin + radio;
	end = xmax - radio;
	lineaH(surface, start, ymin, end, color);
	lineaH(surface, start, ymax, end, color);

	// l�neas verticales
	start = ymin + radio;
	end = ymax - radio;
	lineaV(surface, xmin, start, end, color);
	lineaV(surface, xmax, start, end, color);
	
	/* Or�genes de los c�rculos con los que se calculan los arcos */
	xArIz = x1 + radio; yArIz = y1 + radio; // arriba-izquierda
	xArDe = x2 - radio; yArDe = y1 + radio; // arriba-derecha
	xAbIz = x1 + radio; yAbIz = y2 - radio; // abajo-izquierda
	xAbDe = x2 - radio; yAbDe = y2 - radio; // abajo-derecha

	for ( i = 1; i < 90; i++ ) {
		xaux = radio * cos( deg2rad(i) );
		yaux = radio * sin( deg2rad(i) );
		// arriba-izquierda
		putpixel(surface, xArIz - xaux, yArIz - yaux, col);
		// arriba-derecha y abajo-izquierda con correcci�n
		if ( i < 45 ) {
			// arriba-derecha
			putpixel(surface, xArDe + xaux + 1, yArDe - yaux, col);
			// abajo-izquierda
			putpixel(surface, xAbIz - xaux - 1, yAbIz + yaux, col);
		}
		else if ( i > 45 ) {
			// arriba-derecha
			putpixel(surface, xArDe + xaux, yArDe - yaux - 1, col);
			// abajo-izquierda
			putpixel(surface, xAbIz - xaux, yAbIz + yaux + 1, col);
		}
		else if ( i == 45 ) {
			// arriba-derecha
			putpixel(surface, xArDe + xaux + 1, yArDe - yaux, col);
			putpixel(surface, xArDe + xaux, yArDe - yaux - 1, col);
			// abajo-izquierda
			putpixel(surface, xAbIz - xaux - 1, yAbIz + yaux, col);
			putpixel(surface, xAbIz - xaux, yAbIz + yaux + 1, col);
		}
		// abajo-derecha
		putpixel(surface, xAbDe + xaux, yAbDe + yaux,
		  SDL_MapRGB(surface->format, color.r, color.g, color.b));
	}
}

int rectRelleno(SDL_Surface *surface, int x1, int y1, int x2, int y2,
  SDL_Color color) {

	SDL_Rect rect = {x1, y1, x2-x1+1, y2-y1+1};
	
	return SDL_FillRect(surface, &rect, SDL_MapRGB(surface->format, color.r, color.g, color.b));
}
