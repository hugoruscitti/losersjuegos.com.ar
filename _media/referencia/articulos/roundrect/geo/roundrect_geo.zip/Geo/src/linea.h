#ifndef LINEA_H
#define LINEA_H

#include <SDL.h>

void lineaH(SDL_Surface *surface, int x1, int y1, int x2, SDL_Color color);
void lineaV(SDL_Surface *surface, int x1, int y1, int y2, SDL_Color color);

#endif
