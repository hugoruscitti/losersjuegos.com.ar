/** \file display.c
 * Display utilities.
 * These functions are part of SDL_utils, a set of (simple) helpful
 * functions to be used with the SDL library.
 */

#include "SDL_utils.h"

Uint32 getpixelNoLock(SDL_Surface *surface, int x, int y) {
	int bpp = surface->format->BytesPerPixel;
	/* Here p is the address to the pixel we want to retrieve */
	Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

	switch(bpp) {
    case 1:
      return *p;
    case 2:
      return *(Uint16 *)p;
    case 3:
      if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
      	return p[0] << 16 | p[1] << 8 | p[2];
			else
				return p[0] | p[1] << 8 | p[2] << 16;
		case 4:
      return *(Uint32 *)p;
		default:
			return 0;       /* shouldn't happen, but avoids warnings */
	}
}

void putpixelNoLock(SDL_Surface *surface, int x, int y, Uint32 pixel) {
  int bpp = surface->format->BytesPerPixel;
  /* Here p is the address to the pixel we want to set */
  Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;
  switch(bpp) {
    case 1:
      *p = pixel;
      break;
    case 2:
      *(Uint16 *)p = pixel;
      break;
    case 3:
      if(SDL_BYTEORDER == SDL_BIG_ENDIAN) {
        p[0] = (pixel >> 16) & 0xff;
        p[1] = (pixel >> 8) & 0xff;
        p[2] = pixel & 0xff;
      } else {
        p[0] = pixel & 0xff;
        p[1] = (pixel >> 8) & 0xff;
        p[2] = (pixel >> 16) & 0xff;
      }
      break;
    case 4:
      *(Uint32 *)p = pixel;
      break;
  }
}

/*!
 * \brief Return the pixel value at (x,y).
 *
 * Taken from the SDL Documentation Chap. 2 Graphics and video (example 2-4).
 * Just added surface locking.
 * \param surface target surface
 * \param x x-coordinate
 * \param y y-coordinate
 */
Uint32 getpixel(SDL_Surface *surface, int x, int y) {
	Uint32 pixel;

	if ( SDL_MUSTLOCK(surface) ) SDL_LockSurface(surface);
	pixel = getpixelNoLock(surface, x, y);
	if ( SDL_MUSTLOCK(surface) ) SDL_UnlockSurface(surface);

	return pixel;
}

/*!
 * \brief Set the pixel at (x,y) to the given value.
 *
 * Taken from the SDL Documentation Chap. 2 Graphics and video (example 2-5).
 * Just added surface locking.
 * \param surface target surface
 * \param x x-coordinate
 * \param y y-coordinate
 */
void putpixel(SDL_Surface *surface, int x, int y, Uint32 pixel) {
	if ( SDL_MUSTLOCK(surface) ) SDL_LockSurface(surface);
	putpixelNoLock(surface, x, y, pixel);
	if ( SDL_MUSTLOCK(surface) ) SDL_UnlockSurface(surface);
}

/*! \brief Clears the surface to color 0 (tipically black).
 *
 * Fills the entire surface with color 0 (tipically black).
 * \param surface Surface to be cleared.
 * \return -1 on failure, other on success.
 */
int clearSurface(SDL_Surface *surface) {
	return SDL_FillRect(surface, NULL, 0);
}

/*! \brief Clears the surface to the specified color.
 *
 * Fills the entire surface with the SDL_Color color.
 * \param surface Surface to be cleared.
 * \param color SDL_Color the surface will be filled with.
 * \return -1 on failure, other on success.
 */
int clearToColor(SDL_Surface *surface, SDL_Color color) {
	return SDL_FillRect(surface, NULL, SDL_MapRGB(surface->format, color.r, color.g, color.b));
}

/*! Map an SDL_Color to a pixel format.
 *
 */
Uint32 SDL_MapRGBColor(SDL_PixelFormat *format, SDL_Color color) {
	return SDL_MapRGBA(format, color.r, color.g, color.b, color.unused);
}

/*!
 * This function performs a fast fill of the given rectangle with some color.
 */
int SDL_FillRectColor(SDL_Surface *surface, SDL_Rect *rect, SDL_Color color) {
	if ( !surface ) return -1;
	return SDL_FillRect(surface, rect,
		SDL_MapRGBA(surface->format, color.r, color.g, color.b, color.unused));
}
