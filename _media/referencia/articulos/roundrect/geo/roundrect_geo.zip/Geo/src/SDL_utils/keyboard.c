/** \file keyboard.c
 * Keyboard helper functions.
 * These functions are part of SDL_utils, a set of (simple) helpful
 * functions to be used with the SDL library.
 */

#include "SDL_utils.h"

/*! Wait for a keypress
 * \return Return the pressed key converted to a char.
 */
char readkey() {
	SDL_Event event;

	while ( event.type != SDL_KEYDOWN )
	  SDL_PollEvent(&event);

	printf("key pressed: %c\n", event.key.keysym.sym);
	return event.key.keysym.sym;
}

/*! Wait for a keypress
 * \return Return the pressed key as an Unicode character.
 */
Uint16 ureadkey() {
	SDL_Event event;

	// for getting the �, �, � and some others
	SDL_EnableUNICODE(1);
	while ( event.type != SDL_KEYDOWN )
	  SDL_PollEvent(&event);
	// disable, it adds overhead to SDL keypresses
	SDL_EnableUNICODE(0);

	return event.key.keysym.unicode;
}

/*! Tells whether there is a keypress waiting in the input buffer.
 *
 * \return Whether there is a key pressed at the moment.
 */
int keypressed() {
	SDL_Event event;
	
	// if there is some event
	if ( SDL_PollEvent(&event) ) {
		// if it is a keypress
		if ( event.type == SDL_KEYDOWN ) {
			// keep it in the event queue and return
			//SDL_PushEvent(&event);
			return 1;
		}
		return 0;
	}
	
	return 0;
}

void clearKeys() {
	SDL_Event eventList;
	int numEvents;
	numEvents = SDL_PeepEvents(&eventList, 5, SDL_GETEVENT, SDL_EVENTMASK(SDL_KEYDOWN));
	printf("numEvents: %d\n", numEvents);
}
