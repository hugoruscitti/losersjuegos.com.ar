/** \file misc.c
 * Miscelaneous functions.
 * These functions are part of SDL_utils, a set of (simple) helpful
 * functions to be used with the SDL library.
 */

#include "SDL_utils.h"

/*! \brief Make a new SDL_Rect
 * \param x rect x
 * \param y rect y
 * \param w rect width
 * \param h rect height
 */
SDL_Rect newRect(int x, int y, int w, int h) {
	SDL_Rect rect = {x, y, w, h};
	return rect;
}

/*! \brief Make a new SDL_Color
 *
 */
SDL_Color newColor(int r, int g, int b) {
	SDL_Color color = {r, g, b, 0};
	return color;
}

/*! Get a new SDL_Color with alpha value.
 *
 */
SDL_Color newColorA(int r, int g, int b, int a) {
	SDL_Color color = {r, g, b, a};
	return color;
}
