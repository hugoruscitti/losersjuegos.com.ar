#include "linea.h"

void lineaH(SDL_Surface *surface, int x1, int y1, int x2, SDL_Color color) {
	int i;
	int xmin, xmax;
	
	xmin = x1; xmax = x2;
	
	if ( x2 < x1 ) {
		xmin = x2; xmax = x1;
	}
	
	for (i = xmin; i <= xmax; i++) {
		putpixel(surface, i, y1, SDL_MapRGB(surface->format, color.r, color.g, color.b));
	}
}

void lineaV(SDL_Surface *surface, int x1, int y1, int y2, SDL_Color color) {
	int i;
	int ymin, ymax;
	
	ymin = y1; ymax = y2;
	
	if ( y2 < y1 ) {
		ymin = y2; ymax = y1;
	}
	
	for ( i = ymin; i <= ymax; i++ ) {
		putpixel(surface, x1, i, SDL_MapRGB(surface->format, color.r, color.g, color.b));
	}
}
