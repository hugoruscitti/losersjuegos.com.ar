/* SDL_utils 0.5 (alfa version)
 * SDL_utils is a set of (simple) helper functions to be used with the
 * SDL library.
 * SDL_utils is Copyright (c) Jos� Jorge Enr�quez Rodr�guez
 * SDL_utils is released under the terms of the Lesser GNU Public License (LGPL),
 * you can link to it either statically or dinamically, or just grab the
 * functions you'll use from the source code and include it within your programs.
 */

#ifndef SDL_UTILS_H
#define SDL_UTILS_H

#include <SDL.h>
#include <SDL_ttf.h>

// The 16 VGA standard colors
#define COL_BLACK        newColor(  0,   0,   0)
#define COL_BLUE         newColor(  0,   0, 170)
#define COL_GREEN        newColor(  0, 170,   0)
#define COL_CYAN         newColor(  0, 170, 170)
#define COL_RED          newColor(170,   0,   0)
#define COL_MAGENTA      newColor(170,   0, 170)
#define COL_BROWN        newColor(170,  85,   0)
#define COL_LIGHTGRAY    newColor(170, 170, 170)
#define COL_DARKGRAY     newColor( 85,  85,  85)
#define COL_LIGHTBLUE    newColor( 85,  85, 255)
#define COL_LIGHTGREEN   newColor( 85, 255,  85)
#define COL_LIGHTCYAN    newColor( 85, 255, 255)
#define COL_LIGHTRED     newColor(255,  85,  85)
#define COL_LIGHTMAGENTA newColor(255,  85, 255)
#define COL_YELLOW       newColor(255, 255,  85)
#define COL_WHITE        newColor(255, 255, 255)

/* Set up for C function definitions, even when using C++ */
#ifdef __cplusplus
	extern "C" {
#endif

/* Keyboard functions */
char readkey();
Uint16 ureadkey();
int keypressed();
void clearKeys();

/* Display functions */
Uint32 getpixel(SDL_Surface *surface, int x, int y);
Uint32 getpixelNoLock(SDL_Surface *surface, int x, int y);
void putpixel(SDL_Surface *surface, int x, int y, Uint32 pixel);
void putpixelNoLock(SDL_Surface *surface, int x, int y, Uint32 pixel);
int clearSurface(SDL_Surface *surface);
int clearToColor(SDL_Surface *surface, SDL_Color color);
Uint32 SDL_MapRGBColor(SDL_PixelFormat *format, SDL_Color color);
int SDL_FillRectColor(SDL_Surface *surface, SDL_Rect *rect, SDL_Color color);

/* Text output */
// These require SDL_ttf
void textout(SDL_Surface *dest, TTF_Font *font, Sint16 x, Sint16 y,
	SDL_Color color, const char *text);
void textout_center(SDL_Surface *dest, TTF_Font *font, Sint16 x, Sint16 y,
	SDL_Color color, const char *text);
void textout_right(SDL_Surface *dest, TTF_Font *font, Sint16 x, Sint16 y,
	SDL_Color color, const char *text);
void textoutbg(SDL_Surface *dest, TTF_Font *font, Sint16 x, Sint16 y,
	SDL_Color color, SDL_Color bg, const char *text);
void textprintf(SDL_Surface *dest, TTF_Font *font, Sint16 x, Sint16 y,
	SDL_Color color, const char *format, ...);

/* Miscelaneous functions */
SDL_Rect newRect(int x, int y, int w, int h);
SDL_Color newColor(int r, int g, int b);
SDL_Color newColorA(int r, int g, int b, int a);

/* Ends C function definitions when using C++ */
#ifdef __cplusplus
	}
#endif


#endif /* SDL_EXTRA_H */
