#include "rectangulo.h"
#include "linea.h"
#include "SDL_utils/SDL_utils.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <SDL.h>
#include <SDL_ttf.h>

#define SCREEN_W 640
#define SCREEN_H 480
#define BPP 32
#define FLAGS SDL_SWSURFACE | SDL_FULLSCREEN

int main(int argc, char *argv[]) {
	SDL_Surface *pantalla;
	SDL_Event evento;
	SDL_Color color;
	SDL_Rect rect;
	TTF_Font *fuente;
	int radio = 20;

	if ( argc > 1 ) {
		radio = atoi(argv[1]);
	}

	srand( time(NULL) );

	printf("Inicializando SDL... ");
	SDL_Init(SDL_INIT_VIDEO);
	pantalla = SDL_SetVideoMode(SCREEN_W, SCREEN_H, BPP, FLAGS);
	if ( !pantalla ) {
		fprintf(stderr, "Error: %s.\n", SDL_GetError());
		exit(1);
	}
	TTF_Init();
	SDL_ShowCursor(SDL_DISABLE);
	printf("[OK].\n");
	
	printf("Cargando fuente res/cour.ttf... ");
	fuente = TTF_OpenFont("res/cour.ttf", 12);
	if ( !fuente ) {
		fprintf(stderr, "Error: %d.\n", SDL_GetError());
		exit(1);
	}
	printf("[OK].\n");

	
	// Color del rect�ngulo
	color.r = rand() % 256;
	color.g = rand() % 256;
	color.b = rand() % 256;

	// Dimensiones del rect�ngulo
	rect.x = 30; //rand() % SCREEN_W;
	rect.y = 30; // rand() % SCREEN_H;
	rect.w = SCREEN_W - 60; //rand() % ( SCREEN_W - rect.x );
	rect.h = SCREEN_H - 60; //rand() % ( SCREEN_H - rect.y );
	
	// Informaci�n
	printf("Coordenadas: %d,%d-%d,%d. Radio: %d.\n", rect.x, rect.y, rect.x + rect.w, rect.y + rect.h, radio);
	printf("Color: %d, %d, %d.\n", color.r , color.g, color.b);

	textout_right(pantalla, fuente, SCREEN_W, 0, COL_LIGHTGRAY, "Propuesta al reto -Rect�ngulo redondeado- en SDL ");
	textout_right(pantalla, fuente, SCREEN_W, 12, COL_LIGHTGRAY, "por Jos� Jorge Enr�quez Rodr�guez.");
	textprintf(pantalla, fuente, 0, 0, COL_GREEN,
		"Coordenadas: %d,%d-%d,%d. Radio: %d.", rect.x, rect.y, rect.x + rect.w, rect.y + rect.h, radio);
	textprintf(pantalla, fuente, 0, 12, color,
		"Color: %d, %d, %d.", color.r , color.g, color.b);
	textout(pantalla, fuente, 0, SCREEN_H - 20, COL_WHITE, "Presiona [ESC] para salir...");

	// un rect�ngulo de fondo
	rectRelleno(pantalla, rect.x - 2, rect.y - 2, rect.x + rect.w + 2, rect.y + rect.h + 2,
	  newColor(255, 255, 255));

	// dibujar rect�ngulo redondeado
	rectRedondeado(pantalla, rect.x, rect.y, rect.x + rect.w, rect.y + rect.h,
	  radio, color);

	for ( ; ; ) {
		// entrada
		if ( SDL_PollEvent(&evento) ) {
			if ( evento.type == SDL_QUIT ) break;
			if ( evento.type == SDL_KEYDOWN ) {
				if ( evento.key.keysym.sym == SDLK_ESCAPE ) break;
			}
		}
		
		// proceso

		// dibujado
		SDL_Flip(pantalla);
	}
	
	printf("\nFinalizando... ");
	TTF_CloseFont(fuente);
	TTF_Quit();
	SDL_Quit();
	printf("[OK].\nFin del programa.\n");
	
	return 0;
}
