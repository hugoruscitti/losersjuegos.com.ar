/*
 * Ejercicio : roundrect
 * Copyright (C) 2005 Hugo Ruscitti : hugoruscitti@yahoo.com.ar
 *
 * Este programa es software libre. Puede redistribuirlo y/o 
 * modificarlo bajo los t�rminos de la Licencia P�blica General	de 
 * GNU seg�n es publicada por la Free Software Foundation, bien de 
 * la versi�n 2 de dicha Licencia o bien (seg�n su elecci�n) de 
 * cualquier versi�n posterior.
 * 
 * Este programa se distribuye con la esperanza de que sea �til, pero
 * SIN NINGUNA GARANT�A, incluso sin la garant�a MERCANTIL impl�cita 
 * o sin garantizar la CONVENIENCIA PARA UN PROP�SITO PARTICULAR. 
 * V�ase la Licencia P�blica General de GNU para m�s detalles.
 * 
 * Deber�a haber recibido una copia de la Licencia P�blica General 
 * junto con este programa. Si no ha sido as�, escriba a la Free 
 * Software Foundation, Inc., en 675 Mass Ave, Cambridge, 
 * MA 02139, EEUU.
 */

#include <SDL.h>
#include <math.h>

int iniciar_sdl (SDL_Surface ** screen);
void esperar (void);
void put_pixel (SDL_Surface * screen, int x, int y, Uint32 color);
void roundrect (SDL_Surface *screen, int x0, int y0, int w, int h, int radio, Uint32 color);


/*
 * 
 */
int main (int argc, char * argv [])
{
	SDL_Surface * screen;
	Uint32 color;
	int i;

	if (iniciar_sdl (&screen))
		return 1;

	color = SDL_MapRGB (screen->format, 0xFF, 0xFF, 0xFF);
	roundrect (screen, 50, 50, 220, 140, 20, color);
	
	SDL_Flip (screen);
	esperar ();
	SDL_Quit ();	

	return 0;
}



/*
 * Imprime un rect�ngulo con puntas redondeadas.
 *
 * screen: superficie donde se imprimir� el rect�ngulo.
 * x0: esquina superior izquierda
 * y0: esquina superior izquierda
 * w: ancho total
 * h: alto total
 * radio: radio de difuminaci�n
 * color: color del borde
 */
void roundrect (SDL_Surface *screen, int x0, int y0, int w, int h, int radio, Uint32 color)
{
	int x;
	int y=0;
	int xa = x0 + radio;
	int ya = y0 + radio;
	int xb = x0 + w - radio;
	int yb = y0 + h - radio;

	if (SDL_MUSTLOCK (screen))
		SDL_LockSurface (screen);

	for (x = 0; x <= y; x ++)
	{
		y = (int) sqrt (radio * radio - x * x);

		/* primer cuadrante */
		put_pixel (screen, xb + x, ya - y, color);
		put_pixel (screen, xb + y, ya - x, color);
	
		/* segundo cuadrante */
		put_pixel (screen, xa - x, ya - y, color);
		put_pixel (screen, xa - y, ya - x, color);
	
		/* tercer cuadrante */
		put_pixel (screen, xa - x, yb + y, color);
		put_pixel (screen, xa - y, yb + x, color);

		/* cuarto cuadrante */
		put_pixel (screen, xb + x, yb + y, color);
		put_pixel (screen, xb + y, yb + x, color);
	}

	/* lineas horizontales */
	for (x = xa; x < xb; x ++)
	{
		put_pixel (screen, x, y0, color);
		put_pixel (screen, x, yb + radio, color);
	}

	/* lineas verticales */
	for (y = ya; y < yb; y ++)
	{
		put_pixel (screen, x0, y, color);
		put_pixel (screen, xb + radio, y, color);
	}

	if (SDL_MUSTLOCK (screen))
		SDL_UnlockSurface (screen);
}



/*
 * Inicia la biblioteca.
 */
int iniciar_sdl (SDL_Surface ** screen)
{
	if (SDL_Init (0))
	{
		printf ("No se puede inicializar SDL: %s\n", SDL_GetError ());
		return 1;
	}

	* screen = SDL_SetVideoMode (320, 240, 32, SDL_HWSURFACE);

	if (* screen == NULL)
	{
		printf ("Fall� al iniciar el video: %s\n", SDL_GetError ());
		return 1;
	}

	SDL_WM_SetCaption ("Ejercicio roundrect", NULL);
	
	return 0;
}



/*
 * Imprime un punto en la pantalla.
 */
void put_pixel (SDL_Surface *screen, int x, int y, Uint32 color)
{
	int bpp = screen->format->BytesPerPixel;
	Uint8 *p = (Uint8 *) screen->pixels + y * screen->pitch + x * bpp;

	if (x > screen->w || y > screen->h || y < 0 || x < 0)
		return;

	switch (bpp)
	{
		case 1:
			*p = color;
			break;
		
		case 2:
			*(Uint16 *)p = color;
			break;

		case 3:
			if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
			{
				p[0] = (color >> 16) & 0xff;
				p[1] = (color >> 8) & 0xff;
				p[2] = color & 0xff;
			}
			else
			{
				p[0] = color & 0xff;
				p[1] = (color >> 8) & 0xff;
				p[2] = (color >> 16) & 0xff;
			}
			break;
		
		case 4:
			* (Uint32 *)p  = color;
			break;
	}

}



/*
 * Detiene el programa hasta que el usuario realiza alg�n evento.
 */
void esperar (void)
{
	SDL_Event evento;

	while (SDL_WaitEvent (&evento))
	{
		if (evento.type == SDL_QUIT)
			break;

		if (evento.type == SDL_KEYDOWN)
			break;
	}
}
