/* **************************************************************************
/* * Programa: rectangulo.c
/* * Lenguaje: C
/* * Autor: fhenix@softhome.net
/* * Info: codificaci�n de un rect�ngulo de esquinas redondeadas. Se incluye c�digo
/* *      de prueba.
/* *  Uso:
/* *        > rectangulo     | dibuja un rect�ngulo por defecto
/* *        > rectangulo x0 y0 alto ancho angulo  | dibuja el rect�ngulo especificado
/* *
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <SDL/SDL.h>
#include <time.h>


#define PI 3.14

void rectangulo(SDL_Surface *, int, int, int, int, int, Uint32);
void Recta2Puntos(SDL_Surface *, int, int ,int, int, Uint32);
void PutPixel(SDL_Surface *, int, int, Uint32);
void Arco(SDL_Surface *, int, int, float, float, int, Uint32);


/*****************  FUNCION PRINCIPAL **********************************/
int main (int narg, char *argv[])
{
    SDL_Surface *screen = NULL;
    SDL_Event suceso;
    
    char *msg;
    int salir, x0, y0, ancho, alto, color, angulo=0;

    /* Initialize SDL */
    if (SDL_Init (SDL_INIT_VIDEO) < 0)
    {
        sprintf (msg, "Error, error en -> SDL: %s\n", SDL_GetError ());
        free (msg);
        exit (1);
    }

    atexit(SDL_Quit);

    /* Set 640x480 16-bits video mode */
    screen = SDL_SetVideoMode (320, 200, 16, SDL_SWSURFACE | SDL_DOUBLEBUF);
    if (screen == NULL)
    {
        sprintf (msg, "Error en la ejecuci�n del modo -> 640x480x16: %s\n",
          SDL_GetError ());
        free (msg);
        exit (2);
    }
    SDL_WM_SetCaption ("Prueba SDL: Rect�ngulo Redondeado. ESC para salir. :)", NULL);

    salir = 0;

    srand(time(NULL));
    
    //Pintamos el rectangulo que haya especificado el usuario, en la l�nea de
    //comandos... si no, pintamos uno por defecto.
    if (narg==6) {
       x0=atoi(argv[1]);
       y0=atoi(argv[2]);
       alto=atoi(argv[3]);
       ancho=atoi(argv[4]);
       angulo=atoi(argv[5]);
    }
     else {
          x0=60;
          y0=60;
          ancho=500;
          alto=300;
          angulo=40;
     }          

    while (!salir) {
      while (SDL_PollEvent (&suceso))
        {
            switch (suceso.type)
            {
            case SDL_KEYDOWN:
                 switch(suceso.key.keysym.sym) {
                   case SDLK_ESCAPE:
		           salir=1;
		           break;
             }
            break;           
            default:
                break;
            }
        }
        color=SDL_MapRGB(screen->format, rand()%0xff, rand()%0xff, rand()%0xff);
        rectangulo(screen, x0, y0, alto, ancho, angulo, color);
        
        SDL_Flip (screen);
        if (!salir) {
            SDL_Delay(50);
        }
    }

    return 0;
}



/************************** Funciones ******************************/


void rectangulo(SDL_Surface *destino, int x0, int y0, int h, int w, int radio, Uint32 color) {

     int x1=x0+w, y1=y0+h;  //usaremos coordenadas mejor.
       
     Recta2Puntos(destino, x0+radio, y0, x1-radio, y0, color);
     Recta2Puntos(destino, x0+radio, y1, x1-radio, y1, color);
     Recta2Puntos(destino, x1, y0+radio, x1, y1-radio, color);
     Recta2Puntos(destino, x0, y0+radio, x0, y1-radio, color);
       
       
     Arco(destino, x0+radio, y0+radio, 90.0, 180.0, radio+1, color);
     Arco(destino, x0+radio, y1-radio, 180.0, 270.0, radio+1, color);
     Arco(destino, x1-radio, y1-radio, 270.0, 360.0, radio+1, color);
     Arco(destino, x1-radio, y0+radio, 0.0, 90.0, radio+1, color);
           
}//Fin Rectangulo

void Recta2Puntos(SDL_Surface *pantalla, int x0, int y0, int x1, int y1, Uint32 color)
{
   int x=0, y=0, incx=0, incy=0, temp=0, mayorY=0;
      
   if (x0 > x1) 
     {
	temp=x0;
	x0=x1;
	x1=temp;
	temp=y0;
	y0=y1;
	y1=temp;
     }
   
   if ((x1-x0)==0) 
     {
	if(y0 > y1)
	  {
	     temp=x0;
	     x0=x1;
	     x1=temp;
	     temp=y0;
	     y0=y1;
	     y1=temp;
	  }
      	for(y=y0; y<=y1; y++)
	  PutPixel(pantalla, x0+incx, y+incy, color);
     }
   else
     {
	for (x=x0; x<=x1; x++)
	  {
	     y=(((y1-y0)*(x-x0))/(x1-x0))+y0;
	     PutPixel(pantalla, x+incx, y+incy, color);
	  }
     }
}//fin Recta2Puntos

void PutPixel(SDL_Surface *pantalla, int x, int y, Uint32 pixel) 
{
   int bpp=pantalla->format->BytesPerPixel;
   Uint8 *p=(Uint8 *)pantalla->pixels + y * pantalla->pitch + x * bpp;
   
   switch (bpp) 
     {
      case 1:
	*p=pixel;
	break;
      case 2:
	*(Uint16 *)p=pixel;
	break;
      case 3:
	if(SDL_BYTEORDER == SDL_BIG_ENDIAN) 
	  {
	     p[0]=(pixel >> 16) & 0xff;
	     p[1]=(pixel >> 8) & 0xff;
	     p[2]=pixel & 0xff;
	  }
	else 
	  {
	     p[0]=pixel & 0xff;
	     p[1]=(pixel >> 8) & 0xff;
	     p[2]=(pixel >> 16) & 0xff;
	  }
	break;
      case 4:
	*(Uint32 *)p=pixel;
	break;
     }
}//fin PutPixel

void Arco(SDL_Surface *pantalla, int x0, int y0, float inicio, float fin, int radio, Uint32 color)
{
   int x, y;
   float angulo=0, res;   
   
   res=(2*PI)/360.0;
   
   for(angulo=inicio; angulo<=fin; angulo+=0.1)
     {
	x=radio*cos(res*angulo);
	y=radio*sin(res*angulo);
	PutPixel(pantalla, x+x0, y0-y, color);
     }
}//fin Arco
