/*

    Archivo: main.cpp

    Descripcion: Funciones principales del game loop.

    Autor:  Roberto Albornoz Figueroa
            ralbornoz@gmail.com
            http://www.blogrcaf.com

    Fecha: 17-marzo-2007

*/

#include "graph.h"
#include "CSnow.h"

SDL_Event event;                //!< Manejo de eventos
Uint8 *keyboard=NULL;           //!< Mapa del teclado
CSnow snow;                     //!< Simulacion de nieve
SDL_Surface *fondo=NULL;        //!< Imagen de fondo

// Funciones del game loop
void GameLoop();
void Init();
int Input();
void Update();
void Draw();
void Quit();

// Funcion principal
int main(int argc, char **argv)
{
    Init();

    Draw();
    FadeIn();

    GameLoop();

    FadeOut();

    Quit();

    return 0;
}

//! Ciclo del juego
void GameLoop()
{
    int exit=0;

    Clear(screen);

    while(!exit)
    {
        exit=Input();
        Update();
        Draw();
        Flip();
        SDL_Delay(10);
    }
}

//! Inicializa el sistema
void Init()
{
    // Inicializa modo de video
    InitGraph(640, 480, 32, false);
    WindowTitle("Simulacion de nieve by RCAF (C) 2007");

    // Cargamos imagen de fondo
    fondo=IMG_Load("fondo.jpg");

    // Crea e inicializa la nieve
    snow.SetArea(0, 0, 640, 480);
    snow.SetMaxSnowflake(900);
    snow.Init();

    // Esconde el cursor del mouse
    SDL_ShowCursor(false);
}

//! Cierra el sistema
void Quit()
{
    // Liberamos memoria de la superficie
    if(fondo) SDL_FreeSurface(fondo);

    // Cierra biblioteca SDL
    QuitGraph();
}

//! Lectura de eventos y teclado
int Input()
{
    // Captura de Eventos
    while (SDL_PollEvent(&event))
    {
        if (event.type == SDL_QUIT)
            return 1;
    }

    // Estado del teclado
    keyboard=SDL_GetKeyState(0);

    // Con ESC cerramos la ventana
    if (keyboard[SDLK_ESCAPE]) return 1;

    return 0;
}

//! Actualiza logica
void Update()
{
    // Mueve los copos de nieve
    snow.Update();
}

//! Dibujado de graficos
void Draw()
{
    // Dibujamos el fondo en la pantalla
    if(fondo) Blit(fondo);
    // Limpiamos pantalla
    else Clear(screen);

    // Dibuja los copos de nieve
    snow.Draw();
}
