/*

    Archivo: CSnow.h

    Descripcion: Clase que maneja simulacion de nieve

    Autor:  Roberto Albornoz Figueroa
            ralbornoz@gmail.com
            http://www.blogrcaf.com

    Fecha: 19-marzo-2007

*/

#ifndef CSNOW_H
#define CSNOW_H

#include "CParticleSystem.h"
#include <list>

//! Clase CSnow maneja simulacion de nieve
class CSnow: public CParticleSystem
{
public:

    CSnow();
    ~CSnow();

    void Init();
    void Update();
    void Draw();

    //! Setea el maximo de copos de nieve
    void SetMaxSnowflake(int max)
    {
        max_snowflake=max;
    }

private:

    particle_t CreateSnowflake();

    std::list<particle_t> snowflake;       //!< Copos de nieve
    std::list<particle_t>::iterator it;    //!< Iterador de la lista de copos de nieve
    int max_snowflake;                     //!< Numero maximo de copos de nieve
    Uint32 color_snowflake;                //!< Color del copo de nieve
};

#endif
