/*

    Archivo: CParticleSystem.h

    Descripcion: Clase abstracta para manejar sistemas de particulas

    Autor:  Roberto Albornoz Figueroa
            ralbornoz@gmail.com
            http://www.blogrcaf.com

    Fecha: 17-marzo-2007

*/

#ifndef CPARTICLE_SYSTEM_H
#define CPARTICLE_SYSTEM_H

#include "graph.h"
#include "CRandom.h"

//! Datos de una particula
typedef struct
{
    SDL_Rect pos;
    SDL_Rect vel;
    Uint32 color;
} particle_t;

//! Clase que maneja un sistema de particulas determinado
class CParticleSystem
{
public:

    CParticleSystem() {};
    virtual ~CParticleSystem() {};

    //! Inicializa todas las particulas
    virtual void Init()=0;

    //! Movimiento de cada una de las particulas
    virtual void Update()=0;

    //! Dibuja todas las particulas
    virtual void Draw()=0;

    //! Area de la pantalla por la cual se moveran las particulas
    void SetArea(int x, int y, int w, int h)
    {
        if(x < 0) x=0;
        if(y < 0) y=0;

        if(x >= SCREEN_W) x=SCREEN_W;
        if(y >= SCREEN_H) y=SCREEN_H;

        area.x=x;
        area.y=y;

        if (area.x+w < SCREEN_W) area.w=w;
        else area.w=SCREEN_W-area.x;

        if (area.y+h < SCREEN_H) area.h=h;
        else area.h=SCREEN_H-area.y;

        //printf("area=(%d, %d, %d, %d)\n", area.x, area.y, area.w, area.h);
    }

protected:

    CRandom random; //!< Objeto para manejar numeros aleatorios
    SDL_Rect area;  //!< Area donde se muestra el efecto
};

#endif
