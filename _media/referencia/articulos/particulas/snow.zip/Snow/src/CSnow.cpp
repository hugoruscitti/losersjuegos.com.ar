/*

    Archivo: CSnow.cpp

    Descripcion: Clase que maneja simulacion de nieve

    Autor:  Roberto Albornoz Figueroa
            ralbornoz@gmail.com
            http://www.blogrcaf.com

    Fecha: 19-marzo-2007

*/

#include "CSnow.h"
#include <math.h>
#include <algorithm>

//! Constructor
CSnow::CSnow():CParticleSystem()
{
    max_snowflake=500;
}

//! Destructor
CSnow::~CSnow()
{
}

//! Inicializa los copos de nieve
void CSnow::Init()
{
    for(int i=0; i < max_snowflake; ++i)
    {
        particle_t sf=CreateSnowflake();
        snowflake.push_back(sf);
    }
}

//! Mueve los copos de nieve
void CSnow::Update()
{
    // Recorremos todos los copos de nieve
    for(it=snowflake.begin(); it!=snowflake.end(); ++it)
    {
        // Modificamos posicion del copo
        it->pos.y+=it->vel.y;
        if(random.GetInt(0, 1)) it->pos.x+=it->vel.x;

        // Si el copo sale del area, creamos uno nuevo
        if((it->pos.x <= area.x) || (it->pos.x >= area.x+area.w-1) || (it->pos.y >= area.y+area.h-1))
        {
            particle_t sf=CreateSnowflake();
            sf.pos.y=area.y;
            *it=sf;
        }
    }
}

//! Dibuja cada una de la estrellas
void CSnow::Draw()
{
    LockScreen();

    // Recorremos todos los copos de nieve
    for(it=snowflake.begin(); it!=snowflake.end(); ++it)
    {
        // Dibujamos nuevo copo
        PutPixel(screen, it->pos.x, it->pos.y, color_snowflake);
    }

    UnlockScreen();
}

//! Crea un copo de nieve
particle_t CSnow::CreateSnowflake()
{
    particle_t sf;

    // Posicion inicial
    sf.pos.x=random.GetInt(area.x, area.x+area.w-1);
    sf.pos.y=random.GetInt(area.y, area.y+area.h-1);
    sf.vel.x=random.GetInt(0, 1);
    sf.vel.y=random.GetInt(1, 2);

    if(sf.vel.x==0) sf.vel.x=-1;

    // Color del copo de nieve
    color_snowflake=MakeColorRGB(255, 255, 255);

    return sf;
}

