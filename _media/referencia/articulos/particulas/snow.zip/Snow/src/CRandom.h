/*

    Archivo: CRandom.h

    Descripcion: Clase para manejar numeros aleatorios (enteros y/o reales)

    Autor:  Roberto Albornoz Figueroa
            ralbornoz@gmail.com
            http://www.blogrcaf.com

    Fecha: 17-marzo-2007

*/

#ifndef CRANDOM_H
#define CRANDOM_H

#include <stdlib.h>
#include <time.h>

//! Clase CRandom maneja numeros aleatorios de tipo entero o real
class CRandom
{
public:

    //! Constructor
    CRandom()
    {
        Init();
    }

    //! Destructor
    ~CRandom()
    {
    }

    //! Inicializa la semilla de numeros aleatorios
    void Init()
    {
        srand(time(0));
    }

    //! Devuelve un numero entero aleatorio desde un rango dado
    //! param ini valor inicial
    //! param end valor final
    int GetInt(int ini, int end)
    {
        return ini + (int) ((float) (end-ini+1) * (rand() / (RAND_MAX + 1.0)));
    }

    //! Devuelve un numero real aleatorio desde un rango dado
    //! param ini valor inicial
    //! param end valor final
    float GetFloat(float ini, float end)
    {
        return ini + (end-ini) * (rand() / (RAND_MAX + 1.0));
    }
};

#endif
