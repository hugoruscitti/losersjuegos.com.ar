Simulaci�n de nieve
====================


Descripci�n
===========

Simulacion de nieve utilizando la biblioteca SDL

Se cuenta con una clase abstracta denominada CParticleSystem la cual tiene las funciones
b�sicas para manejar un sistema de part�culas.

La clase CSnow maneja una simulaci�n de nieve simple que hereda de la clase CParticleSystem.

La clase CRandom maneja n�meros aleatorios (enteros o reales).

En graph.cpp se manejan las funciones b�sicas para inicializar un modo de video, mostrar pixeles, efectos fade in/out, etc.

En main.cpp se encuentran las funciones b�sicas para el manejo del game loop. 
Contiene la l�gica del programa.


Funcionamiento
==============

Se debe tener una imagen de 640x480 en formato jpg en el directorio del ejecutable.

En el directorio bin se incluye una imagen de prueba.


Compilaci�n de c�digo
=====================

Se necesita tener instalado en el sistema la biblioteca SDL y SDL_image.

Windows
-------

  gcc -o snow.exe graph.cpp CSnow.cpp main.cpp -lmingw32 -lSDLmain -lSDL -lSDL_image -mwindows


Linux
-----

  gcc -o snow graph.cpp CSnow.cpp main.cpp `sdl-config --cflags --libs` -lSDL_image


Autor
=====

Roberto Albornoz Figueroa
ralbornoz@gmail.com
http://www.blogrcaf.com

