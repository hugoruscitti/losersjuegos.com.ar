from random import randrange
import math
import pygame
from pygame.locals import *


class Particle:
    
    def __init__(self):
        self.x = randrange(0, 320)
        self.y = randrange(0, 240)

        c1 = randrange(100, 255)
        c2 = randrange(100, 255)
        c3 = randrange(100, 255)
        self.color = (c1, c2, c3)

        self.t = randrange(100, 300)
        self.ratio = randrange(100, 120)

    def update(self):

        self.t += 0.05
        self.x = int(math.cos(self.t) * self.ratio) + 160
        self.y = int(math.sin(self.t * 2) * self.ratio / 2) + 120


if __name__ == '__main__':
    
    screen = pygame.display.set_mode((320, 240))
    quit = False
    particles = [Particle() for _ in xrange(900)]

    while not quit:

        screen.fill((0, 0, 0))

        for e in pygame.event.get():
            if e.type == QUIT:
                quit = True

        for p in particles:
            p.update()
            screen.set_at((p.x, p.y), p.color)

        pygame.display.flip()
        pygame.time.delay(1)
