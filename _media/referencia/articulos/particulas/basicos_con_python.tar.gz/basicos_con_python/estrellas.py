from random import randrange
import pygame
from pygame.locals import *


class Particle:
    
    def __init__(self):
        c = randrange(100, 255)
        self.x = randrange(0, 320)
        self.y = randrange(0, 240)
        self.color = (c, c, c)

    def update(self):

        self.x += 1
        self.y += 1

        if self.x >= 320:
            self.x = 0

        if self.y >= 240:
            self.y = 0



if __name__ == '__main__':
    
    screen = pygame.display.set_mode((320, 240))
    quit = False
    particles = [Particle() for _ in xrange(210)]

    while not quit:

        screen.fill((0, 0, 0))

        for e in pygame.event.get():
            if e.type == QUIT:
                quit = True

        for p in particles:
            p.update()
            screen.set_at((p.x, p.y), p.color)

        pygame.display.flip()
        pygame.time.delay(1)
