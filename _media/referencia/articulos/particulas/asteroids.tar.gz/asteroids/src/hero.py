# -*- coding: utf-8 -*-
# Copyright 2007 Hugo Ruscitti <hugoruscitti@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA

import pygame
from pygame.locals import *

from sprite import Sprite


class Hero(Sprite):
    
    def __init__(self, world):
        Sprite.__init__(self)
        self.world = world
        self.angle = 0
        self.update_image()
        self.rect = self.image.get_rect()
        self.delay = 0
        self.velocity = 0
        self.restart()
        self.ratio = self.rect.w / 2

    def restart(self):
        self.x, self.y = 320, 240
        self.invisible_delay = 100

    
    def update_image(self):
        self.image = self.world.gallery.hero_sprites[- self.angle]


    def update(self):

        keys = pygame.key.get_pressed()
        d = 4

        if keys[K_LEFT]:
            self.turn(-4)
        elif keys[K_RIGHT]:
            self.turn(+4)

        if keys[K_UP]:
            self.advance(0.5)

        self.velocity = max(0, self.velocity - 0.2)
        self.dx = self.world.angle.cos(self.angle) * self.velocity
        self.dy = self.world.angle.sin(self.angle) * self.velocity
        self.x += self.dx
        self.y += self.dy

        if self.delay < 1:
            if keys[K_SPACE] or keys[K_RETURN]:
                self.world.create_shot(self.x, self.y, self.angle)
                self.delay = 30
        else:
            self.delay -= 1

        self.update_out_screen()
        self.update_rect()
        
        if self.invisible_delay > 0:
            self.image.set_alpha((100 - self.invisible_delay) % 10 * 25)
            self.invisible_delay -= 1
        else:
            self.image.set_alpha(255)
            


    def can_die(self):
        return self.invisible_delay == 0


    def advance(self, delta):

        if self.velocity > 5:
            self.velocity = 5
        else:
            self.velocity = max(self.velocity + delta, 0)


    def turn(self, delta):
        self.angle += delta

        if self.angle >= 360:
            self.angle -= 360
        elif self.angle < 0:
            self.angle += 360

        self.update_image()
