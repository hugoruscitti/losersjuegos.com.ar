# -*- coding: utf-8 -*-
# Copyright 2007 Hugo Ruscitti <hugoruscitti@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA

import pygame
from sprite import Sprite

class Rock(Sprite):
    
    def __init__(self, world, x, y, size, angle, speed):

        Sprite.__init__(self)
        self.world = world
        self.size = size
        self.speed = speed
        self.dx = world.angle.cos(angle) * speed
        self.dy = world.angle.sin(angle) * speed
        self.x, self.y = x, y
        self.images_list = world.gallery.rock_sprites[size]
        self.rotate_angle = 0
        self.update_image()
        self.ratio = self.rect.w / 2


    def update(self):
        self.x += self.dx
        self.y += self.dy
        self.update_image()
        self.update_out_screen()
        self.update_rect()


    def update_image(self):
        self.image = self.images_list[self.rotate_angle % 360]
        self.rotate_angle += self.speed * 2
        self.rect = self.image.get_rect()


    def destroy(self, shot_angle):
        "Destruye la roca generando rocas mas pequeñas si corresponde"

        angle = shot_angle + 90
            
        if self.size > 0:
            x = self.x
            y = self.y
            size = self.size - 1

            self.world.create_rock(x, y, size, angle, self.speed)
            self.world.create_rock(x, y, size, angle + 180, self.speed)

        self.kill()
