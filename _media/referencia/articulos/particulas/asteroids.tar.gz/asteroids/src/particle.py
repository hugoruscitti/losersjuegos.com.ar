# -*- coding: utf-8 -*-
# Copyright 2007 Hugo Ruscitti <hugoruscitti@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA

import pygame
from sprite import Sprite


class Particle(Sprite):
    
    def __init__(self, world, x, y, angle, power, color):
        Sprite.__init__(self)
        self.image = pygame.Surface((1, 1)).copy()
        self.rect = self.image.get_rect()
        self.rect.move_ip(x, y)
        self.color = color
        self.dx = int(world.angle.cos(angle) * power)
        self.dy = int(world.angle.sin(angle) * power)


    def update(self):
        self._reduce_color()
        self.rect.move_ip(self.dx, self.dy)


    def _reduce_color(self):
        "Disminuye las componentes de color de la partícula hasta desaparecer"

        r, g, b = self.color
        speed = 3

        if r == 0 and g == 0 and b == 0:
            self.kill()
        else:
            r = max(0, r - speed)
            g = max(0, g - speed)
            b = max(0, b - speed)
            self.color = (r, g, b)
            self.image.fill(self.color)
        
