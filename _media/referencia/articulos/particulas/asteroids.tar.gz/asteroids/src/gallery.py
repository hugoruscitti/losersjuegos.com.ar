# -*- coding: utf-8 -*-
# Copyright 2007 Hugo Ruscitti <hugoruscitti@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA

from pygame.transform import rotate
from pygame.image import load


class Gallery:
    "Almacena las imagenes del juego en todos sus cuadros de rotación"
    
    def __init__(self):

        magenta = (255, 0, 255)

        hero = load('ima/hero.png').copy()
        hero.set_colorkey(magenta)
        
        self.hero_sprites = [rotate(hero, angle) for angle in range(0, 360)]

        names = ['rock_small', 'rock_medium', 'rock_big']
        rock = [load('ima/' + n + '.png').copy() for n in names]
        
        for r in rock:
            r.set_colorkey(magenta)

        self.rock_sprites = [
            [rotate(rock[0], angle) for angle in range(0, 360)],
            [rotate(rock[1], angle) for angle in range(0, 360)],
            [rotate(rock[2], angle) for angle in range(0, 360)]]

        shot = load('ima/shot.png').copy()
        shot.set_colorkey((255, 0, 255))

        self.shot_sprites = [rotate(shot, angle) for angle in range(0, 360)]
