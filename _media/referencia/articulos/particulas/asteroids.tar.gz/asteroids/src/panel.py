# -*- coding: utf-8 -*-
# Copyright 2007 Hugo Ruscitti <hugoruscitti@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA

import pygame
from text import Text


class Panel:
    
    def __init__(self, word_sprites, initial_level):
        pygame.font.init()
        self.score_counter = 0
        self.dies_counter = -1

        font = pygame.font.Font(None, 22)
        self.score = Text(font, 10, 10)
        self.level = Text(font, 280, 10)
        self.dies = Text(font, 580, 10)

        word_sprites.add([self.score, self.level, self.dies])
        self.set_level(initial_level)
        self.add_score(0)
        self.add_dies()

    def add_score(self, score):
        self.score_counter += score
        self.score.set_text("Score: %d" % (self.score_counter))

    def set_level(self, level):
        self.level.set_text("Level: %d" % (level))

    def add_dies(self):
        self.dies_counter += 1
        self.dies.set_text("Dies: %d" % (self.dies_counter))
