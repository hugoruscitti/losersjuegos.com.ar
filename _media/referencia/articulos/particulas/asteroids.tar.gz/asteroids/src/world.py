# -*- coding: utf-8 -*-
# Copyright 2007 Hugo Ruscitti <hugoruscitti@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA

import pygame
from angle import Angle
from particle import Particle
from staticparticle import StaticParticle
from random import randint
from hero import Hero
from rock import Rock
from shot import Shot
from panel import Panel
from gallery import Gallery
from audio import Audio


class World:

    
    def __init__(self):

        pygame.display.init()
        pygame.mouse.set_visible(False)
        self.screen = pygame.display.set_mode((640, 480), 16)
        self.background = self.screen.copy()
        
        self.gallery = Gallery()
        self.audio = Audio()
        self.angle = Angle()
        self.clock = pygame.time.Clock()
        self.quit = False
        self.sprites = pygame.sprite.RenderUpdates()
        self.draw_background()
        self.dificulty = 1
        self.create_sprites()
        self.panel = Panel(self.sprites, self.dificulty)


    def create_sprites(self):
        "Crea los actores iniciales del juego"

        self.rock_sprites = pygame.sprite.Group()
        self.shot_sprites = pygame.sprite.Group()
        self.hero = Hero(self)
        self.sprites.add(self.hero)
        self.create_rocks()
        

    def draw_background(self):
        "Imprime un campo con estrellas simple"

        for p in range(70):
            x = randint(0, 640)
            y = randint(0, 480)
            color = randint(150, 255)
            self.sprites.add(StaticParticle(x, y, color))


    def main(self):
        "Bucle principal del juego"

        while not self.quit:

            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    self.quit = True
                elif e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_q or e.key == pygame.K_ESCAPE:
                        self.quit = True
                    elif e.key == pygame.K_f:
                        pygame.display.toggle_fullscreen()
            
            self.sprites.update()
            self.sprites.clear(self.screen, self.background)
            pygame.display.update(self.sprites.draw(self.screen))
            self.clock.tick(60)

            self.check_collisions()


    def check_collisions(self):
        "Analiza e informa a los actores del juego las colisiones ocurridas"

        # colisiones entre disparos y piedas

        collision = self.group_collision(self.shot_sprites, self.rock_sprites)

        if collision:
            shot, rock = collision
            green = (100, 255, 100)
            self.panel.add_score((rock.size + 1) * 5)
            self.create_explosion(rock.x, rock.y, rock.size, green)
            rock.destroy(shot.angle)
            self.audio.play(randint(1, 2))
            shot.kill()
           
            if len(self.rock_sprites) < 1:
                self.dificulty += 1
                self.create_rocks()
                self.panel.set_level(self.dificulty)
            

        # colisiones entre la nave y las piedras
        
        if self.hero.can_die():
            if self.sprite_collision(self.hero, self.rock_sprites):
                black = (255, 255, 255)
                self.create_explosion(self.hero.x, self.hero.y, 4, black)
                self.hero.restart()
                self.panel.add_dies()
                self.audio.play(randint(1, 2))


    def group_collision(self, groupa, groupb):

        groupa = groupa.sprites()
        groupb = groupb.sprites()

        for a in groupa:
            collision = self.sprite_collision(a, groupb)
            if collision:
                return collision

        return None

        
    def sprite_collision(self, sprite, group):
        "Verfica la existencia de una colision 'circular' entre sprites"

        for target in group:
            d = (sprite.ratio + target.ratio)
            if d * d > self.dist(sprite, target):
                return sprite, target


    def dist(self, s1, s2):
        "Returna la distancia entre dos puntos al cuadrado"
        b = int(s1.x - s2.x)
        a = int(s1.y - s2.y)
        return b * b + a * a

    def create_particle(self, x, y, angle, power, color=(255, 255, 255)):
        "Genera una partícula, de uso interno para create_explosion, por ej."

        self.sprites.add(Particle(self, x, y, angle, power, color))


    def create_rocks(self):
        "Genera las rocas necesarias para la etapa del juego"

        for i in range(self.dificulty + 2):
            angle = randint(0, 360)

            if angle > 90 and angle < 270:
                self.create_rock(640, i * 100, 2, angle, 2)
            else:
                self.create_rock(-30, i * 100, 2, angle, 2)
                
       
    def create_rock(self, x, y, size, angle, speed):
        "Genera una roca"

        new = Rock(self, x, y, size, angle, speed)
        self.rock_sprites.add(new)
        self.sprites.add(new)


    def create_shot(self, x, y, angle):
        "Crea un disparo"

        new = Shot(self, x, y, angle)
        self.shot_sprites.add(new)
        self.sprites.add(new)
        self.audio.play(0)


    def create_explosion(self, x, y, size, color):
        "Genera una explosion de particulas"
        
        for angle in range(0, 360, 10):
            for speed in range(3, 5 + size):
                self.create_particle(x, y, angle, speed, color)
            


if __name__ == '__main__':

    w = World()
    w.main()
