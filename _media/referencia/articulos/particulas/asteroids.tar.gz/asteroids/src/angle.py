# -*- coding: utf-8 -*-
# Copyright 2007 Hugo Ruscitti <hugoruscitti@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA


from math import pi, cos, sin, radians

class Angle:
    "Gestiona las relaciones geometrias"
    
    def __init__(self):

        angles = range(0, 360)
        self.cos_table = [cos(radians(x)) for x in angles]
        self.sin_table = [sin(radians(x)) for x in angles]

    def cos(self, angle):
        return self.cos_table[angle % 360]

    def sin(self, angle):
        return self.sin_table[angle % 360]
