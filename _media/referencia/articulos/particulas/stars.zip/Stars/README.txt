Demo Campo de Estrellas
========================


Descripci�n
===========

Creaci�n de un Campo de Estrellas utilizando la biblioteca SDL

Se cuenta con una clase abstracta denominada CParticleSystem la cual tiene las funciones
b�sicas para manejar un sistema de part�culas.

La clase CStars maneja un campo de estrellas que hereda de la clase CParticleSystem.

La clase CRandom maneja n�meros aleatorios (enteros o reales).

En graph.cpp se manejan las funciones b�sicas para inicializar un modo de video, mostrar pixeles, efectos fade in/out, etc.

En main.cpp se encuentran las funciones b�sicas para el manejo del game loop. 
Contiene la l�gica del programa.


Funcionamiento
==============

Para ver las distintas direcciones del campo de estrellas, presiona los cursores del teclado (arriba, abajo, izquierda, derecha).


Compilaci�n de c�digo
=====================

Windows
-------

  gcc -o stars.exe graph.cpp CStars.cpp main.cpp -lmingw32 -lSDLmain -lSDL -mwindows


Linux
-----

  gcc -o stars graph.cpp CStars.cpp main.cpp `sdl-config --cflags --libs`


Autor
=====

Roberto Albornoz Figueroa
ralbornoz@gmail.com
http://www.blogrcaf.com

