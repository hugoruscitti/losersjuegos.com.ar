/*

    Archivo: CStars.h

    Descripcion: Clase que maneja un campo de estrellas

    Autor:  Roberto Albornoz Figueroa
            ralbornoz@gmail.com
            http://www.blogrcaf.com

    Fecha: 17-marzo-2007

*/

#ifndef CSTARS_H
#define CSTARS_H

#include "CParticleSystem.h"
#include <list>

//! Direciones posibles para mover el campo de estrellas
enum direction_t { STARS_UP, STARS_DOWN, STARS_LEFT, STARS_RIGHT };

//! Clase CStars maneja un campo de estrellas
class CStars: public CParticleSystem
{
public:

    CStars();
    ~CStars();

    void Init();
    void Update();
    void Draw();

    //! Setea el maximo de estrellas
    void SetMaxStars(int max_stars)
    {
        this->max_stars=max_stars;
    }

    //! Setea la direccion de las estrellas
    void SetDir(direction_t dir)
    {
        this->dir=dir;
    }

    //! Setea velocidad maxima de las estrellas
    void SetVelMax(int vel_max)
    {
        this->vel_max=vel_max;
    }

private:

    particle_t CreateStar();

    std::list<particle_t> stars;            //!< Lista de estrellas
    std::list<particle_t>::iterator it;     //!< Iterador de la lista de estrellas
    direction_t dir;                        //!< Direccion de las estrellas
    int vel_min, vel_max;                   //!< Rango de velocidad de cada estrella
    int max_stars;                          //!< Numero maximo de entrellas
};

#endif
