/*

    Archivo: CStars.cpp

    Descripcion: Clase que maneja un campo de estrellas

    Autor:  Roberto Albornoz Figueroa
            ralbornoz@gmail.com
            http://www.blogrcaf.com

    Fecha: 17-marzo-2007

*/

#include "CStars.h"
#include <math.h>
#include <algorithm>

//! Constructor
CStars::CStars():CParticleSystem()
{
    max_stars=300;
    dir=STARS_LEFT;

    // Rango de velocidades de las particulas
    vel_min=1;
    vel_max=5;
}

//! Destructor
CStars::~CStars()
{
}

//! Inicializa las estrellas
void CStars::Init()
{
    for(int i=0; i < max_stars; ++i)
    {
        particle_t star=CreateStar();
        stars.push_back(star);
    }
}

//! Mueve las estrellas
void CStars::Update()
{
    for (it=stars.begin(); it!=stars.end(); ++it)
    {
        if (dir == STARS_UP)
        {
            it->pos.y-=it->vel.y;
            if (it->pos.y < area.y)
            {
                *it=CreateStar();
                it->pos.y=area.y+area.h;
            }
        }
        else if (dir == STARS_DOWN)
        {
            it->pos.y+=it->vel.y;
            if (it->pos.y > area.y+area.h)
            {
                *it=CreateStar();
                it->pos.y=area.y;
            }
        }
        else if (dir == STARS_LEFT)
        {
            it->pos.x-=it->vel.x;
            if (it->pos.x < area.x)
            {
                *it=CreateStar();
                it->pos.x=area.x+area.w;
            }
        }
        else if(dir == STARS_RIGHT)
        {
            it->pos.x+=it->vel.x;
            if (it->pos.x > area.x+area.w)
            {
                *it=CreateStar();
                it->pos.x=area.x;
            }

        }
    }
}

//! Dibuja cada una de la estrellas
void CStars::Draw()
{
    LockScreen();

    for(it=stars.begin(); it!=stars.end(); ++it)
    {
       PutPixel(screen, it->pos.x, it->pos.y, it->color);
    }

    UnlockScreen();
}

//! Crea una estrella
particle_t CStars::CreateStar()
{
    particle_t star;

    // Posicion inicial
    star.pos.x=random.GetInt(area.x, area.x+area.w-1);
    star.pos.y=random.GetInt(area.y, area.y+area.h-1);

    // Velocidad inicial
    star.vel.x=random.GetInt(vel_min, vel_max);
    star.vel.y=random.GetInt(vel_min, vel_max);

    // Color inicial
    int c=random.GetInt(10, 255);
    star.color=MakeColorRGB(c, c, c);

    return star;
}

