/*

    Archivo: main.cpp

    Descripcion: Funciones principales del game loop.

    Autor:  Roberto Albornoz Figueroa
            ralbornoz@gmail.com
            http://www.blogrcaf.com

    Fecha: 17-marzo-2007

*/

#include "graph.h"
#include "CStars.h"

SDL_Event event;                //!< Manejo de eventos
Uint8 *keyboard=NULL;           //!< Mapa del teclado
SDL_Surface *fondo=NULL;        //!< Superficie de fondo
CStars stars;                   //!< Campo de estrellas

// Funciones del game loop
void GameLoop();
void Init();
int Input();
void Update();
void Draw();
void Quit();

// Funcion principal
int main(int argc, char **argv)
{
    Init();

    Draw();
    FadeIn();

    GameLoop();

    FadeOut();

    Quit();

    return 0;
}

//! Ciclo del juego
void GameLoop()
{
    int exit=0;

    while(!exit)
    {
        exit=Input();
        Update();
        Draw();
        Flip();
        SDL_Delay(10);
    }
}

//! Inicializa el sistema
void Init()
{
    // Inicializa modo de video
    InitGraph(800, 600, 32, false);
    WindowTitle("Campo de Estrellas by RCAF (C) 2007");

    // Crea e inicializa el campo de estrellas
    stars.SetArea(0, 0, 800, 600);
    stars.SetMaxStars(500);
    stars.SetVelMax(5);
    stars.SetDir(STARS_LEFT);
    stars.Init();

    // Crea e inicializa la superficie de fondo
    fondo=CreateSurface(800, 600);
    Clear(fondo, MakeColorRGB(0, 0, 50));
    SetAlpha(fondo, 120);

    // Esconde el cursor del mouse
    SDL_ShowCursor(false);
}

//! Cierra el sistema
void Quit()
{
    // Libera superficie fondo
    SDL_FreeSurface(fondo);

    // Cierra biblioteca SDL
    QuitGraph();
}

//! Lectura de eventos y teclado
int Input()
{
    // Captura de Eventos
    while (SDL_PollEvent(&event))
    {
        if (event.type == SDL_QUIT)
            return 1;
    }

    // Estado del teclado
    keyboard=SDL_GetKeyState(0);

    // Con ESC cerramos la ventana
    if (keyboard[SDLK_ESCAPE]) return 1;

    // Movimiento de las estrellas
    if (keyboard[SDLK_UP]) stars.SetDir(STARS_UP);

    if (keyboard[SDLK_DOWN]) stars.SetDir(STARS_DOWN);

    if (keyboard[SDLK_LEFT]) stars.SetDir(STARS_LEFT);

    if (keyboard[SDLK_RIGHT]) stars.SetDir(STARS_RIGHT);

    return 0;
}

//! Actualiza logica
void Update()
{
    // Mueve estrellas
    stars.Update();
}

//! Dibujado de graficos
void Draw()
{
    // Copia fondo en la pantalla
    Blit(fondo);

    // Dibuja estrellas
    stars.Draw();
}
