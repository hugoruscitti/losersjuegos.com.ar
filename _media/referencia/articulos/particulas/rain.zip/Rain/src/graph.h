/*

    Archivo: graph.h

    Descripcion: Funciones basicas de manejo de graficos.
                 Inicializacion de modo video, blitting, pixeles,
                 superficies, efectos fade in/out, etc.

    Autor:  Roberto Albornoz Figueroa
            ralbornoz@gmail.com
            http://www.blogrcaf.com

    Fecha: 17-marzo-2007

*/

#ifndef GRAPH_H
#define GRAPH_H

#ifdef WIN32
    #include <SDL/SDL.h>
    #include <SDL/SDL_image.h>
    #include <SDL/SDL_gfxPrimitives.h>
#else
    #include <SDL.h>
    #include <SDL_image.h>
    #include <SDL_gfxPrimitives.h>
#endif

// Variables globales
extern int SCREEN_W, SCREEN_H;          // Dimensiones del modo de video
extern int BPP;                         // Bits por pixel
extern SDL_Surface *screen;             // Puntero a la superficie pantalla
extern SDL_Event event;                 // Manejo de eventos
extern Uint8 *keyboard;                 // Mapa del teclado

// Prototipo de funciones
int InitGraph(int w, int  h, int bpp, bool fullscreen);
void QuitGraph();
void WindowTitle(const char *title);
void ShowMouse(bool toggle);
Uint32 MakeColorRGB(Uint8 r, Uint8 g, Uint8 b);
void PutPixel(SDL_Surface *surface, int x, int y, Uint32 color);
Uint32 GetPixel(SDL_Surface *surface, int x, int y);
void LockScreen();
void UnlockScreen();
void Clear(SDL_Surface *surface, Uint32 color=0);
SDL_Surface *CreateSurface(int w, int h);
void SetAlpha(SDL_Surface *surface, Uint8 alpha);
void Blit(SDL_Surface *surface);
void Blit(SDL_Surface *src, SDL_Surface *dst);
void Flip();
void FadeIn(int speed=5);
void FadeOut(int speed=5);

#endif
