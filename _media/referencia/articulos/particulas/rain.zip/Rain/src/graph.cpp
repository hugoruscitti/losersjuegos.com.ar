/*

    Archivo: graph.cpp

    Descripcion: Funciones basicas para inicializacion de modo video,
                 blitting, pixeles, superficies, efectos fade in/out

    Autor:  Roberto Albornoz Figueroa
            ralbornoz@gmail.com
            http://www.blogrcaf.com

    Fecha: 17-marzo-2007

*/

#include "graph.h"

// Variables globales
int SCREEN_W=0, SCREEN_H=0;     //!< Dimensiones del modo de video
int BPP=0;                      //!< Bits por pixel
SDL_Surface *screen=NULL;       //!< Puntero a la superficie pantalla

//! Inicializa biblioteca SDL y Modo de Video
int InitGraph(int w, int  h, int bpp, bool fullscreen)
{
    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0)
        return 0;

    SCREEN_W=w;
    SCREEN_H=h;
    BPP=bpp;
    int flags=SDL_HWSURFACE | SDL_DOUBLEBUF;

    if(fullscreen)
        flags|=SDL_FULLSCREEN;

    if((screen=SDL_SetVideoMode(w, h, bpp, flags)) < 0)
        return 0;

    return 1;
}

//! Cierra la biblioteca SDL
void QuitGraph()
{
    SDL_Quit();
}

//! Setea el titulo de la ventana
void WindowTitle(const char *title)
{
    SDL_WM_SetCaption(title, NULL);
}

//! Muestra/esconde el puntero del mouse
void ShowMouse(bool toggle)
{
    SDL_ShowCursor(toggle ? 1 : 0);
}

//! Crea un color RGB con el mismo formato de la pantalla
Uint32 MakeColorRGB(Uint8 r, Uint8 g, Uint8 b)
{
    return SDL_MapRGB(screen->format, r, g, b);
}

//! Coloca un pixel en una superficie
void PutPixel(SDL_Surface *surface, int x, int y, Uint32 color)
{
    if(x < 0 || y < 0 || x >= SCREEN_W || y >= SCREEN_H) return;

	int bpp = screen->format->BytesPerPixel;
	Uint8 * buffer = (Uint8 *) screen->pixels + y * screen->pitch + x*bpp;

	switch (bpp)
	{
		case 1: *buffer = color; break;
		case 2: *(Uint16 *) buffer = color; break;
		case 3:
			if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
			{
				buffer[0]=(color >> 16) & 0xff;
				buffer[1]=(color >> 8) & 0xff;
				buffer[2]=color & 0xff;
			}
			else
			{
				buffer[0]=color & 0xff;
				buffer[1]=(color >> 8) & 0xff;
				buffer[2]=(color >> 16) & 0xff;
			}
			break;

		case 4: *(Uint32 *) buffer = color; break;
	}
}

//! Devuelve un pixel de una superficie
Uint32 GetPixel(SDL_Surface *surface, int x, int y)
{
    if(x < 0 || y < 0 || x >= SCREEN_W || y >= SCREEN_H) return 0;

	int bpp = screen->format->BytesPerPixel;
	Uint8 * buffer = (Uint8 *) screen->pixels + y * screen->pitch + x*bpp;

    switch(bpp)
    {
        case 1: return *buffer;
        case 2: return *(Uint16 *) buffer;
        case 3:
                if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
                    return buffer[0] << 16 | buffer[1] << 8 | buffer[2];
                else
                    return buffer[0] | buffer[1] << 8 | buffer[2] << 16;

        case 4: return *(Uint32 *) buffer;
    }

    return 0;
}

//! Bloquea la superficie screen
void LockScreen()
{
    if (SDL_MUSTLOCK(screen))
        SDL_LockSurface(screen);
}

//! Desbloquea la superficie screen
void UnlockScreen()
{
    if (SDL_MUSTLOCK(screen))
        SDL_UnlockSurface(screen);
}

//! Limpia la superficie con un color
void Clear(SDL_Surface *surface, Uint32 color)
{
    SDL_Rect rect={0, 0, surface->w, surface->h};

    SDL_FillRect(surface, &rect, color);
}

//! Crea una superficie vacia de color negro
SDL_Surface *CreateSurface(int w, int h)
{
    const SDL_VideoInfo *vi=SDL_GetVideoInfo();

    SDL_Surface *surface=SDL_CreateRGBSurface(SDL_HWSURFACE, w, h,
                         vi->vfmt->BitsPerPixel,
                         vi->vfmt->Rmask, vi->vfmt->Gmask,
                         vi->vfmt->Bmask, vi->vfmt->Amask);

    Clear(surface, MakeColorRGB(0, 0, 0));

    return surface;
}

//!
void SetAlpha(SDL_Surface *surface, Uint8 alpha)
{
    SDL_SetAlpha(surface, SDL_SRCALPHA, alpha);
}

//! Realiza un blit desde una superficie a la pantalla
void Blit(SDL_Surface *surface)
{
    SDL_BlitSurface(surface, 0, screen, 0);
}

//! Realiza un blit entre dos superficies
void Blit(SDL_Surface *src, SDL_Surface *dst)
{
    SDL_BlitSurface(src, 0, dst, 0);
}

//! Realiza una page flipping
void Flip()
{
    SDL_Flip(screen);
}


//! Efecto Fade In
void FadeIn(int speed)
{
    int alpha=255;
    SDL_Surface *screen_cpy, *black_box;

    // Creamos una superficie negra
    black_box=CreateSurface(SCREEN_W, SCREEN_H);
    Clear(black_box, MakeColorRGB(0, 0, 0));

    // Guardamos una copia del framebuffer
    screen_cpy=CreateSurface(SCREEN_W, SCREEN_H);
    Blit(screen, screen_cpy);

    // Ciclo de Fade In
    while(1)
    {
        SDL_BlitSurface(screen_cpy, 0, screen, 0);
        SDL_SetAlpha(black_box, SDL_SRCALPHA, alpha);
        SDL_BlitSurface(black_box, 0, screen, 0);
        alpha-=speed;
        if(alpha < 0) break;
        SDL_Flip(screen);
        SDL_Delay(10);
    }

    // Eliminamos superficies
    SDL_FreeSurface(black_box);
    SDL_FreeSurface(screen_cpy);
}

//! Efecto Fade Out
void FadeOut(int speed)
{
    int alpha=0;
    SDL_Surface *screen_cpy, *black_box;

    // Creamos una superficie negra
    black_box=CreateSurface(SCREEN_W, SCREEN_H);
    Clear(black_box, MakeColorRGB(0, 0, 0));

    // Guardamos una copia del framebuffer
    screen_cpy=CreateSurface(SCREEN_W, SCREEN_H);
    Blit(screen, screen_cpy);

    // Ciclo de Fade Out
    while(1)
    {
        SDL_BlitSurface(screen_cpy, 0, screen, 0);
        SDL_SetAlpha(black_box, SDL_SRCALPHA, alpha);
        SDL_BlitSurface(black_box, 0, screen, 0);
        alpha+=speed;
        if(alpha > 255) break;
        SDL_Flip(screen);
        SDL_Delay(10);
    }

    // Eliminamos superficies
    SDL_FreeSurface(black_box);
    SDL_FreeSurface(screen_cpy);
}
