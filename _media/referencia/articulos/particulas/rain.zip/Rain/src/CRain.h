/*

    Archivo: CRain.h

    Descripcion: Clase que maneja simulacion de lluvia

    Autor:  Roberto Albornoz Figueroa
            ralbornoz@gmail.com
            http://www.blogrcaf.com

    Fecha: 25-marzo-2007

*/

#ifndef CRAIN_H
#define CRAIN_H

#include "CParticleSystem.h"
#include <list>

//! Direciones posibles para mover la lluvia
enum direction_rain_t { RAIN_LEFT, RAIN_RIGHT };

//! Clase CRain maneja simulacion de lluvia
class CRain: public CParticleSystem
{
public:

    CRain();
    ~CRain();

    void Init();
    void Update();
    void Draw();

    //! Setea el maximo de gotas de lluvia
    void SetMaxRaindrop(int max)
    {
        max_raindrop=max;
    }

    //! Setea la direccion de la lluvia
    void SetDir(direction_rain_t dir)
    {
        this->dir=dir;
    }

private:

    particle_t CreateRaindrop();

    std::list<particle_t> raindrop;         //!< Gotas de lluvia
    std::list<particle_t>::iterator it;     //!< Iterador de la lista de gotas de lluvia
    direction_rain_t dir;                   //!< Direccion de la lluvia
    int max_raindrop;                       //!< Numero maximo de gotas de lluvia
    SDL_Rect dim;                           //!< Dimensiones de una gota de lluvia
    SDL_Rect vel;                           //!< Velocidad constante de las gotas de lluvia
};

#endif
