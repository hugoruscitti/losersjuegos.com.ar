/*

    Archivo: CRain.cpp

    Descripcion: Clase que maneja simulacion de lluvia

    Autor:  Roberto Albornoz Figueroa
            ralbornoz@gmail.com
            http://www.blogrcaf.com

    Fecha: 25-marzo-2007

*/

#include "CRain.h"
#include <math.h>
#include <algorithm>

//! Constructor
CRain::CRain():CParticleSystem()
{
    max_raindrop=500;
    dir=RAIN_LEFT;
    dim.x=dim.y=12;
    vel.x=vel.y=12;
}

//! Destructor
CRain::~CRain()
{
}

//! Inicializa las gotas de lluvia
void CRain::Init()
{
    for(int i=0; i < max_raindrop; ++i)
    {
        particle_t sf=CreateRaindrop();
        raindrop.push_back(sf);
    }
}

//! Mueve las gotas de lluvia
void CRain::Update()
{
    // Recorremos todas las gotas de lluvia
    for(it=raindrop.begin(); it!=raindrop.end(); ++it)
    {
        it->pos.x+=it->vel.x;
        it->pos.y+=it->vel.y;

        if(it->pos.x <= area.x || it->pos.x >= area.x+area.w-1)
        {
            (*it)=CreateRaindrop();
        }
    }
}

//! Dibuja cada una de las gotas de lluvia
void CRain::Draw()
{
    // Recorremos todas las gotas de lluvia
    for(it=raindrop.begin(); it!=raindrop.end(); ++it)
    {
        // Dibujamos una gota de lluvia
        // Utilizamos la funcion lineRGBA de la biblioteca SDL_gfx

        if(dir==RAIN_LEFT)
            lineRGBA(screen, it->pos.x, it->pos.y, it->pos.x-dim.x, it->pos.y+dim.y, it->r, it->g, it->b, it->alpha);
        else if(dir==RAIN_RIGHT)
            lineRGBA(screen, it->pos.x, it->pos.y, it->pos.x+dim.x, it->pos.y+dim.y, it->r, it->g, it->b, it->alpha);
    }
}

//! Crea una gota de lluvia
particle_t CRain::CreateRaindrop()
{
    particle_t rd;


    // Posicion inicial
    rd.pos.x=random.GetInt(area.x-dim.x, area.x+area.w-1+dim.x);
    rd.pos.y=random.GetInt(area.y-dim.y, area.y+area.h-1+dim.y);

    rd.pos.x=random.GetInt(area.x, area.x+area.w-1);
    rd.pos.y=random.GetInt(area.y, area.y+area.h-1);

    // Velocidad y sentido de la lluvia
    rd.vel.x=vel.x;
    rd.vel.y=vel.y;

    if(dir==RAIN_LEFT) rd.vel.x*=-1;

    // Color de la gota de lluvia
    int c=160;
    rd.r=c;
    rd.g=c;
    rd.b=c;
    rd.alpha=random.GetInt(200, 255);

    return rd;
}

