/*

    Archivo: main.cpp

    Descripcion: Funciones principales del game loop.

    Autor:  Roberto Albornoz Figueroa
            ralbornoz@gmail.com
            http://www.blogrcaf.com

    Fecha: 25-marzo-2007

*/

#include "graph.h"
#include "CRain.h"

SDL_Event event;                    //!< Manejo de eventos
Uint8 *keyboard=NULL;               //!< Mapa del teclado
CRain rain;                         //!< Simulacion de lluvia
const int max_images=5;             //!< Numero de imagenes de fondo
SDL_Surface *image[max_images];     //!< Imagenes de fondo
SDL_Surface *fondo;                 //!< Puntero a la imagen de fondo actual

// Funciones del game loop
void GameLoop();
void Init();
int Input();
void Update();
void Draw();
void Quit();

// Funcion principal
int main(int argc, char **argv)
{
    Init();

    Draw();
    FadeIn();

    GameLoop();

    FadeOut();

    Quit();

    return 0;
}

//! Ciclo del juego
void GameLoop()
{
    int exit=0;

    Clear(screen);

    while(!exit)
    {
        exit=Input();
        Update();
        Draw();
        Flip();
        SDL_Delay(10);
    }
}

//! Inicializa el sistema
void Init()
{
    // Inicializa modo de video
    InitGraph(640, 480, 32, false);
    WindowTitle("Simulacion de lluvia by RCAF (C) 2007");

    // Cargamos imagenes de fondo
    char filename[256];
    for(int i=0; i < max_images; i++)
    {
        sprintf(filename, "fondo%d.jpg", i+1);
        image[i]=IMG_Load(filename);
    }

    // Imagen de fondo por defecto
    fondo=image[0];

    // Crea e inicializa la nieve
    rain.SetArea(0, 0, 640, 480);
    rain.SetMaxRaindrop(800);
    rain.SetDir(RAIN_LEFT);
    rain.Init();

    // Esconde el cursor del mouse
    SDL_ShowCursor(false);
}

//! Cierra el sistema
void Quit()
{
    // Liberamos memoria de superficies
    for(int i=0; i < max_images; i++)
        SDL_FreeSurface(image[i]);

    // Cierra biblioteca SDL
    QuitGraph();
}

//! Lectura de eventos y teclado
int Input()
{
    // Captura de Eventos
    while (SDL_PollEvent(&event))
    {
        if (event.type == SDL_QUIT)
            return 1;
    }

    // Estado del teclado
    keyboard=SDL_GetKeyState(0);

    // Con ESC cerramos la ventana
    if (keyboard[SDLK_ESCAPE]) return 1;

    // Tecla '1' cambia a fondo 1
    if (keyboard[SDLK_1]) fondo=image[0];

    // Tecla '2' cambia a fondo 2
    if (keyboard[SDLK_2]) fondo=image[1];

    // Tecla '3' cambia a fondo 3
    if (keyboard[SDLK_3]) fondo=image[2];

    // Tecla '4' cambia a fondo 1
    if (keyboard[SDLK_4]) fondo=image[3];

    // Tecla '5' cambia a fondo 2
    if (keyboard[SDLK_5]) fondo=image[4];

    // Lluvia hacia la izquierda
    if (keyboard[SDLK_LEFT]) rain.SetDir(RAIN_LEFT);

    // Lluvia hacia la derecha
    if (keyboard[SDLK_RIGHT]) rain.SetDir(RAIN_RIGHT);

    return 0;
}

//! Actualiza logica
void Update()
{
    // Mueve la lluvia
    rain.Update();
}

//! Dibujado de graficos
void Draw()
{
    // Dibujamos fondo
    if(fondo) Blit(fondo);
    else Clear(screen, MakeColorRGB(100, 100, 100));

    // Dibuja la lluvia
    rain.Draw();
}
