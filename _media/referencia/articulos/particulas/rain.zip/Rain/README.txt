Simulaci�n de lluvia
====================


Descripci�n
===========

Simulacion de lluvia utilizando la biblioteca SDL

Se cuenta con una clase abstracta denominada CParticleSystem la cual tiene las funciones
b�sicas para manejar un sistema de part�culas.

La clase CRain maneja una simulaci�n de lluvia simple que hereda de la clase CParticleSystem.

La clase CRandom maneja n�meros aleatorios (enteros o reales).

En graph.cpp se manejan las funciones b�sicas para inicializar un modo de video, mostrar pixeles, efectos fade in/out, etc.

En main.cpp se encuentran las funciones b�sicas para el manejo del game loop. 
Contiene la l�gica del programa.

Para cargar im�genes jpg se utiliz� la biblioteca SDL_image

Para dibujar l�neas se utiliz� la biblioteca SDL_gfx


Funcionamiento
==============

Para el correcto funcionamiento del programa se necesita disponer de 5 imagenes de 640x480 en formato jpg. 

En el directorio bin se incluyen 5 im�genes de prueba, que deben estar en el mismo directorio del ejecutable.

Dentro del programa, al presionar las teclas: 1, 2, 3, 4 o 5 podemos cambiar la imagen de fondo.

Con el cursor izquierdo/derecho cambiamos el sentido de la lluvia.


Compilaci�n de c�digo
=====================

Para una correcta compilaci�n del c�digo se necesita tener instalado en el sistema las bibliotecas:

SDL, SDL_image y SDL_gfx


Windows
-------

  gcc -o rain.exe graph.cpp CRain.cpp main.cpp -lmingw32 -lSDLmain -lSDL -lSDL_image -lSDL_gfx -mwindows


Linux
-----

  gcc -o rain graph.cpp CRain.cpp main.cpp `sdl-config --cflags --libs` -lSDL_image -lSDL_gfx


Autor
=====

Roberto Albornoz Figueroa
ralbornoz@gmail.com
http://www.blogrcaf.com

