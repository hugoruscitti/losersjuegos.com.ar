/*
* gskbyte, 2006
* gskbyte@gmail.com
* http://gskbyte.wordpress.com
*/

#ifndef _FRAME_H_
#define _FRAME_H_

using namespace std;

#include "SDL.h"
#include "SDL_image.h"
#include <iostream>

class Frame{
    private:
    
        SDL_Surface * img;
    
    public:
        Frame();
        Frame(const string & ruta);
        Frame(const string & ruta, Uint8, Uint8 g, Uint8 b);
        Frame(int ancho, int alto, Uint8=0, Uint8 g=0, Uint8 b=0); // negro por defecto
        Frame (const Frame & orig);
        Frame (SDL_Surface * src);
        ~Frame();
    
        Frame & operator=(const Frame & orig);
        Frame & operator=(SDL_Surface * src);
        
        bool Cargar(const string & ruta);
        void Liberar();
        
        void PonerPixel(int x, int y, const SDL_Color & color);
        SDL_Color ObtenerPixel(int x, int y);
        
        bool DefinirTransp(Uint8 r, Uint8 g, Uint8 b);
        bool QuitarTansp();
        bool Translucidez(Uint8 alpha);
        void Rellenar(SDL_Color color);
        
        bool CrearVentana(Uint16 ancho, Uint16 alto, int bpp, string titulo,
                          Uint32 flags=SDL_HWSURFACE|SDL_DOUBLEBUF|SDL_RLEACCEL|SDL_HWACCEL|SDL_FULLSCREEN);
    
        int Ancho() const;
        int Alto() const;
        bool Vacio() const;
    
        void Dibujar (SDL_Surface * scr, int x=0, int y=0) const;
        void Dibujar (Frame & scr, int x=0, int y=0) const;
        void Actualizar();
        
        bool GuardarBMP (string ruta) const;
};

Frame::Frame()
{
    img=NULL;
}

Frame::Frame(const string & ruta)
{
    Cargar(ruta);
}

Frame::Frame(const string & ruta, Uint8 r, Uint8 g, Uint8 b)
{
    Cargar(ruta);
    DefinirTransp(r,g,b);
}

Frame::Frame(int ancho, int alto, Uint8 r, Uint8 g, Uint8 b)
{
    img = SDL_CreateRGBSurface(SDL_HWSURFACE|SDL_RLEACCEL, ancho, alto,
                               24, r, g, b, 0);
}

Frame::Frame (const Frame & orig)
{
    this->img=NULL;
    *this=orig.img; // uso el operador = para ahorrar código
}

Frame::Frame (SDL_Surface * src)
{
    this->img=NULL;
    *this=src;
}

Frame::~Frame()
{
    Liberar();
}

Frame & Frame::operator=(const Frame & orig)
{
    *this=orig.img;
    return *this;
}

inline Frame & Frame::operator=(SDL_Surface * src)
{
    if(src!=NULL){
        if(this->img!=NULL) this->Liberar(); // No sé si este paso es necesario
        this->img=SDL_DisplayFormatAlpha(src);
        if(this->img==NULL){
            cout << endl << "Fallo al copiar superficies\n" << endl;
        }
    }
    return *this;
}

bool Frame::Cargar(const string & ruta)
{
  bool exito= true;
    img=IMG_Load(ruta.c_str());
    if(img!=0)
        cout << "Imagen cargada: " << ruta << "\n";
    else
    {
        cout << "Error al cargar la imagen " << ruta << " .\n";
        exito = false;
    }
    return exito;
}

inline void Frame::Liberar()
{
    if(this->img!=NULL){
        SDL_FreeSurface(img);
        img=NULL;
    }
}

void Frame::PonerPixel(int x, int y, const SDL_Color & color)
{
    // Convertimos color
    Uint32 col=SDL_MapRGB(this->img->format, color.r, color.g, color.b);
    // Determinamos posición de inicio
    char *buffer=(char*) this->img->pixels;
    // Calculamos offset para y
    buffer+=this->img->pitch*y;
    // Calculamos offset para x
    buffer+=this->img->format->BytesPerPixel*x;
    // Copiamos el pixel
    memcpy(buffer, &col, this->img->format->BytesPerPixel);
}

SDL_Color Frame::ObtenerPixel(int x, int y)
{
  SDL_Color color;
  Uint32 col;
  // Determinamos posición de inicio
  char *buffer=(char *) this->img->pixels;
  // Calculamos offset para y
  buffer+=this->img->pitch*y;
  // Calculamos offset para x
  buffer+=this->img->format->BytesPerPixel*x;
  // Obtenemos el pixel
  memcpy(&col, buffer, this->img->format->BytesPerPixel);
  // Descomponemos el color
  SDL_GetRGB(col, this->img->format, &color.r, &color.g, &color.b);
  // Devolvemos el color
  return color;
}

bool Frame::DefinirTransp(Uint8 r, Uint8 g, Uint8 b)
{
    int error;
    bool exito=true;
    if(img!=0)
    {
        error=SDL_SetColorKey(this->img, SDL_SRCCOLORKEY|SDL_RLEACCEL,
                              SDL_MapRGB(this->img->format, r,g,b));
        if(error==-1)
        {
            cout << "Error al definir la transparencia\n";
            exito =false;
        }
    }
    else
    {
        cout << "No se ha cargado la imagen, así que no puede definirse"
                << "\nuna transparencia\n";
        exito = false;
    }
    return exito;
}

bool Frame::QuitarTansp()
{
    int error;
    if(img!=0){
        error=SDL_SetColorKey(this->img, 0, SDL_MapRGB(this->img->format, 0,0,0));
        if(error==-1)
        {
            cout << "Error al quitar la transparencia\n";
            return false;
        }
        return true;
    }
    else{
        cout << "No se ha cargado la imagen, no puede quitarse"
                << "\nla transparencia\n";
        return false;
    }
}

bool Frame::Translucidez(Uint8 alpha)
{
    SDL_SetAlpha(img,SDL_RLEACCEL|SDL_SRCALPHA, alpha);
    if(img!=NULL) // si todo va bien
        return true;
    else // si no
        return false;
}

inline void Frame::Rellenar(SDL_Color c)
{
    if(this->img!=NULL)
        SDL_FillRect(this->img, NULL, SDL_MapRGB(this->img->format, c.r, c.g, c.b));
}

bool Frame::CrearVentana(Uint16 ancho, Uint16 alto, int bpp, string titulo, Uint32 flags)
{
    bool exito=true;
    //if(this->img==NULL) // el frame debe de estar vacío para poder crear una ventana
    //{
      if(ancho>0 && alto>0 && ancho<=2048 && alto<=1536) // Tamaños máximo y mínimo
        {
            if (bpp!=1 || bpp!=2 || bpp!=4 || bpp!=8 || bpp!=16 || bpp!=24 || bpp!=32)
                bpp=32; // Los bpp deben ser potencia de 2
            
            this->img=SDL_SetVideoMode(ancho, alto, bpp, flags);
            if (this->img!=NULL) //Si no hay error
            {
                SDL_WM_SetCaption( titulo.c_str(), titulo.c_str());
            }
            else
            {
                cerr << "Error al crear la ventana: \n";
                cerr << SDL_GetError() << endl;
                exito=false;
            }
            
        }
        else
        {
            cout << "Tamaño de ventana no válido. Valores introducidos: " << ancho << " x " << alto << " .\n";
            cout << "No se creó la ventana.\n";
        }
    /*}
    else
    {
        cout << "No se puede (porque no se debe) crear una ventana en una\n"
            << "superficie que ya está ocupada.\n";
        exito = false;
    }
    */
    return exito;
}

inline int Frame::Ancho()  const
{
    return img->w;
}

inline int Frame::Alto()  const
{
    return img->h;
}

bool Frame::Vacio() const
{
    return img==NULL;
}

inline void Frame::Dibujar(SDL_Surface * scr, int x, int y) const
{
    SDL_Rect aux={x,y,0,0};
    if(this->img!=0 && scr!=0){
        SDL_BlitSurface(this->img,NULL,scr,&aux);
    }
}

inline void Frame::Dibujar (Frame & scr, int x, int y) const
{
    SDL_Rect aux={x,y,0,0};
    if(this->img!=0 && scr.img!=0){
        SDL_BlitSurface(this->img,NULL,scr.img,&aux);
    }
}

inline void Frame::Actualizar()
{
    SDL_Flip(this->img);
}

bool Frame::GuardarBMP (string ruta) const
{
    bool exito=true;
    int n=SDL_SaveBMP(this->img, ruta.c_str());
    if(n==0)
        cout << "Captura guardada con éxito en \'" << ruta << "\'.\n";
    else
    {
        cerr << "No se ha podido guardar el frame en " << ruta << " .\n";
        exito=false;
    }
    return exito;
}


#endif /* _FRAME_H_ */

