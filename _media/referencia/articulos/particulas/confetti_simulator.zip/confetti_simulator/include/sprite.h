/*
* gskbyte, 2006
* gskbyte@gmail.com
* http://gskbyte.wordpress.com
*/

#ifndef _SPRITE_H_
#define _SPRITE_H_

#include "frame.h"
#include <vector>
#include <cmath>

class Sprite{
    private:
    
        vector<Frame> sprite;
        int posx;
        int posy;
        int frame_sel;
    
        /* Detección de colisiones */
        vector <SDL_Rect> areas;
    /* Indica si se han definido áreas manualmente.
        Por defecto habrá un área igual al tamaño del frame primero
        Esto sirve para simplificar la función de colisión */
        bool areas_definidas;
    
    public:
    
        Sprite();
        Sprite(int nframes);
        Sprite(const string & ruta);
        
        //~Sprite();
        //Sprite(const Sprite & orig);
        //Sprite & operator=(const Sprite & orig);
        void Copiar(const Sprite & orig);
        
        void AnadirFrame(const Frame f);
        int ObtenerFrameSeleccionado() const;
        void SelFrame(int i);
    
        void operator ++ ();
        void operator -- ();
    
        void AnadirArea(Sint16 x, Sint16 y, Uint16 ancho, Uint16 alto);
        void AnadirArea(SDL_Rect a);
        void BorrarAreas();
        int NumeroAreas() const;
        SDL_Rect ObtenerArea(int i) const;
    
        // Movimiento absoluto
        void Mover(int x, int y);
        // Movimiento relativo
        void Desplazar(int x, int y);
    
        int ObtenerX() const;
        int ObtenerY() const;
    
        int Ancho() const; // Estas funcones devuelven la altura y la anchura
        int Alto() const; // del frame seleccionado (lo que indica frame_sel)
    
        int NFrames() const;
    
        void Dibujar(Frame & sur) const;
        bool Colision(const Sprite & sp) const;
    // Distancia euclídea: sqrt((x1-x2)²+(y1-y2)²)
    // Se calcula desde las esquiinas superiores izquierdas
        float Distancia(const Sprite & sp) const;
    
};

Sprite::Sprite()
{
        posx=posy=frame_sel=0;
        areas_definidas=false;
}
    
Sprite::Sprite(int nframes)
{
    posx=posy=frame_sel=0;
    areas_definidas=false;
    if (nframes>0)
        sprite.reserve(nframes+1);
}
    
Sprite::Sprite(const string & ruta)
{
    posx=posy=frame_sel=0;
    areas_definidas=false;
    Frame aux(ruta);
    AnadirFrame(aux);
}

void Sprite::Copiar(const Sprite & orig)
{
    this->sprite=orig.sprite;
    this->posx=orig.posx;
    this->posy=orig.posy;
    this->frame_sel=orig.frame_sel;
    this->areas=orig.areas;
    this->areas_definidas=orig.areas_definidas;
}

void Sprite::AnadirFrame(const Frame f)
{
    // Antes que nada, añado el frame.
    sprite.push_back(f);
    // Si sólo hay uno, significa que acabo de añadirlo, y si no hay áreas definidas,
    // hay que definir el área por defecto.
    if(areas_definidas==false && sprite.size()==1)
    {
        SDL_Rect rect;
        rect.x = rect.y = 0;
        rect.w=sprite[0].Ancho();
        rect.h=sprite[0].Alto();
    }
}

int Sprite::ObtenerFrameSeleccionado() const
{
    return frame_sel;
}

inline void Sprite::SelFrame(int i)
{
    frame_sel=i%sprite.size();
}

inline void Sprite::operator ++ ()
{
    if(sprite.size()>1)
    {
        frame_sel++;
        frame_sel%=sprite.size();
    }
}

inline void Sprite::operator -- ()
{
    if(sprite.size()>1)
    {
        if (frame_sel==0) frame_sel=sprite.size()-1;
        else frame_sel--;
    }
}

void Sprite::AnadirArea(Sint16 x, Sint16 y, Uint16 ancho, Uint16 alto)
{
    SDL_Rect aux;
    aux.x=x, aux.y=y;
    aux.w=ancho, aux.h=alto;
    
    AnadirArea(aux);
}

void Sprite::AnadirArea(SDL_Rect a)
{
    if (areas_definidas==false)
    {
        areas_definidas=true;
        areas.clear();
    }
    areas.push_back(a);
}


void Sprite::BorrarAreas()
{
    areas.clear();
    areas_definidas=false;
    if (sprite.size()>0)
    {
        SDL_Rect aux;
        aux.x = aux.y = 0;
        aux.w = sprite[0].Ancho();
        aux.h = sprite[0].Alto();
        areas.push_back(aux);
    }
}

int Sprite::NumeroAreas() const
{
    return areas.size();
}

SDL_Rect Sprite::ObtenerArea(int i) const
{
    if (i<0) 
        i=0;
    else if(i>=areas.size())
        i=areas.size()-1;
    return areas[i];
}

inline void Sprite::Mover(int x,int y)
{
    posx=x, posy=y;
}

inline void Sprite::Desplazar(int x, int y)
{
    posx+=x, posy+=y;
}

inline int Sprite::ObtenerX() const
{
    return posx;
}
inline int Sprite::ObtenerY() const
{
    return posy;
}

inline int Sprite::Ancho() const
{
    return sprite[frame_sel].Ancho();
}

inline int Sprite::Alto() const
{
    return sprite[frame_sel].Alto();
}

int Sprite::NFrames() const{
    return sprite.size();
}

inline void Sprite::Dibujar(Frame & sur) const
{
    if (sprite.size()>0)
        sprite[frame_sel].Dibujar(sur,posx,posy);
}

// ¿Esto no debería hacerse sólo con el área actual de ambos sprites?
// Usando frame_sel, por supuesto
bool Sprite::Colision(const Sprite & sp) const
{
    
    int w1, h1, w2, h2, x1, y1, x2, y2;
    
    // Cojo cada área de this
    for (int i=0; i<areas.size(); ++i)
    {
        x1= ObtenerX() + areas[i].x;
        y1= ObtenerY() + areas[i].y;
        w1= areas[i].w;
        h1= areas[i].h;
         // Y la comparo con todas las de sp
        for (int j=0; j<sp.areas.size(); ++j)
        {
            x2= sp.ObtenerX() + sp.areas[j].x;
            y2= sp.ObtenerY() + sp.areas[j].y;
            w2= sp.areas[j].w;
            h2= sp.areas[j].h;
            if (((x1+w1)>x2) && ((y1+h1)>y2) && ((x2+w2)>x1) && ((y2+h2)>y1))
                return true;
        }
    }
    return false;
}

inline float Sprite::Distancia(const Sprite & sp) const
{
    // Distancia euclídea: sqrt((x1-x2)²+(y1-y2)²)
    return sqrt((posx-sp.posx)*(posx-sp.posx) + (posy-sp.posy)*(posy-sp.posy));
}



#endif /* _SPRITE_H_ */
