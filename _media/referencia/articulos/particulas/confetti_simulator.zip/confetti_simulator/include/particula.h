#include <iostream>
#include <vector>
#include <cmath>
#include <cassert>
#include "frame.h"

using namespace std;

struct Coord2D
{
    int x, y;
};

class Particula
{
    private:
        Frame particula;
        Coord2D pos;
        Coord2D dir;
        Coord2D acel; // si es negativo frena, obviamente
        bool cayendo;
        
    public:
        // Particula()
        Particula(const Frame & part, int x, int y, int dx, int dy, int acx, int acy)
        {
            pos.x=x, pos.y=y;
            dir.x=dx, dir.y=dy;
            acel.x=acx, acel.y=acy;
            particula=part;
        }
        //~Particula
        // constructor de copias
        // operador =
        Particula(string ruta_archivo)
        {
            if( this->particula.Cargar(ruta_archivo) == false)
            {
                cout << "\n - Error al cargar archivo de partícula: " << ruta_archivo <<"\n\n";
                exit(-1);
            }
        }
        
        inline void Mover(int x, int y)
        {
            this->pos.x=x, this->pos.y=y;
        }
        
        inline void Desplazar(int x, int y)
        {
            this->pos.x+=x, this->pos.y+=y;
        }
        
        inline void CambiarDireccion(int dx, int dy)
        {
            this->dir.x=dx, this->dir.y=dy;
        }
        
        inline void CambiarAceleracion(int ax, int ay)
        {
            this->acel.x=ax, this->acel.y=ay;
        }
        
        inline int X()
        {
            return pos.x;
        }
        
        inline int Y()
        {
            return pos.y;
        }
        
        inline Coord2D Direccion()
        {
            return dir;
        }
        
        inline void Caer(bool c=true)
        {
            this->cayendo=c;
        }
        
        inline bool Cayendo()
        {
            return cayendo;
        }
        
        inline void Dibujar(Frame & img, int cx, int cy)
        {
            particula.Dibujar(img, cx, cy);
        }
};

class Confeti
{
    private:
        vector<Particula> confeti;
        bool cayendo;
        Coord2D pos_def; // coordenadas por defecto
        int puntero_part;
    public:
        // Confeti();
        Confeti(const Frame & part, int num_particulas, int dx, int dy, int acx, int acy)
        {
            assert(num_particulas>0);
            confeti.reserve(num_particulas);
            cout << 1 << endl;
            Particula p_aux(part, pos_def.x, pos_def.y, dx, dy, acx, acy);
            cout << 1.25 << endl;
            for (int i=0; i<num_particulas; ++i)
            {
                confeti.push_back(p_aux);
            }
            cout << 1.5 << endl;
        }
        //~Confeti();
        //Confeti(const Confeti & orig);
        //Confeti & operator=(const Confeti & orig);
        inline void Caer(Frame & ventana, const Frame & fondo, int soltar_max)
        {
            Coord2D aux;
            soltar_max=random()%soltar_max; // perfectamente omitible
        
            for(int i=0; i<soltar_max; ++i)
            {
                if(puntero_part==confeti.size())
                    puntero_part=0; // para dar la vuelta
            
                if(confeti[puntero_part].Cayendo()==false)
                    confeti[puntero_part].Caer(true);
        
                ++puntero_part;
            }
        
            // Pinto el fondo
            fondo.Dibujar(ventana,0,0);
        
            // Dependiendo de la velocidad de caída y tal, así se desplazan las partículas
            // Y si una partícula ha llegado al final, la reinicio
            for(int i=0; i<confeti.size(); ++i)
            {
                // Eliminación de confeti si se sale de la ventana
                if ( confeti[i].X()>ventana.Ancho() || confeti[i].Y()>ventana.Alto() )
                {
                    confeti[i].Caer(false);
                    confeti[i].Mover(pos_def.x, pos_def.y);
                }
        
                continue; // Tiene sentido ,pero es fullerillo, no?
        
                // Movimiento de confeti
                if ( confeti[i].Cayendo() )
                {
                    aux=confeti[i].Direccion();
                    confeti[i].Desplazar(random()%aux.x, random()%aux.y);
                    confeti[i].Dibujar(ventana, confeti[i].X(), confeti[i].Y());
                }
            
                // Dibujo de confeti
                // confeti[i].Dibujar(ventana, confeti[i].X(), confeti[i].Y());
            }
        }
        
        void Reiniciar()
        {
            for (int i=0; i<confeti.size(); ++i)
            {
                confeti[i].Mover(pos_def.x, pos_def.y);
                confeti[i].Caer(false);
            }
        }
        
        void PonerPosicionInicial (int x, int y)
        {
            this->pos_def.x=x;
            this->pos_def.y=y;
        }
        
        void PonerDireccionCaida (int dx, int dy)
        {
            for (int i=0; i<confeti.size(); ++i)
            {
                confeti[i].CambiarDireccion(dx, dy);
            }
        }
        
};

