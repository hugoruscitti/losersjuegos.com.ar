/*
Primera prueba de partículas, versión 0.0000000000000000000000000000000000000000000049
-----------------------------

Disculpad el desorden de esto, cosas de las prisas y no prepararlas antes. Aun así, funciona :).

Grupo SDL Hispano

Miércoles 21 de febrero de 2007
http://gskbyte.net
*/

#include <iostream>
#include <vector>
#include <cmath>
#include "frame.h"

#define NUMPARTICULAS 5000
#define ANCHO 640
#define ALTO 480

// Caída en diagonal a la derecha
#define MAX_MOVIMIENTO_VERT 10
#define MAX_MOVIMIENTO_HORIZ 10

using namespace std;

class Particula
{
    public:
        Frame part;
        int x, y;
        
        /// Poner velocidades de caída máximas y mínimas
        int dir_x, dir_y;
        int acel_x, acel_y; // si es negativo frena, obviamente
        bool cayendo;
        
        // ¡Esto sólo vale para el confeti!
        void Iniciar()
        {
            // No aparece, se pone arriba del todo
            y=-1;
            // La sitúo a voleo arriba del todo
            x=random()%200;
            // Por ahora, sólo caen hacia abajo
            dir_x=random()%MAX_MOVIMIENTO_HORIZ + 1; // Si no pongo el +1 hay división por cero en los módulos (fácil de areglar)
            dir_y=random()%MAX_MOVIMIENTO_VERT + 1; // no puede ser 0!! (si no, no caen)
        }
};

class Viento
{
    public:
    // private: hacer funciones para ocultar esto!!!!
        int x, y;
        float acel_x, acel_y;
        float fuerza; // Fuerza obtenida al estar 10 px más lejos
    public:
        Viento()
        {
            x=y=0;
            acel_x=acel_y=0;
            fuerza=0;
        }
        
        
        void TomarPosicionRaton()
        {
            SDL_Event evento;
            if(SDL_PollEvent(&evento))
            {
                if (evento.type==SDL_MOUSEMOTION)
                {
                    x=evento.motion.x;
                    y=evento.motion.y;
                }
            }
        }
        
        void CambiarPosicion(int posx, int posy)
        {
            x=posx, y=posy;
        }
        
        void CambiarAceleracion(float ac_x, float ac_y)
        {
            acel_x=ac_x, acel_y=ac_y;
        }
        
        void CambiarFuerza(float f)
        {
            fuerza=f;
        }
        
        float Distancia(const Particula & p)
        {
            float x2, y2;
            x2= (this->x - p.x) * (this->x - p.x);
            y2= (this->y - p.y) * (this->y - p.y);
            return sqrt(x2+y2);
        }
};

/* VARIABLES GLOBALES
---------------------
*/
Frame ventana;

/// FUNCIÓN CONFETTI: salen partículas desde una esquina (configurable), y se esparcen. ¡Confeti!
// Entradas: un vector de partículas de confeti y el fondo, ya cargados
// Entradas opcionales:
    // maxpart - indica el máximo de partículas que se sueltan por iteración
    // pausa - indica la pausa entre iteraciones del bucle, en milisegundos
void Confeti(vector<Particula> & confeti, const Frame & fondo, int maxpart=50, int pausa=30)
{
    bool salir=false;
    int num_caidas, puntero=0;
    SDL_Event evento;
    Viento huracan;
    
    huracan.CambiarAceleracion(-300, -300);
    huracan.CambiarPosicion(200,200);
    huracan.CambiarFuerza(0.95);
    
    // Esto podría estar dentro de la función Iniciar() de las partículas
    // Pero así me ahorro una operación en cada pasada del bucle.
    for(int i=0; i<NUMPARTICULAS; ++i)
    {
        confeti[i].cayendo=false;
    }
    
    while (!salir)
    {
        // Cojo unas cuantas partículas (secuencialmente en el vector) 
        // y las dejo caer (poniendo la variable "cayendo" a true)
        num_caidas=random()%maxpart;
        
        for(int i=0; i<num_caidas; ++i)
        {
            if(puntero==NUMPARTICULAS) puntero=0; // para dar la vuelta
            
            if(confeti[puntero].cayendo==false)
            {
                confeti[puntero].Iniciar();
                confeti[puntero].cayendo=true;
            }
            ++puntero;
        }
        
        // Tomo la posición del ratón
        huracan.TomarPosicionRaton();
        
        // Un retrasillo pa que esto no vaya follao
        SDL_Delay(pausa);
        
        // Pinto el fondo
        fondo.Dibujar(ventana,0,0);
        
        // Dependiendo de la velocidad de caída y tal, así se desplazan las partículas
        // Y si una partícula ha llegado al final, la reinicio
        for(int i=0; i<NUMPARTICULAS; ++i)
        {
            // Eliminación de confeti si se sale de la ventana
            if ( confeti[i].y>ALTO || confeti[i].x>ANCHO )
            {
                confeti[i].cayendo=false;
            }
            
            // Movimiento de confeti
            if ( confeti[i].cayendo==true )
            {
                float dist=huracan.Distancia(confeti[i]);
                confeti[i].y += random()%confeti[i].dir_y + (huracan.acel_y / dist);
                confeti[i].x += random()%confeti[i].dir_x + (huracan.acel_x / dist);
            }
            
            // Dibujo de confeti
            confeti[i].part.Dibujar(ventana, confeti[i].x, confeti[i].y);
        }
        while(SDL_PollEvent(&evento))
        {
            if(evento.type==SDL_KEYDOWN || evento.type==SDL_QUIT)
                salir=true;
        }
        ventana.Actualizar();
    }
}


/*
void Explosion(vector<Particula> & metralla, const Frame & fondo, int posx=ANCHO/2, posy=ALTO/2, int acelx=100, acely=100)
{
    bool salir=false;
    int puntero=0;
    SDL_Event evento;
    
    // Inicio de las partículas, todas en un punto
    for(int i=0; i<NUMPARTICULAS; ++i)
    {
        metralla[i].cayendo=false;
        metralla[i].x=posx;
        metralla[i].y=posy;
        // Cada partícula tendrá una dirección a voleo
        metralla[i].dirx=random()%MAX_MOVIMIENTO_VERT
        
        // Ídem para la aceleración
    }
    
    
}
*/

int main()
{
    Frame fondo;
    fondo.Cargar("fondo640.jpg");
    Particula mota;
    
    mota.part.Cargar("particula.png");
    
    vector <Particula> copos;
    
    // Inicio de la SDL
    if (SDL_Init(SDL_INIT_VIDEO|SDL_INIT_TIMER) < 0){
        cerr << "\nFALLO. No puedo iniciar la SDL\n\n" << SDL_GetError();
        exit(1);
    }
    
    // Establezco las propiedades de la ventana
    ventana.CrearVentana(ANCHO,ALTO,16,"Confetti simulator 2007",
                         SDL_HWSURFACE|SDL_DOUBLEBUF|SDL_RLEACCEL|SDL_HWACCEL);
    
    copos.reserve(NUMPARTICULAS);
    // Pongo la imagen de los copos
    for (int i=0; i<NUMPARTICULAS; ++i)
        copos.push_back(mota);
    
    // Y ahora mi cutre-función
    Confeti(copos, fondo);
    
}

