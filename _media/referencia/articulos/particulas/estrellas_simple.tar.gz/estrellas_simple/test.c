#include <stdlib.h>
#include <time.h>
#include "SDL.h"

#define PARTICLES_MAX 260

SDL_Surface * screen;

struct particle
{
    int x;
    int y;
    Uint32 color;
};


SDL_Surface * init (void);
void particles_init(struct particle * data, int max);
void particles_erase(struct particle * data, int max);
void particles_draw(struct particle * data, int max);
void particles_update(struct particle * data, int max);
void put_pixel(SDL_Surface *_ima, int x, int y, Uint32 pixel);
void lock_screen(void);
void unlock_screen(void);
void init_random(void);
int rand_from_to(int from, int to);


int main (int argc, char * argv [])
{
    struct particle particles[PARTICLES_MAX];
    int quit = 0;
    SDL_Event event;

    screen = init();
    init_random();
    particles_init(particles, PARTICLES_MAX);

    while (! quit)
    {
        while (SDL_PollEvent(&event))
        {
            if (event.type == SDL_QUIT)
                quit = 1;
        }

        particles_erase(particles, PARTICLES_MAX);
        particles_update(particles, PARTICLES_MAX);
        particles_draw(particles, PARTICLES_MAX);
        SDL_Flip(screen);
        SDL_Delay(1);
    }
    
    SDL_Quit();
    return 0;
}


SDL_Surface * init (void)
{
    SDL_Surface * tmp;

    if (SDL_Init(SDL_INIT_VIDEO) == 1)
    {
        printf(SDL_GetError());
        return NULL;
    }

    tmp = SDL_SetVideoMode(320, 240, 16, 0);

    if (! tmp)
    {
        printf(SDL_GetError());
        return NULL;
    }

    SDL_WM_SetCaption("Titulo", NULL);

    return tmp;
}


void particles_init(struct particle * data, int max)
{
    int i;
    int c;

    for (i = 0; i < max; i ++)
    {
        c = rand_from_to(100, 255);

        data[i].x = rand_from_to(0, 320);
        data[i].y = rand_from_to(0, 240);
        data[i].color = SDL_MapRGB(screen->format, c, c, c);
    }
}

void particles_erase(struct particle * data, int max)
{
    int i;
    Uint32 black=0;

    lock_screen();

    for (i = 0; i < max; i ++)
        put_pixel(screen, data[i].x, data[i].y, black);

    unlock_screen();
}


void particles_draw(struct particle * data, int max)
{
    int i;

    lock_screen();

    for (i = 0; i < max; i ++)
        put_pixel(screen, data[i].x, data[i].y, data[i].color);

    unlock_screen();
}


void particles_update(struct particle * data, int max)
{
    int i;

    for (i = 0; i < max; i ++)
    {
        data[i].x ++;
        data[i].y ++;

        if (data[i].x >= 320)
            data[i].x = 0;

        if (data[i].y >= 240)
            data[i].y = 0;
    }
}


void put_pixel(SDL_Surface *ima, int x, int y, Uint32 pixel)
{
	int bpp = ima->format->BytesPerPixel;
	Uint8 *p = (Uint8 *)ima->pixels + y * ima->pitch + x*bpp;

	switch (bpp)
	{
		case 1:
			*p = pixel;
			break;
			
		case 2:
			*(Uint16 *)p = pixel;
			break;
			
		case 3:
			if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
			{
				p[0]=(pixel >> 16) & 0xff;
				p[1]=(pixel >> 8) & 0xff;
				p[2]=pixel & 0xff;
			}
			else
			{
				p[0]=pixel & 0xff;
				p[1]=(pixel >> 8) & 0xff;
				p[2]=(pixel >> 16) & 0xff;
			}
			break;
			
		case 4:
			*(Uint32 *) p = pixel;
			break;
	}
}


void lock_screen(void)
{
    if (SDL_MUSTLOCK(screen))
        SDL_LockSurface(screen);
}


void unlock_screen(void)
{
    if (SDL_MUSTLOCK(screen))
        SDL_UnlockSurface(screen);
}


void init_random(void)
{
    srand(time(NULL));
}


int rand_from_to(int from, int to)
{
    return from + (int) ((float) (to-from) * (rand() / (RAND_MAX + 1.0))); 
}
