/*
 * Mini ejemplo : fuentes
 * Copyright (C) 2005 Hugo Ruscitti
 *
 * Este programa es software libre. Puede redistribuirlo y/o 
 * modificarlo bajo los t�rminos de la Licencia P�blica General	de 
 * GNU seg�n es publicada por la Free Software Foundation, bien de 
 * la versi�n 2 de dicha Licencia o bien (seg�n su elecci�n) de 
 * cualquier versi�n posterior.
 * 
 * Este programa se distribuye con la esperanza de que sea �til, pero
 * SIN NINGUNA GARANT�A, incluso sin la garant�a MERCANTIL impl�cita 
 * o sin garantizar la CONVENIENCIA PARA UN PROP�SITO PARTICULAR. 
 * V�ase la Licencia P�blica General de GNU para m�s detalles.
 * 
 * Deber�a haber recibido una copia de la Licencia P�blica General 
 * junto con este programa. Si no ha sido as�, escriba a la Free 
 * Software Foundation, Inc., en 675 Mass Ave, Cambridge, 
 * MA 02139, EEUU.
 */

#include "SDL.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

void esperar (void)
{
	SDL_Event evento;

	while (SDL_WaitEvent (&evento))
	{
		if (evento.type == SDL_QUIT || evento.type == SDL_KEYDOWN)
			return;
	};
}


SDL_Surface * iniciar_sdl (const char * titulo)
{
	SDL_Surface * screen;

	if (SDL_Init (SDL_INIT_VIDEO))
	{
		printf ("error: %s\n", SDL_GetError ());
		return NULL;
	}

	screen = SDL_SetVideoMode (320, 240, 16, SDL_HWSURFACE);
	
	if (screen == NULL)
	{
		printf ("error: %s\n", SDL_GetError ());
		return NULL;
	}

	SDL_FillRect (screen, NULL, SDL_MapRGB (screen->format, 200, 200, 200));
	SDL_WM_SetCaption (titulo, NULL);

	return screen;
}

int imprimir_letra (SDL_Surface * dst, SDL_Surface * ima, int x, int y, \
		char letra)
{
	int indice = (int) letra; /* c�digo ASCII de la letra */
	SDL_Rect srcrect;
	SDL_Rect dstrect = {x, y, 0, 0};
	int fil = 16;
	int col = 16;

	if (indice > fil * col || indice < 0)
	{
		printf("error, no se puede acceder al indice %d\n", indice);
		return 0;
	}

	srcrect.w = ima->w / col;
	srcrect.h = ima->h / fil;
	srcrect.x = (indice % col) * srcrect.w;
	srcrect.y = (indice / col) * srcrect.h;

	SDL_BlitSurface(ima, &srcrect, dst, &dstrect);
	return srcrect.w; /* se retorna el ancho del caracter impreso */
}

void imprimir_palabra (SDL_Surface * screen, SDL_Surface * ima, int x, int y, \
		char * cadena)
{
	int i;
	int dx = x; /* destino de impresi�n para el caracter actual */

	for (i = 0; cadena [i]; i ++)
	{
		dx += imprimir_letra (screen, ima, dx, y, cadena [i]);
	}
}

int main (int argc, char * argv [])
{
	SDL_Surface * screen;
	SDL_Surface * ima;

	screen = iniciar_sdl ("Fuente soluci�n 1");

	if (screen == NULL)
		return 1;
	
	ima = SDL_LoadBMP ("supertux_font.bmp");
	
	if (ima == NULL)
		return 1;

	SDL_SetColorKey (ima, SDL_SRCCOLORKEY, \
			SDL_MapRGB (ima->format, 200, 200, 200));
	
	imprimir_palabra (screen, ima, 5, 50, "Iniciar nuevo juego");
	imprimir_palabra (screen, ima, 80, 100, "Otro texto");
	
	SDL_Flip (screen);
	esperar ();
	
	SDL_FreeSurface (ima);
	SDL_Quit ();
	return 0;
}
