# -*- coding: utf-8 -*-
import pygame

screen = pygame.display.set_mode((640, 480))        # genera la ventana
pygame.display.set_caption("Monkey Hunter")         # define un título

# crea dos objetos "Surface".
#
# nota: las funciones "convert" y "convert_alpha" convierten la superficie
#       creada por "load" a un formato de color que permite imprimirlas mucho
#       mas rápido sobre la pantalla.
fondo = pygame.image.load("escenario.jpg").convert()
logotipo = pygame.image.load("logo.png").convert_alpha()


# imprime ambas "Surface" sobre la ventana, e invoca a "flip" para
# actualizar la pantalla principal. Mostrando los cambios.
screen.blit(fondo, (0, 0))
screen.blit(logotipo, (570, 390))


# se muestran lo cambios en pantalla
pygame.display.flip()


# Detiene el programa hasta que surja el evento QUIT. Esto es: que el
# usuario pulse el botón "cerrar" de la ventana.
pygame.event.set_allowed(None)
pygame.event.set_allowed(pygame.QUIT)
pygame.event.wait()
