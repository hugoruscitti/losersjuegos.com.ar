# -*- coding: utf-8 -*-
#
# Copyright 2007 Hugo Ruscitti <hugoruscitti@gmail.com>
# More info: http://www.losersjuegos.com.ar
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA


import pygame
import util
from banana import Banana
from bomba import Bomba
from cazador import Cazador

class Escenario:
    """Muestra y resulve las colisiones de un laberinto.

    El laberinto tiene un tamaño de 550x320 pixeles, y está situado
    aproximadamente en el centro de la pantalla. A unos 50 pixeles
    del costado izquierdo y 80 de la parte superior de la pantalla."""

    def __init__(self, nivel=1):
        self.vertical = util.cargar_imagen('vertical.png')
        self.horizontal = util.cargar_imagen('horizontal.png')
        self.esquina_1 = util.cargar_imagen('esquina_1.png')
        self.esquina_3 = util.cargar_imagen('esquina_3.png')
        self.esquina_7 = util.cargar_imagen('esquina_7.png')
        self.esquina_9 = util.cargar_imagen('esquina_9.png')
        self.mapa = self.cargar_nivel(nivel)

    def imprimir(self, fondo):
        imagenes = {
            '-': self.horizontal,
            '|': self.vertical,
            '1': self.esquina_1,
            '3': self.esquina_3,
            '7': self.esquina_7,
            '9': self.esquina_9,
            }

        y = 0

        for fila in self.mapa:
            x = 0

            for celda in fila:
                if celda in imagenes:
                    #pos = (60 + x * 48- 55, 80 + y * 43 - 43)
                    pos = (60 + x * 48 - 30, 80 + y * 43 - 30)
                    fondo.blit(imagenes[celda], pos)

                x += 1

            y += 1

    def cargar_nivel(self, nivel):
        nombre_del_archivo = 'nivel_%d.txt' %nivel
        archivo = open(nombre_del_archivo, 'rt')
        mapa = archivo.readlines()
        archivo.close()
        return mapa

    def crear_objetos(self, bananas, bombas, cazadores):
        y = 0
        for fila in self.mapa:
            x = 0
            for celda in fila:
                pos_x, pos_y = util.a_coordenadas(y, x)

                if celda == '+':
                    bananas.add(Banana(pos_x, pos_y))
                elif celda == 'x':
                    bombas.add(Bomba(pos_x, pos_y))
                elif celda == '@':
                    cazadores.add(Cazador(pos_x, pos_y, self))

                x += 1

            y += 1

    def puede_avanzar(self, (fila, columna), (df, dc)):

        # limites de la pantalla
        if fila + df < 0 or fila + df > 7:
            return False
        elif columna + dc < 0 or columna + dc > 11:
            return False

        if self.mapa[fila + df][columna + dc] in '1379-|':
            return False

        return True
