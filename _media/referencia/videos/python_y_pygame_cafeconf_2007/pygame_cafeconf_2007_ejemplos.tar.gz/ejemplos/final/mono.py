# -*- coding: utf-8 -*-
#
# Copyright 2007 Hugo Ruscitti <hugoruscitti@gmail.com>
# More info: http://www.losersjuegos.com.ar
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA


import pygame
from pygame.sprite import Sprite
from pygame import *
import util
import sonidos


class Mono(Sprite):

    def __init__(self, escenario):
        Sprite.__init__(self)
        self.cargar_imagenes()
        self.image = self.normal
        self.escenario = escenario
        self.en_movimiento = True
        self.columna_destino = 0
        self.fila_destino = 3
        self.contador = 0
        self.x = -50
        self.y = 209
        # genera los rectangulos de posicion y colision
        self.rect = self.image.get_rect()
        self.rect_colision = self.rect.inflate(-30, -30)

    def cargar_imagenes(self):
        self.normal = util.cargar_imagen('mono.png')
        self.contento = util.cargar_imagen('mono_contento.png')
        self.pierde = util.cargar_imagen('mono_pierde.png')

    def update(self):

        # adapta los controles al 'recalcitrante' hábito de usar VIM
        #K_LEFT = K_h
        #K_RIGHT = K_l
        #K_UP = K_k
        #K_DOWN = K_j

        # solo permite controlar al persona si no está en movimiento
        if not self.en_movimiento:
            teclas = pygame.key.get_pressed()

            if teclas[K_LEFT]:
                self.mover(-1, 0)
            elif teclas[K_RIGHT]:
                self.mover(+1, 0)
            elif teclas[K_UP]:
                self.mover(0, -1)
            elif teclas[K_DOWN]:
                self.mover(0, +1)
        else:
            self.actualizar_posicion()

        self.actualizar_animacion()
        self.actualizar_rect_colision()

    def actualizar_posicion(self):
        """Realiza un desplazamiento suave de un sitio a otro.

        Mientras la variable self.en_movimiento vale True, el personaje
        del juego se debe desplazar de forma progresiva desde la posición
        (self.x, self.y) hasta las posición (destino_x, destino_y)."""

        pos = util.a_coordenadas(self.fila_destino, self.columna_destino)
        destino_x, destino_y = pos

        delta_x = (destino_x - self.x) / 2.5
        delta_y = (destino_y - self.y) / 2.5

        # consulta si el desplazamiento es tan pequeño que se debe dar
        # por concluido el desplazamiento
        if abs(delta_x) < 0.1 and abs(delta_y) < 0.1:
            self.x = destino_x
            self.y = destino_y
            self.en_movimiento = False
        else:
            self.x += delta_x
            self.y += delta_y

        self.rect.centerx = int(self.x)
        self.rect.centery = int(self.y)


    def mover(self, desplazamiento_columna, desplazamiento_fila):
        self.en_movimiento = True

        pos_actual = (self.fila_destino, self.columna_destino)
        desplazamiento = (desplazamiento_fila, desplazamiento_columna)

        if self.escenario.puede_avanzar(pos_actual, desplazamiento):
            self.fila_destino += desplazamiento_fila
            self.columna_destino += desplazamiento_columna

    def actualizar_rect_colision(self):
        self.rect_colision.midbottom = self.rect.midbottom

    def actualizar_animacion(self):
        if self.contador > 0:
            self.contador -= 1

            if self.contador < 1:
                self.image = self.normal

    def ponerse_contento(self):
        self.image = self.contento
        self.contador = 30
        sonidos.reproducir_sonido('come')

    def pierde_una_vida(self):
        self.image = self.pierde
        self.contador = 65
