# -*- coding: utf-8 -*-
#
# Copyright 2007 Hugo Ruscitti <hugoruscitti@gmail.com>
# More info: http://www.losersjuegos.com.ar
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA


from pygame.sprite import Sprite
import util

class Banana(Sprite):

    def __init__(self, x, y):
        Sprite.__init__(self)
        self.image = util.cargar_imagen('banana.png')
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.rect_colision = self.rect.inflate(-30, -10)
        self.delay = None
        self.se_puede_comer = True

    def update(self):
        pass

    def update_desaparecer(self):
        self.delay -= 1
        if self.delay < 1:
            self.kill()

    def comer(self):
        self.image = util.cargar_imagen('banana_a_punto_de_comer.png')
        self.delay = 30
        self.update = self.update_desaparecer
        self.se_puede_comer = False
