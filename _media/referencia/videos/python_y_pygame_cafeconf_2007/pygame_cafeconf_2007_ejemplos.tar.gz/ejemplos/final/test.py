# -*- coding: utf-8 -*-
#
# Copyright 2007 Hugo Ruscitti <hugoruscitti@gmail.com>
# More info: http://www.losersjuegos.com.ar
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA


import pygame
import util

from mono import Mono
from explosion import Explosion
import sonidos
from escenario import Escenario

screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption("Monkey Hunter")
temporizador = pygame.time.Clock()

fondo = util.cargar_imagen('escenario.jpg', optimizar=True)
logotipo = util.cargar_imagen('logo.png')
decoracion = util.cargar_imagen('decoracion.png')

sprites = pygame.sprite.OrderedUpdates()
bananas = pygame.sprite.Group()
bombas = pygame.sprite.Group()
cazadores = pygame.sprite.Group()

escenario = Escenario()
escenario.imprimir(fondo)
escenario.crear_objetos(bananas, bombas, cazadores)

mono = Mono(escenario)

sprites.add(bananas)
sprites.add(bombas)
sprites.add(cazadores)
sprites.add(mono)

salir = False

while not salir:

    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            salir = True
        elif e.type == pygame.KEYDOWN:
            if e.unicode == 'q':
                salir = True
            elif e.unicode == 'f':
                pygame.display.toggle_fullscreen()

    # colisiones con bananas
    banana_en_colision = util.spritecollideany(mono, bananas)

    if banana_en_colision and banana_en_colision.se_puede_comer:
        banana_en_colision.comer()
        mono.ponerse_contento()

    # colisiones con las bombas
    bomba_en_colision = util.spritecollideany(mono, bombas)

    if bomba_en_colision and not bomba_en_colision.esta_cerrada:
        sprites.add(Explosion(bomba_en_colision))
        bomba_en_colision.kill()
        sonidos.reproducir_sonido('pierde')
        sonidos.reproducir_sonido('boom')
        mono.pierde_una_vida()
        sprites.remove(mono)
        sprites.add(mono)
        for c in cazadores:
            c.ponerse_contento()

    cazador_en_colision = util.spritecollideany(mono, cazadores)

    if cazador_en_colision:
        cazador_en_colision.kill()
        sonidos.reproducir_sonido('pierde')
        mono.pierde_una_vida()
            

    sprites.update()
    screen.blit(fondo, (0, 0))

    sprites.draw(screen)
    
    # Observar los rectángulos de colisión
    #for s in sprites.sprites():
    #    try:
    #        screen.fill((0, 0, 0), s.rect_colision)
    #    except:
    #        pass

    screen.blit(decoracion, (0, 0))
    screen.blit(logotipo, (640 - 67, 480 - 85))
    pygame.display.flip()
    temporizador.tick(60)
