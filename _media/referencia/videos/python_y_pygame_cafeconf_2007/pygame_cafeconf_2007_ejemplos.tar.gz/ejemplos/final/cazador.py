# -*- coding: utf-8 -*-
#
# Copyright 2007 Hugo Ruscitti <hugoruscitti@gmail.com>
# More info: http://www.losersjuegos.com.ar
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA


import pygame
from pygame.sprite import Sprite
from pygame import *
import util
import sonidos

# direcciones
IZQUIERDA, DERECHA, ARRIBA, ABAJO = range(4)

class Cazador(Sprite):

    def __init__(self, pos_x, pos_y, escenario):
        Sprite.__init__(self)
        self.cargar_imagenes()
        self.image = self.normal
        self.escenario = escenario
        self.contador = 0
        self.x = pos_x
        self.y = pos_y
        self.fila_destino, self.columna_destino = util.a_celdas(pos_x, pos_y)
        self.demora_antes_de_mover = -1
        self.rect = self.image.get_rect()
        self.rect.center = (pos_x, pos_y)
        self.rect_colision = self.rect.inflate(-30, -30)
        self.direccion = IZQUIERDA

    def cargar_imagenes(self):
        self.normal = util.cargar_imagen('cazador.png')
        self.contento = util.cargar_imagen('cazador_contento.png')

    def update(self):
        direcciones = {
                IZQUIERDA: (-1, 0),
                DERECHA: (1, 0),
                ARRIBA: (0, -1),
                ABAJO: (0, 1)
                }

        # solo permite controlar al persona si no está en movimiento
        if self.demora_antes_de_mover < 1:
            x, y = direcciones[self.direccion]
            self.mover(x, y)
            self.demora_antes_de_mover = 30
        else:
            self.actualizar_posicion()

        self.actualizar_animacion()
        self.actualizar_rect_colision()
        self.demora_antes_de_mover -= 1


    def actualizar_posicion(self):
        """Realiza un desplazamiento suave de un sitio a otro.

        Mientras la variable self.en_movimiento vale True, el personaje
        del juego se debe desplazar de forma progresiva desde la posición
        (self.x, self.y) hasta las posición (destino_x, destino_y)."""

        #destino_x = self.columna_destino * 48 + 60
        #destino_y = self.fila_destino * 43 + 80
        pos = util.a_coordenadas(self.fila_destino, self.columna_destino)
        destino_x, destino_y = pos

        delta_x = (destino_x - self.x) / 12.0
        delta_y = (destino_y - self.y) / 12.0

        # consulta si el desplazamiento es tan pequeño que se debe dar
        # por concluido el desplazamiento
        if abs(delta_x) < 0.1 and abs(delta_y) < 0.1:
            self.x = destino_x
            self.y = destino_y
        else:
            self.x += delta_x
            self.y += delta_y

        self.rect.centerx = int(self.x)
        self.rect.centery = int(self.y)


    def mover(self, desplazamiento_columna, desplazamiento_fila):
        pos_actual = (self.fila_destino, self.columna_destino)
        desplazamiento = (desplazamiento_fila, desplazamiento_columna)

        if self.escenario.puede_avanzar(pos_actual, desplazamiento):
            self.fila_destino += desplazamiento_fila
            self.columna_destino += desplazamiento_columna
        else:
            if self.direccion == IZQUIERDA:
                self.direccion = ARRIBA
            elif self.direccion == ARRIBA:
                self.direccion = DERECHA
            elif self.direccion == DERECHA:
                self.direccion = ABAJO
            elif self.direccion == ABAJO:
                self.direccion = IZQUIERDA

    def actualizar_rect_colision(self):
        self.rect_colision.midbottom = self.rect.midbottom

    def actualizar_animacion(self):
        if self.contador > 0:
            self.contador -= 1

            if self.contador < 1:
                self.image = self.normal

    def ponerse_contento(self):
        self.image = self.contento
        self.contador = 60
