# -*- coding: utf-8 -*-
import pygame
from pygame.sprite import Sprite

salir = False                         # indica la terminación del programa

screen = pygame.display.set_mode((640, 480))        # genera la ventana
pygame.display.set_caption("Monkey Hunter")         # define un título

temporizador = pygame.time.Clock()

# crea dos objetos "Surface".
#
# nota: las funciones "convert" y "convert_alpha" convierten la superficie
#       creada por "load" a un formato de color que permite imprimirlas mucho
#       mas rápido sobre la pantalla.
fondo = pygame.image.load("escenario.jpg").convert()
logotipo = pygame.image.load("logo.png").convert_alpha()
fondo.blit(logotipo, (570, 390)) 

mono = pygame.image.load("mono.png").convert_alpha()
pos_x = 200
pos_y = 300

while not salir:
    pos_x += 10

    if pos_x > 640:
        pos_x = - 40

    screen.blit(mono, (pos_x, pos_y)) # imprime al 'mono' en pantalla.
    pygame.display.flip()             # se muestran lo cambios en pantalla

    temporizador.tick(60)
    screen.blit(fondo, (0, 0))

    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            salir = True
