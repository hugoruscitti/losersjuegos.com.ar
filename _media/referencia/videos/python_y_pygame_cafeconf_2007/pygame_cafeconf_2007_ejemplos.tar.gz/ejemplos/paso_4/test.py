# -*- coding: utf-8 -*-
import pygame
from pygame.locals import *
from pygame.sprite import Sprite

class Mono(Sprite):

    def __init__(self):
        self.image = pygame.image.load("mono.png").convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.move_ip(200, 300)

    def update(self):
        teclas = pygame.key.get_pressed()

        if teclas[K_LEFT]:
            self.rect.x -= 10
        elif teclas[K_RIGHT]:
            self.rect.x += 10

        if teclas[K_UP]:
            self.rect.y -= 10
        elif teclas[K_DOWN]:
            self.rect.y += 10



if __name__ == '__main__':
    salir = False

    # creacion de la ventana
    screen = pygame.display.set_mode((640, 480))
    pygame.display.set_caption("Monkey Hunter")
    fondo = pygame.image.load("escenario.jpg").convert()
    logotipo = pygame.image.load("logo.png").convert_alpha()
    fondo.blit(logotipo, (570, 390))


    # objetos
    temporizador = pygame.time.Clock()
    mono = Mono()

    while not salir:
        mono.update()

        # actualizacion grafica
        screen.blit(fondo, (0, 0))
        screen.blit(mono.image, mono.rect)
        pygame.display.flip()

        temporizador.tick(60)
        # gestion de eventos
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                salir = True


