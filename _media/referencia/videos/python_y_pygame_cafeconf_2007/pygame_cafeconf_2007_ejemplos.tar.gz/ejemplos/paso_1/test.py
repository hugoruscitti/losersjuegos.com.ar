import pygame

pygame.display.set_mode((640, 480))
pygame.display.set_caption("Monkey Hunter")

# espera hasta que el usuario cierra la ventana
pygame.event.set_allowed(None)
pygame.event.set_allowed(pygame.QUIT)
pygame.event.wait()
