# -*- coding: utf-8 -*-

import pygame
import util
from mono import Mono
from explosion import Explosion
import sonidos
from banana import Banana
from cazador import Cazador
from bomba import Bomba

# recursos del juego
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption("Monkey Hunter")
temporizador = pygame.time.Clock()

# fondo de pantalla
fondo = util.cargar_imagen('escenario.jpg', optimizar=True)
logotipo = util.cargar_imagen('logo.png')
fondo.blit(logotipo, (640 - 67, 390))

# grupos
sprites = pygame.sprite.OrderedUpdates()
bananas = pygame.sprite.Group()
bombas = pygame.sprite.Group()
cazadores = pygame.sprite.Group()

# creación de sprites
mono = Mono()

bananas.add([Banana(200, 200), Banana(300, 200), Banana(400, 300)])
cazadores.add([Cazador(100, 100)])
bombas.add([Bomba(300, 100), Bomba(400, 130)])

# incluimos a todos los sprites al grupo principal
sprites.add([mono, bananas, bombas, cazadores])

salir = False

while not salir:

    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            salir = True
        elif e.type == pygame.KEYDOWN:
            if e.unicode == 'q':
                salir = True
            elif e.unicode == 'f':
                pygame.display.toggle_fullscreen()

    # colisiones con bananas
    banana_para_comer = pygame.sprite.spritecollideany(mono, bananas)

    if banana_para_comer:
        banana_para_comer.kill()
        mono.ponerse_contento()
        grito = pygame.mixer.Sound("sonidos/come_fruta.wav")
        grito.play()

    # colisiones con las bombas
    bomba_en_colision = pygame.sprite.spritecollideany(mono, bombas)

    if bomba_en_colision and not bomba_en_colision.esta_cerrada:
        sprites.add(Explosion(bomba_en_colision))
        bomba_en_colision.kill()
        sonidos.reproducir_sonido('pierde')
        sonidos.reproducir_sonido('boom')
        mono.pierde_una_vida()
        sprites.remove(mono)
        sprites.add(mono)
        for c in cazadores:
            c.ponerse_contento()

    cazador_en_colision = pygame.sprite.spritecollideany(mono, cazadores)

    if cazador_en_colision:
        cazador_en_colision.kill()
        sonidos.reproducir_sonido('pierde')
        mono.pierde_una_vida()
            

    sprites.update()
    screen.blit(fondo, (0, 0))
    sprites.draw(screen)
    pygame.display.flip()
    temporizador.tick(60)
