# -*- coding: utf-8 -*-
#
# Copyright 2007 Hugo Ruscitti <hugoruscitti@gmail.com>
# More info: http://www.losersjuegos.com.ar
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA


from pygame.sprite import Sprite
import util

class Bomba(Sprite):

    def __init__(self, x, y):
        Sprite.__init__(self)
        self.cuadros = [
                util.cargar_imagen('bomba1.png'),
                util.cargar_imagen('bomba2.png'),
                ]
        self.rect = self.cuadros[0].get_rect()
        self.rect.center = (x, y)
        self.esta_cerrada = False
        self.rect_colision = self.rect.inflate(-30, -30)
        self.paso = 0
        self.delay = -1

    def update(self):
        if self.delay < 0:
            self.actualizar_animacion()
            self.delay = 2
        else:
            self.delay -= 1

    def actualizar_animacion(self):

        if self.paso == 0:
            self.paso = 1
        else:
            self.paso = 0

        self.image = self.cuadros[self.paso]
