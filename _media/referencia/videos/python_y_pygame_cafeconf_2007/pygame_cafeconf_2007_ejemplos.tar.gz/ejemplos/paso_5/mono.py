# -*- coding: utf-8 -*-
#
# Copyright 2007 Hugo Ruscitti <hugoruscitti@gmail.com>
# More info: http://www.losersjuegos.com.ar
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA


import pygame
from pygame.sprite import Sprite
from pygame import *
import util
import sonidos


class Mono(Sprite):

    def __init__(self):
        Sprite.__init__(self)
        self.cargar_imagenes()
        self.image = self.normal
        self.contador = 0
        self.rect = self.image.get_rect()

    def cargar_imagenes(self):
        self.normal = util.cargar_imagen('mono.png')
        self.contento = util.cargar_imagen('mono_contento.png')
        self.pierde = util.cargar_imagen('mono_pierde.png')

    def update(self):
        teclas = pygame.key.get_pressed()

        if teclas[K_LEFT]:
            self.rect.x -= 5
        elif teclas[K_RIGHT]:
            self.rect.x += 5

        if teclas[K_UP]:
            self.rect.y -= 5
        elif teclas[K_DOWN]:
            self.rect.y += 5

        self.actualizar_animacion()

    def actualizar_animacion(self):
        if self.contador > 0:
            self.contador -= 1

            if self.contador < 1:
                self.image = self.normal

    def ponerse_contento(self):
        self.image = self.contento
        self.contador = 30

    def pierde_una_vida(self):
        self.image = self.pierde
        self.contador = 65
