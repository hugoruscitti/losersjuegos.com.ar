/* 
 * Ejemplo : Escalado y rotacion de 2 superficies 
 * (Adaptado del ejemplo mini escalado por Hugo Ruscitti).
 * 
 * Copyright (C) 2006 Lucas Liendo.
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
 */

#include <SDL/SDL.h>
#include "SDL_rotozoom.h"
#include <SDL_image.h> 
#include <stdio.h>
#include <stdlib.h>

#define pi2 6.28318

int iniciar_sdl (SDL_Surface ** pantalla)
{
	if (SDL_Init (SDL_INIT_VIDEO) == -1) 
	{
		printf("Error: %s\n", SDL_GetError());
		return 1;
	}

	* pantalla = SDL_SetVideoMode (300, 300, 16, SDL_SWSURFACE);
	
	if (pantalla == NULL) 
	{
		printf("Error: %s\n", SDL_GetError());
		return 1;
	}
	
	return 0;
}

void limpiar(SDL_Surface *screen, int x, int y, int w, int h)
{
	SDL_Rect rect = {x, y, w, h};
	SDL_FillRect(screen, &rect, SDL_MapRGB(screen->format, 20, 100, 20));
}


void inf_loop (SDL_Surface * ventana)
{
	int salir = 0;
	double angulo = 0;
	double zoom = 1;
	SDL_Surface * imagen;
	SDL_Surface * imagen_copia;
	SDL_Surface * imagen2;
	SDL_Surface * imagen2_copia;
	SDL_Event evento;
	SDL_Rect rect1;
	SDL_Rect rect2;

	imagen = IMG_Load ("../ima/mail.png");
	imagen2 = IMG_Load ("../ima/stop.png");

	rect1.x = 150;
	rect1.y = 150;

	rect2.x = 100;
	rect2.y = 100;

	while (! salir)
	{
		while (SDL_PollEvent (&evento))
		{
			switch (evento.type)
			{
				case SDLK_q :
					salir = 1;
					break;

				case SDL_QUIT :
					salir = 1;
					break;

				default :
					break;
			}
		}

		if (angulo < 360)
		{
			angulo = angulo + 1;
			zoom = (angulo * pi2) / 360;
			imagen_copia = rotozoomSurface (imagen, angulo, fabs (sin (zoom)), 1);
			imagen2_copia = rotozoomSurface (imagen2, angulo, fabs (cos (zoom)), 1);

			rect1.x = 190 - imagen_copia->w / 2;
			rect1.y = 150 - imagen_copia->h / 2;
			
			rect2.x = 110 - imagen2_copia->w / 2;
			rect2.y = 150 - imagen2_copia->h / 2;

			limpiar(ventana, 0, 0, ventana->w, ventana->h);
			SDL_BlitSurface (imagen_copia, NULL, ventana, &rect1);
			SDL_BlitSurface (imagen2_copia, NULL, ventana, &rect2);
			SDL_FreeSurface (imagen_copia);
			SDL_FreeSurface (imagen2_copia);
			SDL_Flip (ventana);
		}
		else
			angulo = 0;
		
		SDL_Delay (10);
	}

	SDL_FreeSurface (imagen);
	SDL_FreeSurface (imagen2);
}


int main (void)
{
	SDL_Surface * ventana;

	if (iniciar_sdl (&ventana))
		return 1;

	inf_loop (ventana);

	SDL_Quit ();
	return 0;
}
