# -*- coding: utf-8 -*-
#
# Autor: David Ramírez
# Licencia: GPL 3

import pygame
from pygame import *
from math import *

resolucion = (500, 300)
color = (255, 240, 220)

class Antiaereo ( sprite.Sprite):
    def __init__(self, centro):
        sprite.Sprite.__init__(self)
        
        # Se crea la imagen de la circunferencia grande y se situa
        self.img_base = pygame.image.load("base.png").convert()
        color_transparente = self.img_base.get_at((0,0))
        self.img_base.set_colorkey(color_transparente)
        self.rect_base = self.img_base.get_rect()
        #self.rect.center = centro
        
        # Se crea la imagen de la circunferencia pequeña
        self.img_canyon = pygame.image.load("canyon.png").convert()
        color_transparente = self.img_canyon.get_at((0, 0))
        self.img_canyon.set_colorkey(color_transparente)
        self.rect_canyon = self.img_canyon.get_rect()
        
        self.image = Surface((self.rect_canyon.width, self.rect_canyon.height)).convert()
        #self.image.fill((255,255,0))
        self.image.set_colorkey((255,255,0))
        self.rect = self.image.get_rect()
        self.rect.center = centro
        
        self.centro = centro
        
    def update(self, pos_rat):
        # Se hace una copia de la imagen de la circunferencia grande y se
        # imprime, sobre ella, la circunferencia pequeña con centro en la posición 
        # que devuelve "obt_pos_mir".
        
        #self.pos_mirada = self.obt_pos_mir(pos_rat)
        self.image.fill((255,255,0))
        
        self.canyon = self.mover_canyon(self.img_canyon, pos_rat)
        self.rect_canyon = self.canyon.get_rect()
        #self.rect_canyon.center = self.centro
        #self.image = Surface((self.canyon_rect.width, 
        #self.image.blit(self.canyon, (self.rect - self.rad_p, self.pos_mirada[1] - self.rad_p))
        
        #self.image = Surface((self.rect_canyon.width, self.rect_canyon.height)).convert()
        
        self.image.blit(self.img_base, ((self.rect.width / 2) - (self.rect_base.width / 2),
                        (self.rect.height / 2) - (self.rect_base.height / 2)))
        self.image.blit(self.canyon, ((self.rect.width / 2) - (self.rect_canyon.width / 2),
                        (self.rect.height / 2) - (self.rect_canyon.height / 2)))
    def mover_canyon(self, img_canyon, pos_rat):
        # Se devuelve la posición en la que se tiene que situar el centro de la
        # circunferencia pequeña, en realación a la grande, dependiendo de la
        # posición del ratón.
        # Para ello, hace falta saber el angulo exacto del centro a la posición
        # del ratón. Teniendo en cuenta que tan(ángulo) == tan(ángulo + pi).
        if (pos_rat[0] - self.centro[0]) == 0:
            if pos_rat[1] > self.centro[1]:
                a = pi / 2
            else:
                a = - pi / 2
        else:
            if pos_rat[0] > self.centro[0]:
                a = atan((self.centro[1] - pos_rat[1]) / (self.centro[0] - pos_rat[0]))
            else:
                a = pi + atan((self.centro[1] - pos_rat[1]) / (self.centro[0] - pos_rat[0]))
                
        canyon_girado = transform.rotate(img_canyon, degrees(-a))
        #print a
        return canyon_girado
            
    def dis_pq(self, P, Q):
        # Se devuelve la distancia de un punto a otro
        Px, Py = P
        Qx, Qy = Q
        
        h = hypot(Px - Qx, Py - Qy)
        return h

def main():
    # Se crea la pantalla con la resolución determinada
    screen = pygame.display.set_mode(resolucion)
    # Se crea el grupo ojos y se añaden dos
    antiaereos = pygame.sprite.Group()
    for a in range(1, 9):
        antiaereos.add(Antiaereo(( -15 + a * 60.0, 60.0 + sin(a) * 40)))
    
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                # Finaliza el programa si hay un evento de cerrar
                return
        screen.fill(color)  # Se pinta la pantalla
        pos = mouse.get_pos()  # Se otiene la posición del ratón
        antiaereos.update(pos)  # Se actualizan los ojos dependiendo de "pos"
        antiaereos.draw(screen)  # Se dibujan los ojos
        display.update()  # Se actualiza la pantalla

if __name__ == '__main__':
    main()
