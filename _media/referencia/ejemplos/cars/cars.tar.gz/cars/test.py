# -*- coding: utf-8 -*-
from engine import Engine
from stage import Stage
from car import Car

engine = Engine('Cars, maneja un automóvil')
stage = Stage()
car = Car(stage)

engine.add(car)
engine.set_background(stage.get_image())
engine.loop()
