# -*- coding: utf-8 -*-
import pygame
from pygame.locals import *

class Engine:
    
    def __init__(self, title='example', width=640, height=480):
        pygame.init()
        self.screen = pygame.display.set_mode((width, height), 16)
        self.background = self.screen.copy()
        self.sprites = pygame.sprite.RenderUpdates()
        self.clock = pygame.time.Clock()
        self.quit = False
        pygame.display.set_caption(title)

    def add(self, sprite):
        self.sprites.add(sprite)

    def set_background(self, image):
        self.background.blit(image, (0, 0))
        self.screen.blit(self.background, (0, 0))
        pygame.display.flip()

    def loop(self):

        while not self.quit:
            self.sprites.update()
            self.sprites.clear(self.screen, self.background)
            pygame.display.update(self.sprites.draw(self.screen))

            for e in pygame.event.get():
                if e.type == QUIT:
                    self.quit = True
                elif e.type == KEYDOWN:
                    if e.unicode == 'q':
                        self.quit = True
                    elif e.unicode == 'f':
                        pygame.display.toggle_fullscreen()

            self.clock.tick(100)
        
