# -*- coding: utf-8 -*-
import os

import pygame
from pygame.locals import *

class Stage:
    
    def __init__(self):
        self.load_stage_map(1)

    def load_stage_map(self, stage_number):
        """Carga el archivo de bloques para el escenario.

        A partir de un archivo de texto, este método almacenará en 'self.tiles'
        una matriz donde cada celda indica un código de bloque para imprimir.
        Por ejemplo el bloque 'a7' indica que ese bloque se debe mostrar
        mediante la imagen 'ima/a7.png', vea el método 'get_image'."""
        
        file = open("stages/%s.txt" %(stage_number), 'rt')
        content = file.readlines()
        self.tiles = [[x for x in row.split()] for row in content]

    def get_tile_number(self, screen_x, screen_y):
        """Retorna el numero de tile a imprimir en una coordenada de pantalla."""
        row = screen_y / 64
        col = screen_x / 64
        return self.tiles[row][col]

    def get_image(self):
        """Imprime todos los bloques gráficos sobre una nueva superficie."""

        surface = pygame.display.get_surface().copy()

        images = dict()
        for filename in os.listdir('ima'):
            name = filename.replace('.png', '')
            images[name] = pygame.image.load('ima/' + filename)

        for row in range(8):
            for col in range(10):
                tile_value = self.tiles[row][col]
                surface.blit(images['00'], (col * 64, row * 64))
                surface.blit(images[tile_value], (col * 64, row * 64))

        return surface


if __name__ == '__main__':

    stage = Stage()
    screen = pygame.display.set_mode((640, 480))
    stage.draw(screen)
    pygame.display.flip()
    pygame.time.delay(2000)
