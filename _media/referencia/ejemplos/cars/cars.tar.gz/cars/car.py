# -*- coding: utf-8 -*-

import pygame
from pygame.locals import *
from pygame.sprite import Sprite
from math import sin, cos, radians

# Atributos del automovil
MAX_SPEED = 3
ACCEL = 0.2
DELTA_SPEED = 0.1

# Limites del escenario
LEFT = 0
RIGHT = 640
UP = 0
DOWN = 480


class Car(Sprite):
    """Representa un automóvil del videojuego."""
    
    def __init__(self, stage):
        Sprite.__init__(self)
        self.stage = stage
        self.original_image = pygame.image.load('cars/red.png')
        self.image = self.original_image.copy()
        self.rect = self.image.get_rect()
        self.angle = 0
        self.velocity = 0
        self.x = 100.0
        self.y = 50.0
        self.dx = 0
        self.dy = 0
        self.update_position()

    def update(self):
        key = pygame.key.get_pressed()

        if key[K_LEFT]:
            self.angle -= 0.7 * self.velocity
        elif key[K_RIGHT]:
            self.angle += 0.7 * self.velocity

        if key[K_UP]:
            self.advance(+1)
        elif key[K_DOWN]:
            self.advance(-1)
        else:
            # Reduce la velocidad de manera gradual.
            if self.velocity > DELTA_SPEED:
                self.velocity -= DELTA_SPEED
            elif self.velocity < -DELTA_SPEED:
                self.velocity += DELTA_SPEED
            else:
                self.velocity = 0

        angle = radians(self.angle)
        self.dx = cos(angle) * self.velocity
        self.dy = sin(angle) * self.velocity

        self.check_bound_collision()
        self.update_position()
        self.update_image()
        self.update_floor_contact()

    def update_position(self):
        """Actualiza la posición del automóvil."""
        self.rect.x = int(self.x) - self.rect.w / 2
        self.rect.y = int(self.y) - self.rect.h / 2
        self.x += self.dx
        self.y += self.dy

    def update_floor_contact(self):
        """Reduce la velocidad del automóvil si pisa el pasto."""
        tile_number = self.stage.get_tile_number(int(self.x), int(self.y))

        if tile_number == '00' and self.velocity > MAX_SPEED - 1:
            self.velocity = MAX_SPEED -2


    def check_bound_collision(self):
        """Evita que el automovil quede fuera de la pantalla."""

        if self.dx > 0:
            if self.rect.right >= RIGHT:
                self.x = RIGHT - self.rect.w / 2
                self.velocity *= -1
                return
        else:
            if self.rect.left <= LEFT:
                self.x = LEFT + self.rect.w / 2
                self.velocity *= -1
                return

        if self.dy < 0:
            if self.rect.top < UP:
                self.y = UP + self.rect.h / 2
                self.velocity *= -1
        else:
            if self.rect.bottom > DOWN:
                self.y = DOWN - self.rect.h / 2
                self.velocity *= -1


    def advance(self, delta):
        """Controla los límites de velocidad"""
        self.velocity += ACCEL * delta

        if self.velocity > MAX_SPEED:
            self.velocity = MAX_SPEED
        elif self.velocity < - MAX_SPEED / 2:
            self.velocity = - MAX_SPEED / 2

    def update_image(self):
        self.image = pygame.transform.rotate(self.original_image, -self.angle)
        self.rect.w = self.image.get_width()
        self.rect.h = self.image.get_height()
