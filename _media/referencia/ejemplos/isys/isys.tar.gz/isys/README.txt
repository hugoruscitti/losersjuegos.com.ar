Introduccion:

	La libreria Isys es un conjunto de funciones para facilitar el uso de SDL_TTF.
	Para mas detalles sobre el uso de cada funcion, abra el archivo de cabezera Isys.h

Requerimientos:
	
	Se requieren las siguientes librerias: SDL_TTF, SDL y la clase STRING de estandar C++
	