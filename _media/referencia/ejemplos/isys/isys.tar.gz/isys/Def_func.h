#ifndef DEF_FUNC_H_INCLUDED
#define DEF_FUNC_H_INCLUDED

#define DNORMAL     0x0000		//equivalente a TTF_STYLE_NORMAL
#define DBOLD       0x0001		//equivalente a TTF_STYLE_BOLD
#define DITALIC     0x0002		//equivalente a TTF_STYLE_ITALIC
#define DUNDERLINE  0x0004		//equivalente a TTF_STYLE_UNDERLINE

#define DBACKGR     0x0010		//fondo activado

#define DSOLID      0x0100		//impresion rapida y de baja calidad
#define DSHADED     0x0200		//impresion intermedia
#define DBLENDED    0x0400		//impresion lenta y de alta calidad

#define DTEXT		0x1000
#define DUTF8		0x2000

/*Macro que crea SDL_Color, con 0 = Negro
								1 = Azul
								2 = Verde
								3 = Cyan
								4 = Rojo
								5 = Magenta
								6 = Marron
								7 = Gris claro
								8 = Gris oscuro
								9 = Azul oscuro
							   10 = Verde oscuro
							   11 = Cyan oscuro
							   12 = Amarillo oscuro
							   13 = Magenta oscuro
							   14 = Amarillo
						  default = Blanco
*/

#define DCOLOR(x) (((x)==0)?ScreateColor(0,0,0,0):(((x)==1)?ScreateColor(0,0,255,0):(((x)==2)?ScreateColor(0,255,0,0):(((x)==3)?ScreateColor(0,255,255,0):(((x)==4)?ScreateColor(255,0,0,0):(((x)==5)?ScreateColor(255,0,255,0):(((x)==6)?ScreateColor(128,0,0,0):(((x)==7)?ScreateColor(208,208,208,0):(((x)==8)?ScreateColor(94,94,94,0):(((x)==9)?ScreateColor(0,0,128,0):(((x)==10)?ScreateColor(0,128,0,0):(((x)==11)?ScreateColor(0,128,128,0):(((x)==12)?ScreateColor(128,128,0,0):(((x)==13)?ScreateColor(128,0,128,0):(((x)==14)?ScreateColor(255,255,0,0):ScreateColor(255,255,255,0))))))))))))))))


#endif // DEF_FUNC_H_INCLUDED
