/*
 * Copyright (C) 2007 Martin Di Paola
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 * 02111-1307  USA
 */

/*Creado por Martin Di Paola; petete_zur88@hotmail.com*/

#include "Def_func.h"

#include "Isys.c"

#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>

int main(int argc, char* argv[])
	{
		SDL_Surface *pantalla;

	if(SDL_Init(SDL_INIT_VIDEO)!=0)
		{
    	return -1;
		}
	if(TTF_Init()!=0)
		{
		return -1;
		}

pantalla=SDL_SetVideoMode(800,600,24,SDL_SWSURFACE|SDL_DOUBLEBUF);

	if(pantalla == NULL)
		{
   		return -1;
		}

TTF_Font *Fuente;




SDL_Color Color1={255,255,255,0};
SDL_Color Color2=ScreateColor(200,0,2,0);
SDL_Color Color3={0,0,255,0};



SDL_Surface *img;
SDL_Surface *aux;
img=SDL_LoadBMP("src/nada.bmp");

SDL_Rect rect={330, 20, 0, 0};

SDL_Event event;

/*Uso la funcion Iback()*/
Fuente=TTF_OpenFont("src/fontTTF.ttf", 35);
aux=Iback("Hola Isys!!!!", Fuente, DCOLOR(4), DCOLOR(1), DUTF8|DBOLD|DBLENDED, img, NULL);
SDL_FreeSurface(img);
TTF_CloseFont(Fuente);

int done=0;


while(done != -1) {

/*Limpio la pantalla*/
Sclrscr(pantalla, DCOLOR(0));


/*Imprimo lo escrito con Iback()*/
SDL_BlitSurface( aux, NULL, pantalla, &rect);



/*Escribo un texto con Iprint()*/

Fuente=TTF_OpenFont("src/fontTTF.ttf", 20);
Iprint("Creado por Martin Di Paola, bajo la licencia GPL 2", Fuente, DCOLOR(4), DCOLOR(7), DNORMAL, pantalla, 20, 90);
TTF_CloseFont(Fuente);

/*Escribo un bloque de texto con IprintLim()*/

Fuente=TTF_OpenFont("src/fontTTF.ttf", 15);
IprintLim("Esta serie de funciones usan las librerías SDL y SDL_TTF. Tambien utiliza las librerías estándar del C, las funciones originales estaban en C++ y fueron portadas. \n En general, los nombres de las funciones comienzan con la letra I y retornan 0 si todo salió bien, o distinto de 0 si algo salio mal. Usted puede ver con mucho mas detalle el valor de retorno y otras cosas en el archivo cabezera Isys.h\n \nEstas funciones estan bajo la licencia GPL General Public License 2. Usted debería haber recibido junto con este ejecutable el código fuente y una copia de la licencia. De no ser asi puede comunicarse conmigo a través del siguiente mail: petete_zur88@hotmail.com \n \n Este párrafo fue escrito usando la funcion IprintLim(), mientras que el título fue escrito por Iback(). El texto a la izquierda es un ejemplo de Ivertical(), los textos de abajo estan escritos usando Iprint() e Ifun().", Fuente, DCOLOR(-1), DCOLOR(0), DBLENDED|DUTF8, 740, pantalla, 40, 140);


/*Ejemplo de Ifun()*/
Ifun("......Ifun.................................Ifun....................Ifun...............................Ifun.............................Ifun.............", Fuente, DCOLOR(14), DCOLOR(9), DBLENDED|DTEXT, 20, 80, done, pantalla, 80, 530);


Iprint("Presiona una tecla para salir...", Fuente, DCOLOR(3), DCOLOR(0), DBLENDED|DUTF8, pantalla, 30, 570);
TTF_CloseFont(Fuente);

/*Escribo de forma vertical con Ivertical()*/

Fuente=TTF_OpenFont("src/fontTTF.ttf", 14);
Ivertical("Fuente ae_AlManzomah", Fuente, DCOLOR(5), DCOLOR(12), DBLENDED|DITALIC, pantalla, 0, 0);
TTF_CloseFont(Fuente);


SDL_Flip(pantalla);

if(done>=80) done=0;
done++;

   while ( SDL_PollEvent(&event) ) {

      if ( event.type == SDL_KEYDOWN )
         done = -1;
   }

 }
 SDL_FreeSurface(aux);

SDL_FreeSurface(pantalla);


 TTF_Quit();
 SDL_Quit();
return 0;

	}






