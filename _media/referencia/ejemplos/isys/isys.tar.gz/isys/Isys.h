/*ISYS  I/o SolutYon for Sdl*/

/*Creado por Martin Di Paola, bajo la licencia GPL 2
  Ante cualquier duda, comunicarse al siguiente mail
  petete_zur88@hotmail.com*/

#ifndef ISYS_H_INCLUDED
#define ISYS_H_INCLUDED

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>


#include "Def_func.h"

/***********************************************************************************
 *
 *@summary strNULL() devuelve 1 si la cadena apunta a NULL o bien, si el primer caracter es \0
 *				Devuelve 0 si la cadena es No vacia
 *
 *@requests C
 *
 *@version 1.0.0
 *@author Di Paola Martin Pablo
 *@license GPL version 2
 *
 *@param *s1, const char: Cadena de origen
 *
 ************************************************************************************/

int strNULL(const char *s1);

/***********************************************************************************
 *
 *@summary strMN() devuelve una subcadena de la cadena original pasada como parametro
 *
 *@requests C
 *
 *@version 1.0.5
 *@author Di Paola Martin Pablo
 *@license GPL version 2
 *
 *@param *s1, const char: Cadena de origen
 *@param start, unsigned int: Posicion desde donde se empezara a copiar
 *@param num, unsigned int: Cantidad de posiciones a copiar
 *
 *@return const char*
 *
 *@note Es de uso interno para otras funciones. El usuario de esta funcion debe encargarse
 *		de liberar la memoria apuntada por el puntero de retorno.
 *
 ************************************************************************************/

const char *strMN(const char *s1, unsigned int start, unsigned int num);


/***********************************************************************************
 *
 *@summary ScreateColor() devuelve una estructura SDL_Color
 *
 *@requests SDL
 *
 *@version 1.0.0
 *@author Di Paola Martin Pablo
 *@license GPL version 2
 *
 *@param r, Uint8: Componente rojo
 *@param g, Uint8: Componente verde
 *@param b, Uint8: Componente azul
 *@param z, Uint8: Sin usuar
 *
 *@return SDL_Color
 *
 ************************************************************************************/

SDL_Color ScreateColor(Uint8 r, Uint8 g, Uint8 b, Uint8 z);

/***********************************************************************************
 *
 *@summary ScreateSurf devuelve una superficie de color CBase y los
 *			atributos de la superficie principal (screen/pantalla)
 *
 *@requests SDL
 *
 *@version 1.0.1
 *@author Di Paola Martin Pablo
 *@license GPL version 2
 *
 *@param width, height, unsigned int: Ancho y alto de la superficie a crear
 *@param CBase, SDL_Color: Color del del fondo
 *
 *@return Devuelve SDL_Surface* si todo salio bien, o NULL si salio mal
 *
 ************************************************************************************/
SDL_Surface *ScreateSurf(unsigned int width, unsigned int height, SDL_Color CBase);

/***********************************************************************************
 *
 *@summary Sclrscr() borra la superficie con un color determinado
 *
 *@requests SDL
 *
 *@version 1.0.1
 *@author Di Paola Martin Pablo
 *@license GPL version 2
 *
 *@param *paper, SDL_Surface: Superficie a borrar
 *@param CBase, SDL_Color: Color para borrar
 *
 *@return void
 *
 ************************************************************************************/

void Sclrscr(SDL_Surface *paper, SDL_Color CBase);

/*************************************************************************
 *
 *@summary Ssize mide el largo y ancho de un texto
 *
 *@requests SDL, SDL_TTF
 *
 *@version 1.0.1
 *@author Di Paola Martin Pablo
 *@license GPL version 2
 *
 *@param *t_tmp, const char : Texto a escribir. No acepta saltos de linea
 *@param *font, TTF_Font: Fuente a utilizar
 *@param *w, int: Ancho de la imagen
 *@param *h, int: Alto de la imagen
 *@param flag16, Uint16: Opciones (DTEXT o DUTF8)
 *
 *@return Devuelve 0 si todo salio bien, o distinto de 0 si salio mal
 *
 *@note Es de uso interno para otras funciones
 *
 ************************************************************************************/

int Ssize(const char *t_tmp, TTF_Font *font, int *w, int *h, Uint16 flag16);


/***********************************************************************************
 *
 *@summary IdefaultFlag chequea un flag y en caso de haber un error o
 *			de estar incompleto el flag, se lo setea con DNORMAL|DBLENDED|DTEXT
 *
 *@requests SDL
 *
 *@version 1.0.2
 *@author Di Paola Martin Pablo
 *@license GPL version 2
 *
 *@param *flag16, Uint16: Flag a chequear
 *
 *@return Void
 *
 *@note Puede darse el caso de que el flag este incompleto, EJ: DITALIC|DSHADED. En este
 *		caso (falta decidir si se quiere DTEXT o DUTF8) la funcion modifica el flag solamente
 *		en la parte incompleta quedando como resultado DITALIC|DSHADED|DTEXT
 *
 *@note Es de uso interno para otras funciones
 *
 ************************************************************************************/

 void IdefaultFlag(Uint16 *flag16);

 /*************************************************************************
 *
 *@summary Iwrite devuelve una superficie con un texto escrito en ella
 *
 *@requests SDL, SDL_TTF
 *
 *@version 1.0.2
 *@author Di Paola Martin Pablo
 *@license GPL version 2
 *
 *@param *Text, const char: Texto a escribir. No acepta saltos de linea
 *@param *font, TTF_Font: Fuente a utilizar
 *@param CText, SDL_Color: Color del texto
 *@param CBackgr, SDL_Color: Color del fondo. Es usado solamente si se usa DSHADED
 *@param flag16, Uint16: Opciones (DSOLID, DSHADED o DBLENDED; DTEXT o DUTF8)
 *
 *@return Devuelve la superficie si todo salio bien, o NULL si salio mal
 *
 *@note No permite modificar el estilo (italic/bold)
 *		Si la flag es DSHADED tendra fondo si o si
 *
 *@note Se recomienda usar Iprint
 *
 ************************************************************************************/

SDL_Surface *Iwrite(const char *Text, TTF_Font *font, SDL_Color CText, SDL_Color CBackgr,Uint16 flag16);


/***********************************************************************************
 *
 *@summary Iprint imprime un texto sobre una superficie
 *
 *@requests SDL, SDL_TTF
 *
 *@version 1.0.2
 *@author Di Paola Martin Pablo
 *@license GPL version 2
 *
 *@param *Text, const char: Texto a escribir. No acepta saltos de linea
 *@param *font, TTF_Font: Fuente a utilizar
 *@param Ctext, SDL_Color: Color del texto
 *@param Cbackgr, SDL_Color: Color del fondo. Es usado solamente si se usa DSHADED|DBACKGR
 *@param flag16, Uint16: Opciones.Determina la calidad y el estilo del texto.Y ademas si tendra o no fondo
 *@param *paper, SDL_Surface: Superficie donde se dibujara el texto
 *@param x, y , unsigned int: Posiciones xy donde se dibujara el texto
 *
 *@return Devuelve 0 si todo salio bien, y un numero distinto de 0 si salio mal
 *
 *@note Solo se imprime el fondo si DSHADED y DBACKGR estan activadas
 *		No acepta saltos de linea
 *
 ************************************************************************************/

int Iprint(const char *Text, TTF_Font *font, SDL_Color CText, SDL_Color CBackgr, Uint16 flag16, SDL_Surface *paper, unsigned int x, unsigned int y);


/***********************************************************************************
 *
 *@summary Iprint devuelve una superficie con el texto escrito
 *
 *@requests SDL, SDL_TTF
 *
 *@version 000.0.1
 *@author Di Paola Martin Pablo
 *@license GPL version 2
 *
 *@param *Text, const char: Texto a escribir. No acepta saltos de linea
 *@param *font, TTF_Font: Fuente a utilizar
 *@param Ctext, SDL_Color: Color del texto
 *@param Cbackgr, SDL_Color: Color del fondo. Es usado solamente si se usa DBACKGR
 *@param flag16, Uint16: Opciones.Determina la calidad y el estilo del texto.Y ademas si tendra o no fondo
 *
 *@return Devuelve SDL_Surface* si todo salio bien, o NULL si salio mal
 *
 *@note La superficie devuelta podria ser tratada con SDL_DisplayFormat por parte del usuario
 *
 ************************************************************************************/

//SDL_Surface *Iprint(const char *Text, TTF_Font *font, SDL_Color CText, SDL_Color CBackgr, Uint16 flag16);


/**********************************************************************************
 *
 *@summary IprintLim escribe en una superficie el texto con un
 *			limite de ancho y aceptando saltos de linea
 *
 *@requests SDL, SDL_TTF
 *
 *@version 1.0.2
 *@author Di Paola Martin Pablo
 *@license GPL version 2
 *
 *@param *Text, const char: Texto a escribir. Acepta saltos de linea pero no consecutivos
 *@param *font, TTF_Font: Fuente a utilizar
 *@param CText, SDL_Color: Color del texto
 *@param CBackgr, SDL_Color: Color del fondo. Es usado solamente si se usa DSHADED|DBACKGR
 *@param flag16, Uint16: Opciones.Determina la calidad y el estilo del texto.Y ademas si tendra o no fondo
 *@param lim, unsigned int: Limite en pixeles que tendra el texto
 *@param x, y , unsigned int: Posiciones xy donde se dibujara el texto
 *
 *@return Devuelve 0 si todo salio bien, o un numero distinto de 0 si salio mal
 *
 *@note Acepta saltos de linea pero no consecutivos. EJ: "hola\n\n\nmundo!" Para solucionarlo
 *		basta con separar los saltos de lineas. EJ: "hola\n \n \nmundo!"
 *
 *@note Solo se imprime el fondo si DSHADED y DBACKGR estan activadas
 *
 ************************************************************************************/

int IprintLim(const char *Text, TTF_Font *font, SDL_Color CText, SDL_Color CBackgr, Uint16 flag16, unsigned int lim, SDL_Surface *paper, unsigned int x, unsigned int y);

/*************************************************************************
 *
 *@summary Ivertical imprime en una superficie un texto de forma vertical
 *
 *@requests SDL, SDL_TTF
 *
 *@version 1.0.5
 *@author Di Paola Martin Pablo
 *@license GPL version 2
 *
 *@param *Text, const char: Texto a escribir. No acepta saltos de linea
 *@param *font, TTF_Font: Fuente a utilizar
 *@param CText, SDL_Color: Color del texto
 *@param CBackgr, SDL_Color: Color del fondo. Es usado solamente si se usa DSHADED|DBACKGR
 *@param flag16, Uint16: Opciones.Determina la calidad y el estilo del texto.Y ademas si tendra o no fondo
 *@param *paper, SDL_Surface: Superficie donde se escribira
 *@param x, y, unsigned int: Posicion xy donde se escribira
 *
 *@return Devuelve 0 si todo salio bien, o distinto de 0 si salio mal
 *
 *@note No acepta saltos de linea
 *
 ************************************************************************************/

int Ivertical(const char *Text, TTF_Font *font, SDL_Color CText, SDL_Color CBackgr, Uint16 flag16, SDL_Surface *paper, unsigned int x, unsigned int y);

/**************************************************************************************
 *
 *@summary Ifun imprime en una superficie un texto de forma ondulante
 *
 *@requests SDL, SDL_TTF y la libreria math (c)
 *
 *@version 1.0.5
 *@author Di Paola Martin Pablo
 *@license GPL version 2
 *
 *@param *Text, const char: Texto a escribir. No acepta saltos de linea
 *@param *font, TTF_Font: Fuente a utilizar
 *@param CText, SDL_Color: Color del texto
 *@param CBackgr, SDL_Color: Color del fondo. Es usado solamente si se usa DSHADED|DBACKGR
 *@param flag16, Uint16: Opciones.Determina la calidad y el estilo del texto.Y ademas si tendra o no fondo
 *@param A, signed int: Es la amplitud y 2A equivale a la altura maxima de las ondas
 *@param P, unsigned int: Es el periodo de la funcion seno.
 *					Cuanto mas grande sea el valor mas lento sera el efecto
 *@param C, unsigned int: Es un valor entre [0;P) que debe ir variando para dar el efecto ondulante.
 *@param *paper, SDL_Surface: Superficie donde se escribira
 *@param x, y, unsigned int: Posicion xy donde se escribira
 *
 *@return Devuelve 0 si todo salio bien, o distinto de 0 si salio mal
 *
 *@note No acepta saltos de linea
 *
 ************************************************************************************/

int Ifun(const char *Text, TTF_Font *font, SDL_Color CText, SDL_Color CBackgr, Uint16 flag16, signed int A, unsigned int P, unsigned int C, SDL_Surface *paper, unsigned int x, unsigned int y);


/**************************************************************************************
 *
 *@summary Iback devuelve una superficie con texto escrito en ella a modo de mascara
 *		   que cubre el fondo hecho de imagenes (no de un color solido) y es el texto el
 *		   que sera trasparente.
 *
 *@requests SDL, SDL_TTF
 *
 *@version 1.0.5
 *@author Di Paola Martin Pablo
 *@license GPL version 2
 *
 *@param *Text, const char: Texto a escribir. No acepta saltos de linea
 *@param *font, TTF_Font: Fuente a utilizar
 *@param CBackgr, SDL_Color: Color del fondo.
 *@param CText, SDL_Color: Color del texto temporal.
 *@param flag16, Uint16: Opciones.
 *@param *source, SDL_Surface: Es la imagen fuente con la que se armara el fondo
 *@param *rectsrc, SDL_Rect: Determina que porcion de la imagen Source se usara para armar el fondo.
 *					En caso de ser NULL, se usara la imagen en su totalidad
 *
 *@return Devuelve SDL_Surface* si todo salio bien, o NULL si salio mal
 *
 *@note No acepta saltos de linea.
 *		Si la imagen contiene el mismo color que CBackgr y esta desactivada la opcion DBACKGR
 *		, la imagen puede verse afectada.
 *		Si la imagen contiene el color CText la imagen podria verse comprometida
 *		Si CBackgr coincide con CText la imagen podria verse comprometida
 *
 *@note Si se usa DBACKGR conviene que CText se asemeje a CBackgr
 *
 ************************************************************************************/

SDL_Surface *Iback(const char *Text, TTF_Font *font, SDL_Color CText, SDL_Color CBackgr, Uint16 flag16, SDL_Surface *source, SDL_Rect *rectsrc);


#endif // ISYS_H_INCLUDED



