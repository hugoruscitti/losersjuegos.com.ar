/*ISYS  I/o SolutYon for Sdl*/

/*Creado por Martin Di Paola, bajo la licencia GPL 2
  Ante cualquier duda, comunicarse al siguiente mail
  petete_zur88@hotmail.com*/

#include <string.h>
#include <math.h>
#include <stdlib.h>

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>


#include "Def_func.h"
#include "Isys.h"

/***********************
 *
 * char strNULL()
 *
 ***************************************************************************************/

int strNULL(const char *s1)
	{
		if(s1==NULL) return 1;
		else if(s1[0]=='\0') return 1;
		else return 0;
	}

/**********************
 *
 * const char *strMN()
 *
 ***************************************************************************************/

const char *strMN(const char *s1, unsigned int start, unsigned int num)
	{
		char *tmp;
		char end=0;
		int i;
		int length;

for(i=start; (i<start+num) && (end==0); i++)
	{
		if(s1[i]=='\0')
			{
			end=1;
			i--;
			}
	}

length=i-start+1;
num=length-1;

		tmp=(char *) malloc(length);

		for(i=start; i<start+num; i++)
			{
				tmp[i-start]=s1[i];
			}
		tmp[num]='\0';

		return tmp;
	}

/****************************
 *
 * SDL_Color ScreateColor()
 *
 *******************************************************************************************/

SDL_Color ScreateColor(Uint8 r, Uint8 g, Uint8 b, Uint8 z)
	{
		SDL_Color tmp={r,g,b,z};
		return tmp;
	}

/****************************
 *
 * SDL_Surface *ScreateSurf()
 *
 *******************************************************************************************/

SDL_Surface *ScreateSurf(unsigned int width, unsigned int height, SDL_Color CBase)
	{
SDL_Surface *src;

	const SDL_VideoInfo *vi=SDL_GetVideoInfo();		//veo la info de la pantalla
src=SDL_CreateRGBSurface(SDL_SWSURFACE|SDL_SRCCOLORKEY, width, height, vi->vfmt->BitsPerPixel, vi->vfmt->Rmask, vi->vfmt->Gmask, vi->vfmt->Bmask, vi->vfmt->Amask);	//crea la superficie con fondo
	SDL_FillRect(src, 0, SDL_MapRGB(src->format, CBase.r, CBase.g, CBase.b));

return src;
	}

/****************************
 *
 * void Sclrscr()
 *
 *******************************************************************************************/

void Sclrscr(SDL_Surface *paper, SDL_Color CBase)
	{
		SDL_Rect rect = {0, 0, paper->w, paper->h};
        Uint32 aux = SDL_MapRGB(paper->format, CBase.r, CBase.g, CBase.b);

        SDL_FillRect(paper, &rect, aux);

	}

/*********************
 *
 * int Ssize()
 *
 *****************************************************************************************/
int Ssize(const char *t_tmp, TTF_Font *font, int *w, int *h, Uint16 flag16)
	{
if(flag16&DTEXT)
	{
		TTF_SizeText( font, t_tmp, w, h ); return 0;
	}
else if(flag16&DUTF8)
	{
		TTF_SizeUTF8( font, t_tmp, w, h ); return 0;
	}
else
	{
		return -1;
	}
	}


/**********************
 *
 * void IdefaultFlag()
 *
 ***************************************************************************************/

void IdefaultFlag(Uint16 *flag16)
	{
	 	Uint16 tmp=0x0000;

if(*flag16&DBOLD)
			{
				tmp|=DBOLD;
			}
		else if(*flag16&DITALIC)
			{
				tmp|=DITALIC;
			}
		else if(*flag16&DUNDERLINE)
			{
				tmp|=DUNDERLINE;
			}
						//por default, DNORMAL
if(*flag16&DSOLID)
			{
				tmp|=DSOLID;
			}
		else if(*flag16&DSHADED)
			{
				tmp|=DSHADED;
			}
		else
			{
				tmp|=DBLENDED;
			}
						//por default, DBLENDED
if(*flag16&DUTF8)
			{
				tmp|=DUTF8;
			}
		else
			{
				tmp|=DTEXT;
			}
						//por default, DTEXT

		if(*flag16&DBACKGR)
			{
				tmp|=DBACKGR;
			}
	*flag16=tmp;
	}

/*************************
 *
 * SDL_Surface *Iwrite()
 *
 *************************************************************************************************/

 SDL_Surface *Iwrite(const char *Text, TTF_Font *font, SDL_Color CText, SDL_Color CBackgr,Uint16 flag16)
	{
	if(flag16&DTEXT)
		{
		if(flag16&DSOLID)
				{
				return TTF_RenderText_Solid(font,Text,CText);		//rapido y feo
				}
			else if(flag16&DBLENDED)
				{
				return TTF_RenderText_Blended(font,Text,CText);		//bonito y lento
				}
			else if(flag16&DSHADED)
				{
				return TTF_RenderText_Shaded(font,Text,CText,CBackgr);	//punto medio
				}
			else
				{
				return NULL;		//error en el flag
				}
		}
	else if(flag16&DUTF8)
		{
			if(flag16&DSOLID)
				{
				return TTF_RenderUTF8_Solid(font,Text,CText);		//rapido y feo
				}
			else if(flag16&DBLENDED)
				{
				return TTF_RenderUTF8_Blended(font,Text,CText);		//bonito y lento
				}
			else if(flag16&DSHADED)
				{
				return TTF_RenderUTF8_Shaded(font,Text,CText,CBackgr);	//punto medio
				}
			else
				{
				return NULL;		//error en el flag
				}
		}
	else
		{
			return NULL; //error en el flag
		}
	}


/******************
 *
 *	int Iprint()
 *
 *******************************************************************************************/
int Iprint(const char *Text, TTF_Font *font, SDL_Color CText, SDL_Color CBackgr, Uint16 flag16, SDL_Surface *paper, unsigned int x, unsigned int y)
	{
	if(strNULL(Text)==1 || font==NULL || paper == NULL ) return -1;		//error en los parametros

IdefaultFlag(&flag16);		//seteo por default en caso de haber un error o de estar incompleto

	SDL_Surface *src;
	SDL_Rect rect;

	TTF_SetFontStyle(font, flag16);

		if((src=Iwrite(Text, font, CText, CBackgr, flag16))==NULL) return -2; //escribo

rect.x=x;
rect.y=y;
rect.w=src->w;
rect.h=src->h;

			//eliminamos el fondo SOLO SI la opcion DSHADED esta activada y DBACKGR no
			//SI DSHADED y DBACKGR estan activadas se dibuja el fondo
			//SI la opcion no es DSHADED, no hay fondo que dibujar
	if((flag16&DSHADED) && !(flag16&DBACKGR)) SDL_SetColorKey(src,SDL_SRCCOLORKEY|SDL_RLEACCEL, SDL_MapRGB(src->format,CBackgr.r,CBackgr.g,CBackgr.b));
	SDL_BlitSurface(src,NULL,paper,&rect);	//dibujamos en el papel
	SDL_FreeSurface(src);
	return 0;		//exito
	}


/**************************
 *
 *	SDL_Surface *Iprint()
 *
 *******************************************************************************************/
/*
SDL_Surface *Iprint(char *Text, TTF_Font *font, SDL_Color CText, SDL_Color CBackgr, Uint16 flag16)
	{
	if(strNULL(Text)==1 || font==NULL) return NULL;	//error en los parametros

IdefaultFlag(&flag16);		//seteo por default en caso de haber un error o de estar incompleto

	SDL_Surface *src;
	int width;					//ancho de la superficie a crear si DSHADED esta desactivada
	int height;					//alto de la superficie a crear si DSHADED esta desactivada

	TTF_SetFontStyle(font, flag16);

	//SI DSHADED esta activada, la funcion termina dentro del segundo IF, pero si no esta activada
	//(DSOLID o DBLENDED), y la opcion DBACKGR esta activada, se debera crear una nueva
	//superficie para crear el fondo

	if((src=Iwrite(Text, font, CText, CBackgr, flag16))==NULL) return NULL; //escribo

	if(flag16&DSHADED)
		{
			if(!(flag16&DBACKGR)) SDL_SetColorKey(src,SDL_SRCCOLORKEY|SDL_RLEACCEL, SDL_MapRGB(src->format,CBackgr.r,CBackgr.g,CBackgr.b));

		return src;
		}

//SI DBACKGR esta desactivada, se regresa la superficie sin fondo
if(!(flag16&DBACKGR)) return src;

//En caso de querer un fondo, con DBACKGR activada

	width=src->w;
	height=src->h;		//extraigo el ancho y el alto de src y luego la libero
	SDL_FreeSurface(src);

src=ScreateSurf(width, height, CBackgr);		//creo la superficie
//Listo, src es una superficie con fondo de color CBackgr lista para imprimirle el texto

Iprint(Text, font, CText, CBackgr, flag16, src, 0, 0);

	return src;
	}

*/
/**********************
 *
 * int IprintLim()
 *
 ********************************************************************************************/

int IprintLim(const char *Text, TTF_Font *font, SDL_Color CText, SDL_Color CBackgr, Uint16 flag16, unsigned int lim, SDL_Surface *paper, unsigned int x,unsigned int y)
	{

	if(strNULL(Text)==1 || font==NULL || paper == NULL) return -1;	//error en los parametros

IdefaultFlag(&flag16);		//seteo por default en caso de haber un error o de estar incompleto

	const char *t_tmp;


	SDL_Surface *src;
	SDL_Rect rect;
	int w, h;		//ancho y alto
	int n=0;
	int m=0;
	int line=0;
	int length=strlen(Text);

	do
		{
		n++;
		t_tmp=strMN(Text, m, n);
if((Ssize(t_tmp, font, &w, &h, flag16))!=0) return -3;	//tomo las medidas del texto
		free((void *)(t_tmp));		//libero la memoria. MUY IMPORTANTE!!!

		if(Text[m+n-1]=='\n' || w>lim || length==(n+m))
			{
			if(w>lim || Text[m+n-1]=='\n')
				{
				n--;
				}

			t_tmp=strMN(Text, m, n);
			TTF_SetFontStyle(font, flag16);

	if((src=Iwrite(t_tmp, font, CText, CBackgr, flag16))==NULL) return -2;	//escribo una letra

			rect.x=x;
			rect.y=y+(line*TTF_FontLineSkip(font));
			rect.w=src->w;
			rect.h=src->h;

//borro el fondo
	if((flag16&DSHADED)&& !(flag16&DBACKGR)) SDL_SetColorKey(src,SDL_SRCCOLORKEY|SDL_RLEACCEL, SDL_MapRGB(src->format,CBackgr.r,CBackgr.g,CBackgr.b));

			SDL_BlitSurface(src,NULL,paper,&rect);
			SDL_FreeSurface(src);
			if(Text[m+n]=='\n') m++;
			m+=n;
			n=0;
			line++;
			free((void *)(t_tmp));		//libero la memoria. MUY IMPORTANTE!!!
			}
		}while(m!=length);	//continuo con la siguiente linea hasta que no haya mas letras

		return 0;		//exito
	}

/********************
 *
 * int Ivertical()
 *
 **********************************************************************************************/

int Ivertical(const char *Text, TTF_Font *font, SDL_Color CText, SDL_Color CBackgr, Uint16 flag16, SDL_Surface *paper, unsigned int x, unsigned int y)
	{
	if(strNULL(Text)==1 || font==NULL || paper == NULL ) return -1;		//error en los parametros

IdefaultFlag(&flag16);		//seteo por default en caso de haber un error o de estar incompleto

	SDL_Surface *img;
	SDL_Rect rect;

TTF_SetFontStyle(font, flag16);

	int i=0;
	int heigth=TTF_FontLineSkip(font);
	const char *aux;		//puntero auxiliar


	while(Text[i]!='\0')
	{
aux=strMN(Text, i, 1);

	if((img=Iwrite( aux, font, CText, CBackgr, flag16))==NULL) return -2;	//escribo una letra

free((void *)(aux));		//libero la memoria. MUY IMPORTANTE!!!
	rect.x=x;
	rect.y=y+(i*heigth);
	rect.w=img->w;
	rect.h=img->h;

if((flag16&DSHADED)&&!(flag16&DBACKGR)) SDL_SetColorKey(img,SDL_SRCCOLORKEY|SDL_RLEACCEL, SDL_MapRGB(img->format,CBackgr.r,CBackgr.g,CBackgr.b));

	SDL_BlitSurface(img,NULL,paper,&rect);
	SDL_FreeSurface(img);
	i++;
	}
	return 0;		//exito
	}





/**********************
 *
 * int Ifun()
 *
 ******************************************************************************************/


int Ifun(const char *Text, TTF_Font *font, SDL_Color CText, SDL_Color CBackgr, Uint16 flag16, int A, unsigned int P, unsigned int C, SDL_Surface *paper, unsigned int x, unsigned int y)
	{
	if(strNULL(Text)==1 || font==NULL || paper == NULL ) return -1;	//error en los parametros

IdefaultFlag(&flag16);		//seteo por default en caso de haber un error o de estar incompleto

	int width=0;
	float B=6.28/P;		// 2PI/periodo
	int i;
	int length=strlen(Text);
	SDL_Surface *img;
	SDL_Rect rect;
	const char *aux;		//puntero auxiliar

	TTF_SetFontStyle(font, flag16);


	for(i=0; i<length; i++)
		{
	aux=strMN(Text, i, 1);
		if((img=Iwrite(aux, font, CText, CBackgr, flag16))==NULL) return -2; //escribo una letra
	free((void *)(aux));		//libero la memoria. MUY IMPORTANTE!!!

		if((flag16&DSHADED)&&!(flag16&DBACKGR)) SDL_SetColorKey(img,SDL_SRCCOLORKEY|SDL_RLEACCEL, SDL_MapRGB(img->format,CBackgr.r,CBackgr.g,CBackgr.b));

		rect.x=x+width;
		rect.y=(int)(A*sin(B*(rect.x+C)))+y;		//formula para dar el efecto ondulante!!
		rect.h=img->h;
		rect.w=img->w;

		SDL_BlitSurface(img, NULL, paper, &rect);

		width+=rect.w;
		SDL_FreeSurface(img);
		}

	return 0;		//exito
	}

/*************************
 *
 * SDL_Surface *Iback()
 *
 ***************************************************************************************/

SDL_Surface *Iback(const char *Text, TTF_Font *font, SDL_Color CText, SDL_Color CBackgr, Uint16 flag16, SDL_Surface *source, SDL_Rect *rectsrc)
	{

if((strNULL(Text)==1) || (font==NULL) || (source==NULL)) return NULL;		//error en los parametros

IdefaultFlag(&flag16);		//seteo por default en caso de haber un error o de estar incompleto

	SDL_Surface *tmp;
	SDL_Surface *text_tmp;
	SDL_Surface *img_tmp;

		int width_text, height_text;		//ancho y alto del texto
		int width_src, height_src;			//ancho y alto del source
		int rows, cols;

		int i,j;

		SDL_Rect rectdst;

TTF_SetFontStyle(font, flag16);
text_tmp=Iwrite(Text, font, CText, CBackgr, flag16);	//creo el texto temporal

		width_text=text_tmp->w;		//tomo el ancho y alto del texto
		height_text=text_tmp->h;

img_tmp=ScreateSurf(width_text, height_text, CBackgr);			//creo una superficie temporal

SDL_BlitSurface(text_tmp, NULL, img_tmp, NULL);		//pego el texto temporal en la superficie temporal
SDL_UpdateRect(img_tmp, 0, 0, width_text, height_text);	//ahora, img_tmp contiene el texto y un fondo

SDL_FreeSurface(text_tmp);

if(rectsrc==NULL) 			//tomo el ancho y el alto de la imagen
	{
		width_src=source->w;
		height_src=source->h;
	}
else
	{
		width_src=rectsrc->w;
		height_src=rectsrc->h;
	}


		rows=((int)(height_text/height_src))+1;		//obtengo la cantidad de imagenes "sources"
		cols=((int)(width_text/width_src))+1;		//necesarias para cubrir el texto

	tmp=ScreateSurf(width_text, height_text, CText);	//creo la superficie


for(i=0; i<rows; i++)		//imprimo source en tmp para crear el fondo de tmp
	{
		for(j=0; j<cols; j++)
			{
			rectdst.x=j*width_src;
			rectdst.y=i*height_src;

			SDL_BlitSurface(source, rectsrc, tmp, &rectdst);

			}
	}



SDL_SetColorKey(img_tmp,SDL_SRCCOLORKEY|SDL_RLEACCEL, SDL_MapRGB(img_tmp->format,CText.r,CText.g,CText.b));

SDL_BlitSurface(img_tmp, NULL, tmp, NULL);
SDL_FreeSurface(img_tmp);

SDL_UpdateRect(tmp, 0, 0, width_text, height_text);

if(!(flag16&DBACKGR)) SDL_SetColorKey(tmp,SDL_SRCCOLORKEY|SDL_RLEACCEL, SDL_MapRGB(tmp->format,CBackgr.r,CBackgr.g,CBackgr.b));

return tmp;
	}

