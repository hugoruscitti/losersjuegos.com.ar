/*
 * Copyright (C) 2006 Hugo Ruscitti
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "gestor_figuras.h"

/*!
 * \brief Genera una instancia de la clase
 */
GestorFiguras :: GestorFiguras ()
{
	n_figuras = 0;
}

/*!
 * \brief Libera los recursos asignados
 */
GestorFiguras :: ~GestorFiguras ()
{
	int i;

	for (i = 0; i < n_figuras; i ++)
		delete figuras [i];
}


/*!
 * \brief A�ade otra figura a la colecci�n de figuras
 * \param nueva puntero a la figura (en caso de error se elimina)
 */
void GestorFiguras :: agregar_figura (Figura * nueva)
{
	if (n_figuras < MAX_FIGURAS)
	{
		figuras [n_figuras] = nueva;
		n_figuras ++;
	}
	else
	{
		printf ("Imposible a�adir otra figura, se especific� un "
				"l�mite m�ximo de %d figuras\n", MAX_FIGURAS);

		printf ("(se elimina la instancia de esa figura)\n");
		
		delete nueva;
	}
}


/*!
 * \brief Imprime todas las figuras en pantalla
 * \param screen superficie destino
 */
void GestorFiguras :: imprimir (SDL_Surface * screen)
{
	int i;

	// imprime todas las figuras en pantalla
	for (i = 0; i < n_figuras; i ++)
		figuras [i]->imprimir (screen);
	
}


/*!
 * \brief Retorna la figura que se puede arrrastrar pulsando en (x; y)
 * \param x posici�n horizontal del mouse
 * \param y posici�n vertical del mouse
 * \return figura que se puede seleccionar o NULL
 */
Figura * GestorFiguras :: seleccionar_figura (int x, int y)
{
	int i;

	for (i = 0; i < n_figuras; i ++)
	{
		if (figuras [i]-> se_puede_arrastrar (x, y))
			return figuras [i];
	}

	// ninguna figura se puede seleccionar pulsando en (x, y)
	return NULL;
}
