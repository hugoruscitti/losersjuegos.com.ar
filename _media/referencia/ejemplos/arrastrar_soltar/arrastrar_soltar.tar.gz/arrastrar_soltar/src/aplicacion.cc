/*
 * Copyright (C) 2006 Hugo Ruscitti
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "aplicacion.h"
#include <stdlib.h>

/*!
 * \brief Inicia todos los recursos del programa
 */
Aplicacion :: Aplicacion ()
{
	if (SDL_Init (0))
	{
		printf ("Error: %s\n", SDL_GetError ());
		exit (1);
	}

	screen = SDL_SetVideoMode (320, 240, 16, SDL_SWSURFACE);

	if (! screen)
	{
		printf ("Error: %s\n", SDL_GetError ());
		exit (1);
	}

	mouse = new Mouse (& figuras);
	
	SDL_WM_SetCaption ("Arrastrar y soltar", NULL);

	figuras.agregar_figura (new Figura (100, 100, "../ima/face.png"));
	figuras.agregar_figura (new Figura (200, 10, "../ima/mail.png"));
	figuras.agregar_figura (new Figura (200, 100, "../ima/cd.png"));
	figuras.agregar_figura (new Figura (10, 10, "../ima/office.png"));
}


/*!
 * \brief Libera recursos
 */
Aplicacion :: ~Aplicacion ()
{
	delete mouse;

	SDL_Quit ();
}

/*!
 * \brief Contiene el bucle principal del programa, desde aqu� se capturan y 
 * notifican todos los eventos.
 */
void Aplicacion :: ejecutar (void)
{
	SDL_Event eventos;
	bool salir = false;


	while (! salir)
	{
		imprimir_pantalla ();

		// Detiene el programa hasta que recibe un evento
		if (SDL_WaitEvent (& eventos))
		{
			switch (eventos.type)
			{
				case SDL_QUIT:
					salir = true;
					break;

				case SDL_MOUSEMOTION:
					mouse->mover (eventos.motion.x, 
							eventos.motion.y);
					break;

				case SDL_MOUSEBUTTONDOWN:
					mouse->pulsa_boton ();
					break;
					
				case SDL_MOUSEBUTTONUP:
					mouse->suelta_boton ();
					break;
					
				default:
					break;
			}
		}
		else
		{
			printf ("Ocurri� un error: %s\n", SDL_GetError ());
			salir = true;
		}
	}
}

/*!
 * \brief Actualiza la pantalla del programa
 */
void Aplicacion :: imprimir_pantalla (void)
{
	SDL_FillRect (screen, NULL, SDL_MapRGB(screen->format, 200, 200, 200));
	
	figuras.imprimir (screen);

	SDL_Flip (screen);
}
