/*
 * Copyright (C) 2006 Hugo Ruscitti
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "SDL_image.h"
#include "figura.h"


/*!
 * \brief Genera una instancia de figura
 * \param x posici�n horizontal
 * \param y posici�n vertical
 * \param ruta_imagen ruta hacia el archivo que contiene la im�gen a mostrar
 */
Figura :: Figura (int x, int y, char * ruta_imagen)
{
	imagen = IMG_Load (ruta_imagen);

	if (! imagen)
	{
		printf ("Imposible cargar la imagen: %s\n", SDL_GetError ());
		printf ("(la figura ser� invisible)\n");
	}

	definir_eje (0, 0);
	this->mover (x, y);
}

/*!
 * \brief Libera los recursos utilizados
 */
Figura :: ~Figura ()
{
	if (imagen)
		SDL_FreeSurface (imagen);
}

/*!
 * \brief Muestra la figura sobre una superficie
 * \param screen superficie destino
 */
void Figura :: imprimir (SDL_Surface * screen)
{
	SDL_Rect rect = {x, y, 0, 0};
	
	if (imagen)
		SDL_BlitSurface (imagen, NULL, screen, &rect);
}

/*!
 * \brief altera la posici�n de la figura
 * \param x nueva posici�n horizontal
 * \param y nueva posici�n vertical
 */
void Figura :: mover (int x, int y)
{
	this->x = x - eje_x;
	this->y = y - eje_y;
}


/*!
 * \brief Determina si el puntero del mouse puede seleccionar a la figura
 * \param x posici�n horizontal del mouse
 * \param y posici�n vertical del mouse
 * \return true si puede seleccionarlo, false en caso contrario
 */
bool Figura :: se_puede_arrastrar (int x, int y)
{
	if (imagen)
	{
		int borde_izquierdo = this->x;
		int borde_derecho = this->x + imagen->w;
		int borde_superior = this->y;
		int borde_inferior = this->y + imagen->h;
		
		if (x > borde_izquierdo && x < borde_derecho \
				&& y > borde_superior && y < borde_inferior)
			return true;
	}

	return false;
}

/*!
 * \brief Define cual debe ser el punto de control al momento de imprimir la 
 * figura en pantalla
 * \param x nueva posici�n horizontal del eje
 * \param y nueva posici�n vertical del eje
 */
void Figura :: definir_eje (int x, int y)
{
	eje_x = x;
	eje_y = y;
}

/*!
 * \brief Se le notifica que el mouse ha seleccionado a la figura desde el 
 * punto (x; y)
 * \param x posici�n horizontal del mouse
 * \param y posici�n vertical del mouse
 */
void Figura :: seleccionar (int x, int y)
{
	definir_eje (x - this->x, y - this->y);
}
