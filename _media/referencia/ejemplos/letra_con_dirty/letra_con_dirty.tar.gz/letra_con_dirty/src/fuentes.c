/*
 * Copyright (C) 2006 Gabriel Valentin
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "fuentes.h"


int fuentes_iniciar (Fuentes * fuentes)
{
	int indice = buscar_letra ('a');
	
	fuentes->fuente = fuentes_obtener_rect (fuentes->imagen, indice, 9, 14);

	fuentes->movimiento.w = (fuentes->fuente).w;
	fuentes->movimiento.h = (fuentes->fuente).h;
	fuentes->movimiento.x = 10;
	fuentes->movimiento.y = 10;
}


void fuentes_mover (SDL_Rect * rectangulo)
{
	static int velocidad = 0;
	static int direccion = 1;
	static int limite_derecho = 300;
	
	velocidad ++; 
	rectangulo->y += velocidad >> 2;
	rectangulo->x += direccion * 1;

	if (rectangulo->x > limite_derecho || rectangulo->x < 0 )
		direccion *= -1;

	if (rectangulo->y > 200)
		velocidad = -30;
		
}


void fuentes_imprimir (Juego * juego)
{
	   
	SDL_BlitSurface ((juego->fuentes).imagen,& ((juego->fuentes).fuente), 
				 (juego->dirty).screen,& ((juego->fuentes).movimiento));

	dirty_agregar (& (juego->dirty),& ((juego->fuentes).movimiento));
}


SDL_Rect fuentes_obtener_rect (SDL_Surface * ima, int indice, 
			 int columnas, int filas)
{
	SDL_Rect rectangulo;

	rectangulo.w = ima->w / columnas; 
	rectangulo.h = ima->h / filas;
	rectangulo.x = (indice % columnas) * rectangulo.w;
	rectangulo.y = (indice / columnas) * rectangulo.h;

	return rectangulo;
}
