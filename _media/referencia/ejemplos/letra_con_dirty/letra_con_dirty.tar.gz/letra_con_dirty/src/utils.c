/*
 * Copyright (C) 2006 Gabriel Valentin
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "utils.h"

#define COLOR 255, 255, 255

void iniciar_sdl (Juego * juego)
{
	SDL_Init (SDL_INIT_VIDEO);
	
	(juego->dirty).screen = SDL_SetVideoMode (320, 240, 16, SDL_SWSURFACE);
	
	(juego->dirty).fondo = crear_fondo ((juego->dirty).screen);
	
	SDL_FillRect ((juego->dirty).fondo, NULL, 
				 SDL_MapRGB ((juego->dirty).fondo->format, COLOR));

	SDL_BlitSurface ((juego->dirty).fondo, NULL, (
					    juego->dirty).screen, NULL);

	SDL_Flip ((juego->dirty).screen);

}


SDL_Surface * crear_fondo (SDL_Surface * screen)
{
	SDL_Surface * fondo;
	
	fondo = SDL_CreateRGBSurface (SDL_HWSURFACE, 640, 480, 16, 0, 0, 0,0);

	fondo = SDL_DisplayFormat (screen);

	return fondo;
}


SDL_Surface * cargar_imagen (char * ruta)
{
	SDL_Surface * imagen;
	
	imagen = SDL_LoadBMP (ruta);

	return imagen;
}


int salir (void)
{
	SDL_Event evento;
	
	while( SDL_PollEvent ( &evento) )
	{
		if (evento.type == SDL_QUIT)
			return 0;
		
		if (evento.key.keysym.sym == SDLK_q)
			return 0;
	}
	return 1;
}


int buscar_letra (char letra)
{
	char vector [] = "abcdefghijklmnopqrstuvwxyz"\
		   "ABCDEFGHIJKLMNOPQRSTUVWXYZ"\
		   "123456789";
	int i;

	for (i = 0; vector [i] != letra; i++);

	return i;
		   
}

