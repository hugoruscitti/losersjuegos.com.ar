/*
 * Copyright (C) 2006 Gabriel Valentin
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "dirty.h"

void dirty_iniciar (Dirty * dirty)
{
	dirty->lim_anteriores = 0;
	dirty->lim_actuales = 0;
}

void dirty_limpiar (Dirty * dirty)
{
	int i = 0;
	
	for (i = 0; i < dirty->lim_anteriores ; i++)
		SDL_BlitSurface (dirty->fondo, dirty->anteriores + i
					 , dirty->screen, dirty->anteriores + i);

}

void dirty_agregar (Dirty * dirty, SDL_Rect * rectangulo)
{
	dirty->actuales [dirty->lim_actuales ++] = * rectangulo;
}


void dirty_imprimir (Dirty * dirty)
{
	SDL_Rect todos [300];
	int i = 0, j;
	int lim_todos = 0;

	for (; i < dirty->lim_anteriores; i++)
		todos [i] = dirty->anteriores [i];	

	for (j = 0; j < dirty->lim_actuales; i++, j++)
		todos [i] = dirty->actuales [j];
	
	SDL_UpdateRects (dirty->screen, i, todos);
	
	dirty_reiniciar (dirty);
}

void dirty_reiniciar (Dirty * dirty)
{
	int i = 0;

	for (; i < dirty->lim_actuales; i ++)
		dirty->anteriores [i] = dirty->actuales [i];
			   
	dirty->lim_anteriores = dirty->lim_actuales;
	dirty->lim_actuales = 0;
}
