# -*- coding: utf-8 -*-
# Copyright 2006 Hugo Ruscitti <hugoruscitti@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Scribes; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA

import pygame
from pygame.locals import *

class State:
    "Representaci�n abstracta de un estado de personaje"
    
    def __init__ (self, player):
        self.player = player

    def update (self):
        pass

class Jumping (State):
    "Representa el estado 'saltando'"
    
    def __init__ (self, player, vy):
        "Inicia un salto con velocidad inicial indicada por el parametro vy"
        
        State.__init__ (self, player)
        self.player.animation.set_frames ([5])
        self.vy = vy
    
    def update (self):
        self.vy = self.vy + 0.1
        dy = int (self.vy)
        keys = pygame.key.get_pressed ()
        
        if dy > 0:
            dy = self.player.stage.get_floor_dist (self.player.x, self.player.y, int (self.vy))
            
            "Ha tocado el suelo"
            if dy == 0 and int (self.vy) != 0:
                self.player.change_state (Normal (self.player))

        if keys [K_LEFT]:
            self.player.move_ip (-2, 0)
            self.player.set_flip (True)
        elif keys [K_RIGHT]:
            self.player.move_ip (2, 0)
            self.player.set_flip (False)

        self.player.move_ip (0, dy)


class Normal (State):
    "Representa el comportamiento del personaje cuando este est� parado sin realizar acciones"
    
    def __init__ (self, player):
        State.__init__ (self, player)
        self.player.animation.set_frames ([0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 2, 1])
    
    def update (self):
        keys = pygame.key.get_pressed ()
        
        if keys [K_UP]:
            self.player.change_state (Jumping (self.player, - 4))
        elif keys [K_LEFT] or keys [K_RIGHT]:
            self.player.change_state (Running (self.player))
        


class Running (State):
    "Controla al personaje mientras corre por el escenario"
    
    def __init__ (self, player):
        State.__init__ (self, player)
        self.player.animation.set_frames ([3, 4])
    
    def update (self):
        keys = pygame.key.get_pressed ()
        
        if keys [K_LEFT]:
            self.player.move_ip (-2, 0)
            self.player.set_flip (True)
        elif keys [K_RIGHT]:
            self.player.move_ip (2, 0)
            self.player.set_flip (False)
        else:
            self.player.change_state (Normal (self.player))

        if keys [K_UP]:
            self.player.change_state (Jumping (self.player, - 4))
        
        "si no se encuentra sobre una plataforma comienza a caer"
        if self.player.stage.get_floor_dist (self.player.x, self.player.y, 1) == 1:
            self.player.change_state (Jumping (self.player, 0))