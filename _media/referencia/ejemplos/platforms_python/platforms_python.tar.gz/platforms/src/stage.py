# -*- coding: utf-8 -*-
# Copyright 2006 Hugo Ruscitti <hugoruscitti@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Scribes; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA

from engine.animation import Animation
import pygame


class Stage:
    "Representa un escenario con plataformas que el jugador puede 'pisar'"
    
    def __init__ (self):
        "Genera los bloques de plataformas"
        map_source = [
        '                                        ',
        '                                        ',
        '                                        ',
        '                                        ',
        '                                        ',
        '                                        ',
        '                                        ',
        '                                        ',
        '                                        ',
        '                                        ',
        '                                        ',
        '                                        ',
        '                                        ',
        '                                        ',
        '               [:.]                     ',
        '                                        ',
        '                                        ',
        '            [.:.:.]                     ',
        '                                        ',
        '                    [:.]                ',
        '                                        ',
        '                                        ',
        '                    [:.:.:.:.:.]        ',
        '                                        ',
        '            [:.:.:.]                    ',
        '                                        ',
        '        [.:.:.:.:.]                     ',
        '                                        ',
        '........................................',
        '========================================',
        ]

        chars=" []:.="
        self.tile_map = [ [ chars.index(n)-1 for n in l ] for l in map_source ]
        self.animation = Animation ('tiles.png', -1, 1, 6)
    
    def draw (self, dst):
        "Imprime todo el escenario sobre la superficie 'dst'"
        
        dst.fill ((200,  200,  200))
        x = 0
        y = 0
        for row in self.tile_map:
            for tile_number in row:
                if tile_number != -1:
                    self.animation.draw_frame (dst, tile_number, x, y)
                x = x + 16
            x = 0
            y = y + 16
    
    def get_floor_dist (self, x, y, max):
        "Obtiene la distancia entre el punto (x, y) y el proximo bloque solido hacia abajo"
        
        for dy in xrange (max):
            if (y + dy) % 16 == 0 and self.tile_map [(y + dy) / 16] [x / 16] != -1:
                return dy
        
        return max
