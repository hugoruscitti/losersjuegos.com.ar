# -*- coding: utf-8 -*-
# Copyright 2006 Hugo Ruscitti <hugoruscitti@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Scribes; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA

import engine.game
from engine.scene import Scene
from engine.fps import Fps
from stage import Stage
import player
import pygame

class Platform (Scene):
    "Representa un escenario con plataformas y un personaje que se puede controlar con el teclado"
    
    def __init__ (self, game):
        "Inicia el nivel con algunas plataformas y el personaje"
        
        Scene.__init__ (self)
        self.sprites = pygame.sprite.RenderUpdates ()
        self.stage = Stage ()
        player_1 = player.Player ((30, 30), self.stage)
        self.sprites.add (player_1)
        fps = Fps (game.clock)
        self.sprites.add (fps)
        self.create_background ()
    
    def create_background (self):
        self.background = pygame.display.get_surface ().convert ()
        self.stage.draw (self.background)
    
    def update (self):
        "Actualiza la logica de la escena"
        
        self.sprites.update ()
    
    def draw (self, screen, display):
        "Imprime todos los objetos en pantalla"
        
        self.sprites.clear (screen, self.background)
        display.update (self.sprites.draw (screen))

    def entire_draw (self, screen):
        screen.blit (self.background, (0, 0))
        pass

    def terminate (self):
        "Libera los recursos de la escena"
        pass
    
if __name__ == '__main__':
    game = engine.game.Game ('Ejemplo de plataformas', 'Hugo Ruscitti', fps = 100)
    plataform = Platform (game)
    game.change_scene (plataform)
    game.run ()
