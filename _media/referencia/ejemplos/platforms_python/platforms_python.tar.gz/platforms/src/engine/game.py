# -*- coding: utf-8 -*-
# Copyright 2006 Hugo Ruscitti <hugoruscitti@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Scribes; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA

import pygame
from pygame.locals import *


class Game:
    "Gestiona el bucle principal de un videojuego junto con el intercambio de escenas"
    
    def __init__ (self, title, author = None, width = 640, height = 480, bpp = 16, mode = SWSURFACE, debug = False, fps = 70):
        "Inicia la ventana principal y los recursos basicos"
        
        pygame.init ()
        self.screen = pygame.display.set_mode ((width, height), mode, bpp)
        self.clock = pygame.time.Clock ()
        
        
        if author:
            caption = title + ' by ' + author
        else:
            caption = title
        
        pygame.display.set_caption (caption)
        self.quit = False
        self.fps = fps
        self.scene = None

    def change_scene (self, new_scene):
        "Intercambia la escena actual del juego"
        
        if self.scene:
            self.scene.terminate ()
        self.scene = new_scene
        self.scene.entire_draw (self.screen)
        pygame.display.flip ()

    def run (self):
        "Inicia el bucle principal del programa"
        
        while not self.quit:
            
            for event in pygame.event.get ():
                if event.type == QUIT:
                    self.do_quit ()
            
            self.clock.tick (self.fps)
            
            self.scene.update ()
            self.scene.draw (self.screen, pygame.display)
        
        if self.scene:
            self.scene.terminate ()

    def do_quit (self):
        "Termina de ejecutar el programa"
        
        self.quit = True