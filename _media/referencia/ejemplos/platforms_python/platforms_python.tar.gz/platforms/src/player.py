# -*- coding: utf-8 -*-
# Copyright 2006 Hugo Ruscitti <hugoruscitti@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Scribes; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301
# USA

from pygame.sprite import Sprite
from engine.animation import Animation
import pygame
import states
from pygame.locals import *

class Player (Sprite):
    "Reprensenta a un personaje animado que controla el jugador mediante el teclado"
    
    def __init__ (self, position, stage):
        "Carga los recursos principales para comenzar el juego"
        
        Sprite.__init__ (self)
        self.animation = Animation ('red_alien.png', -1, 1, 8)
        
        self.set_hotspot (26, 74)
        self.rect = self.animation.get_rect ()
        self.flip = False
        self.set_flip (False)
        self.stage = stage
        self.move (50, 50)
        self.change_state (states.Jumping (self, 0))
    
    def update (self):
        "Actualiza el comportamiento del personaje"
        
        self.state.update ()
        self.animation.advance ()
        self.image = self.animation.get_actual_frame (self.flip)
        

    def change_state (self, state):
        self.state = state

    def set_hotspot (self, x, y):
        "Define cual ser� el eje de representaci�n del personaje (generalmente los pies del protagonista)"
        
        self.hotspot_x = x
        self.hotspot_y = y

    def move (self, x, y):
        "Intenta desplazar al personaje a una posici�n absoluta (x, y) sin exceder los bordes de pantalla"
        
        if x < 10:
            x = 10
        elif x > 630:
            x = 630
        self.x = x
        self.y = y
        self.rect.x = x - self.hotspot_x
        self.rect.y = y - self.hotspot_y
        
    def move_ip (self, dx, dy):
        "Realiza un desplazamiento del personaje en el escenario"
        
        self.move (self.x + dx, self.y + dy)
        
    
    def set_flip (self, new):
        "Invierte el grafico que representa al personaje de manera horizontal"
        
        if self.flip == new:
            return
        
        self.flip = new