/*
 * Copyright (C) 2006 Hugo Ruscitti
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "utils.h"

SDL_Surface * iniciar_sdl (int w, int h, char * titulo)
{
	int flags = SDL_SWSURFACE;
	SDL_Surface * screen;

	if (SDL_Init (SDL_INIT_VIDEO) == -1)
	{
		printf ("%s\n", SDL_GetError ());
		return NULL;
	}

	atexit (SDL_Quit);

	SDL_WM_SetCaption (titulo, NULL);
	
	screen = SDL_SetVideoMode (w, h, 16, flags);
	
	if (! screen)
	{
		printf ("%s\n", SDL_GetError ());
		return NULL;
	}

	SDL_FillRect (screen, NULL, SDL_MapRGB (screen->format, 200, 200, 200));
	
	return screen;
}


void put_pixel(SDL_Surface *_ima, int x, int y, Uint32 pixel)
{
	int bpp = _ima->format->BytesPerPixel;
	Uint8 *p = (Uint8 *)_ima->pixels + y * _ima->pitch + x*bpp;

	switch (bpp)
	{
		case 1:
			*p = pixel;
			break;
			
		case 2:
			*(Uint16 *)p = pixel;
			break;
			
		case 3:
			if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
			{
				p[0]=(pixel >> 16) & 0xff;
				p[1]=(pixel >> 8) & 0xff;
				p[2]=pixel & 0xff;
			}
			else
			{
				p[0]=pixel & 0xff;
				p[1]=(pixel >> 8) & 0xff;
				p[2]=(pixel >> 16) & 0xff;
			}
			break;
			
		case 4:
			*(Uint32 *) p = pixel;
			break;
	}
}

void get_pixel_color (SDL_Surface * imagen, int x, int y, SDL_Color * color)
{
	int bpp = imagen->format->BytesPerPixel;
	Uint8 *p = (Uint8 *)imagen->pixels + y * imagen->pitch + x * bpp;

	SDL_GetRGBA (* (Uint32 *) p, imagen->format, 
			&(color->r), 
			&(color->g), 
			&(color->b),
			&(color->unused)
			);
}

void set_pixel_color (SDL_Surface * imagen, int x, int y, SDL_Color * color)
{
	Uint32 pixel;
	
	pixel = SDL_MapRGBA (imagen->format, color->r, color->g, color->b, 
			color->unused);

	put_pixel (imagen, x, y, pixel);
}
