/*
 * Copyright (C) 2006 Hugo Ruscitti
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _UTILS_H
#define _UTILS_H

#include "SDL.h"
#include <stdlib.h>

SDL_Surface * iniciar_sdl (int w, int h, char * titulo);
void put_pixel(SDL_Surface *_ima, int x, int y, Uint32 pixel);
Uint32 get_pixel (SDL_Surface *surface, int x, int y);
void get_pixel_color (SDL_Surface * imagen, int x, int y, SDL_Color * color);
void set_pixel_color (SDL_Surface * imagen, int x, int y, SDL_Color * color);

#endif
