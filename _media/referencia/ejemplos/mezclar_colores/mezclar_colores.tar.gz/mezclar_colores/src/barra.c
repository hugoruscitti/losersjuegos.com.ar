/*
 * Copyright (C) 2006 Hugo Ruscitti
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "barra.h"

void barra_iniciar (Barra * barra, int x, int y, int w, int valor_minimo, 
		int valor_maximo, Uint32 color)
{
	barra->x = x;
	barra->y = y;
	barra->w = w;
	barra->valor_minimo = valor_minimo;
	barra->valor_maximo = valor_maximo;
	barra->color = color;
	barra->valor_actual = (valor_maximo + valor_minimo) / 2;
}


void barra_imprimir (Barra * barra, SDL_Surface * screen)
{
	SDL_Rect linea = {barra->x, barra->y, barra->w, 2};
	SDL_Rect cursor;
	SDL_Rect regla = {barra->x + barra->w / 2, barra->y - 2, 1, 6};
	int x;
	int ancho;

	/* imprime la linea horizontal y el punto medio de la misma */
	SDL_FillRect (screen, & linea, 0);
	SDL_FillRect (screen, & regla, 0);
	
	/* imprime el cursor que se desplaza en la barra. Para esto se
	 * deben transladar el `valor_actual` entre 
	 * [valor_minimo y valor_maximo] a la coordenada proporcional 
	 * `x`, entre [barra->x y barra->x + barra->w]
	 */
	ancho = barra->valor_maximo - barra->valor_minimo;
	x = (barra->w * (barra->valor_actual - barra->valor_minimo)) / ancho;
	
	cursor.x = barra->x + x - 4;
	cursor.y = barra->y - 6;
	cursor.w = 8;
	cursor.h = 12;
	
	SDL_FillRect (screen, & cursor, barra->color);
}

void barra_on_click (Barra * barra, int x, int y)
{
	/* intenta determinar si se ha pulsado sobre este componente. En
	 * caso contrario ignora el evento */
	if (x > barra->x && x < barra->x + barra->w \
			&& y > barra->y - 3 && y < barra->y + 3)
	{
		int dx = x - barra->x;
		int ancho = barra->valor_maximo - barra->valor_minimo;

		barra->valor_actual = ancho*dx / barra->w + barra->valor_minimo;
	}
}
