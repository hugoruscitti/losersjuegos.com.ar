/*
 * Copyright (C) 2006 Hugo Ruscitti
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdlib.h>
#include <stdio.h>

#include "SDL.h"
#include "SDL_image.h"

#include "mezclar_colores.h"
#include "barra.h"
#include "utils.h"



int main (void)
{
	SDL_Event event;
	SDL_Surface * screen;
	SDL_Surface * imagen_original;
	SDL_Surface * imagen;
	SDL_Surface * fondo;
	Barra barras [4];

	screen = iniciar_sdl (320, 240, "Mezclar colores");

	if (! screen)
	{
		printf ("Error: %s\n", SDL_GetError ());
		exit (1);
	}

	/* Carga las imagenes principales */
	
	imagen_original = IMG_Load ("../data/ceferino.png");

	if (! imagen_original)
	{
		printf ("Error: %s\n", SDL_GetError ());
		exit (1);
	}

	fondo = IMG_Load ("../data/fondo.png");

	if (! fondo)
	{
		printf ("Error: %s\n", SDL_GetError ());
		exit (1);
	}

	/* Genera las barras para modificar las componentes de color */
	iniciar_deslizadores (barras, screen->format);

	/* espera el cierre de la aplicaci�n */	
	while (SDL_WaitEvent (& event))
	{
		do 
		{
			switch (event.type)
			{
				case SDL_QUIT:
					SDL_FreeSurface (imagen_original);
					SDL_FreeSurface (fondo);
					exit (1);
					break;

				case SDL_MOUSEBUTTONDOWN:
				{
					int x = event.button.x;
					int y = event.button.y;
					
					/* se notifica a todos los componentes
					 * que se registr� la pulsaci�n de un 
					 * bot�n del `mouse`.
					 */
					barra_on_click (barras, x, y);
					barra_on_click (barras + 1, x, y);
					barra_on_click (barras + 2, x, y);
					barra_on_click (barras + 3, x, y);
					break;
				}
				
				case SDL_MOUSEMOTION:
				{
					int x = event.motion.x;
					int y = event.motion.y;
					
					/* se notifica a todos los componentes
					 * que se registr� la pulsaci�n de un 
					 * bot�n del `mouse` mientras se 
					 * realiza un movimiento.
					 */
					if (SDL_BUTTON(1) & event.motion.state)
					{
						barra_on_click (barras, x, y);
						barra_on_click (barras+1, x, y);
						barra_on_click (barras+2, x, y);
						barra_on_click (barras+3, x, y);
					}
					break;

				}
				
				default:
					break;
			}
		
		} while (SDL_PollEvent (&event));

		imagen = mezclar_colores (imagen_original, 
				barras[0].valor_actual,
				barras[1].valor_actual,
				barras[2].valor_actual,
				barras[3].valor_actual);
		
		imprimir_ventana (screen, fondo, imagen, barras);
		SDL_FreeSurface (imagen);
		SDL_Delay (1);
	}

	return 0;
}


/*!
 * \brief actualiza la parte visible del programa
 * \param screen pantalla principal
 * \param fondo fondo de pantalla
 * \param imagen imagen que representa la figura de colores a modificar
 * \param barras vector de barras
 */
void imprimir_ventana (SDL_Surface * screen, SDL_Surface * fondo, 
		SDL_Surface * imagen, Barra * barras)
{
	SDL_Rect imagen_rect = {160 - imagen->w / 2, 0, 0, 0};

	SDL_BlitSurface (fondo, NULL, screen, NULL);
	SDL_BlitSurface (imagen, NULL, screen, & imagen_rect);

	barra_imprimir (barras, screen);
	barra_imprimir (barras + 1, screen);
	barra_imprimir (barras + 2, screen);
	barra_imprimir (barras + 3, screen);
	
	SDL_Flip (screen);
}


/*!
 * \brief altera las componentes de color de todos los p�xeles de la imagen
 * \param src superficie a modificar
 * \param dr modificaci�n para el componente Rojo, rango [-255, 255]
 * \param dg modificaci�n para el componente Verde, rango [-255, 255]
 * \param db modificaci�n para el componente Az�l, rango [-255, 255]
 * \param da modificaci�n para el componente Alpha, rango [-255, 255]
 * return una nueva superficie con el cambio de colores
 */
SDL_Surface * mezclar_colores (SDL_Surface * src,int dr, int dg, int db, int da)
{
	SDL_Surface * dst = SDL_DisplayFormatAlpha (src);
	int x, y;
	int r, g, b, a;

	if (! dst)
	{
		printf ("Error: %s\n", SDL_GetError ());
		return NULL;
	}

	if (SDL_MUSTLOCK (src))
	{
		if (SDL_LockSurface (src) < 0)
			return NULL;
	}

/* \brief evita que un n�mero `X` supere los l�mites `min` y `max` */
#define limitar(X,min,max) ((X) > (max))? max: ((X) < (min))? min: X

	for (x = 0; x < src->w; x ++)
	{
		for (y = 0; y < src->h; y ++)
		{
			SDL_Color color_src;
			SDL_Color color_dst;

			/* obtiene las componentes de un p�xel */
			get_pixel_color (src, x, y, & color_src);

			/* le aplica una modificaci�n de componentes */
			r = color_src.r + dr;
			g = color_src.g + dg;
			b = color_src.b + db;
			a = color_src.unused + da;
		
			/* se asegura que el valor de las componetes est� 
			 * comprendido entre 0 y 255 */
			color_dst.r = limitar(r,0,255);
			color_dst.g = limitar(g,0,255);
			color_dst.b = limitar(b,0,255);
			color_dst.unused = limitar(a,0,255);
			
			/* copia el pixel generado a la superficie destino */
			set_pixel_color (dst, x, y, & color_dst);
		}
	}

	if (SDL_MUSTLOCK (src))
		SDL_UnlockSurface (src);
	
	return dst;
}

/*!
 * \brief genera las barras horizontales que le permiten alterar la imagen
 * \param barras vector a las 3 barras
 * \param format formato de p�xeles de la imagen destino (generalmente screen)
 */
void iniciar_deslizadores (Barra * barras, SDL_PixelFormat * format)
{
	Uint32 r = SDL_MapRGB (format, 255, 0, 0);
	Uint32 g = SDL_MapRGB (format, 0, 255, 0);
	Uint32 b = SDL_MapRGB (format, 0, 0, 255);
	Uint32 a = SDL_MapRGB (format, 0, 0, 0);

	barra_iniciar (barras,     10, 185, 300, -255, 255, r);
	barra_iniciar (barras + 1, 10, 200, 300, -255, 255, g);
	barra_iniciar (barras + 2, 10, 215, 300, -255, 255, b);
	barra_iniciar (barras + 3, 10, 230, 300, -255, 255, a);
}
