/*
prueba de imagen en programa en C con SDL Copyright(C) 2009 Jes�s Hern�ndez Gormaz - <elrinconjhg@gmail.com> - www.elrinconjhg.ya.st

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 3, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

Este programa es software libre. Puede redistribuirlo y/o
modificarlo bajo los t�rminos de la Licencia P�blica General
de GNU seg�n es publicada por la Free Software Foundation,
bien de la versi�n 3 de dicha Licencia o bien (seg�n su
elecci�n) de cualquier versi�n posterior.
Este programa se distribuye con la esperanza de que sea
�til, pero SIN NINGUNA GARANT�A, incluso sin la garant�a
MERCANTIL impl�cita o sin garantizar la CONVENIENCIA PARA UN
PROP�SITO PARTICULAR. Para m�s detalles, v�ase la Licencia
P�blica General de GNU.
Deber�a haber recibido una copia de la Licencia P�blica
General junto con este programa. En caso contrario, escriba
a la Free Software Foundation, Inc., en 675 Mass Ave,
Cambridge, MA 02139, EEUU.
*/

#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>

/*incluimos el archivo de cabecera dodne esta los datos de la primera imagen (imagen) definidos como una variable global*/
#include "losersjuegos.h"

/*incluimos el archivo de cabecera de una funcion que contiene tanto los datos para crear la segunda imagen (imagen2) como
 el paso para crear la superficie, esta funcion devuelve directamente la superficie creada, asi nos evitamos tener una variable global*/
#include "copyleft.h"

int main(int argc, char *argv[]){
	SDL_Surface *pantalla, *imagen, *imagen2;
	SDL_Rect dest;
	/* Iniciando SDL*/
	if (SDL_Init(SDL_INIT_VIDEO) < 0) {
		exit(1);
	}
	/* Iniciando modo de video*/
	pantalla = SDL_SetVideoMode((losersjuegos.w + 100),(losersjuegos.h + 100),32,SDL_HWSURFACE|SDL_DOUBLEBUF);
	if (pantalla == NULL) {
		SDL_Quit();
		exit(1);
	}
	/*creamos una superficie con SDL_CreateRGBSurfaceFrom a partir de los datos de la imagen*/
	imagen= SDL_CreateRGBSurfaceFrom(&losersjuegos.pixels, losersjuegos.w, losersjuegos.h, losersjuegos.bpp * 8, losersjuegos.w * losersjuegos.bpp, 0x000000ff, 0x0000ff00, 0x00ff0000, 0xff000000);
	/*llamamos a una funcion que contiene los datos de una imagen y se encarga de crear la superficie con
	 ellos, esta opcion es mejor que la anterior de crear directamente la superficie a partir de los datos
	 como una variable global puesto que asi ya no necesitas una variable global y todo queda dentro de una funcion*/
	imagen2= Logo_copyleft();
	if(imagen != NULL && imagen2 != NULL){
		/*mostramos las imagenes en la pantalla centradas si son mas peque�as que la pantalla*/
		dest.x = ((pantalla->w / 2)-(imagen2->w / 2));
		dest.y = ((pantalla->h / 2)-(imagen2->h / 2));
		dest.w = imagen2->w;
		dest.h = imagen2->h;
		SDL_BlitSurface(imagen2, NULL, pantalla, &dest);
		if(SDL_Flip(pantalla) == -1){
			SDL_UpdateRect(pantalla, 0, 0, pantalla->w, pantalla->h);
		}
		/*esperamos 4 segundos para despues mostrar encima de la imagen actual, la otra imagen*/
		SDL_Delay(4000);
		/*usamos el mismo rectangulo pero con las dimensiones de la imagen que falta por mostrar y centrando la imagen que vamos a mostrar*/
		dest.x = ((pantalla->w / 2)-(imagen->w / 2));
		dest.y = ((pantalla->h / 2)-(imagen->h / 2));
		dest.w = imagen->w;
		dest.h = imagen->h;
		SDL_BlitSurface(imagen, NULL, pantalla, &dest);
		if(SDL_Flip(pantalla) == -1){
			SDL_UpdateRect(pantalla, 0, 0, pantalla->w, pantalla->h);
		}
	}
	/*esperamos 5 segundos para despues salir del programa*/
	SDL_Delay(5000);
	/*liberamos los recursos de memoria usados*/
	SDL_FreeSurface(imagen);
	SDL_FreeSurface(imagen2);
	SDL_FreeSurface(pantalla);
	/*finalizamos SDL*/
	SDL_Quit();
	return 0;
}
