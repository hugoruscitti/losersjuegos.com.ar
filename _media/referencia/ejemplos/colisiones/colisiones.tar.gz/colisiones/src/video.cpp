/*
 * Copyright (C) 2006 Gabriel Valentin
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include<stdio.h>
#include"video.h"

int video :: iniciar(void)
{
	if(SDL_Init(SDL_INIT_VIDEO) == -1)
	{
		fprintf(stderr,"Error al inicializar Video:%s",SDL_GetError());
		return 1;
	}

	screen = SDL_SetVideoMode(640,480,16,SDL_HWSURFACE|SDL_DOUBLEBUF);

	if(screen == NULL)
	{
		fprintf(stderr,"Error al iniciar la superficie:%s",SDL_GetError());
		return 1;
	}
		
	if(crear_fondo())
		return 1;
	
	lim_actual=lim_todos=lim_anteriores=0;
	
	return 0;
}


int video :: crear_fondo(void)
{
	SDL_Surface *imagen;
		
	fondo = SDL_CreateRGBSurface(SDL_HWSURFACE,640,480,16,0,0,0,0);
		
	imagen = SDL_LoadBMP(DATADIR "fondo.bmp");

	if(fondo == NULL)
	{
		fprintf(stderr,"Error al crear el fondo auxiliar %s",SDL_GetError());
		return 1;
	}

	fondo = SDL_DisplayFormat(screen);
	
	SDL_BlitSurface(imagen,0,fondo,0);
	SDL_Flip(fondo);
	
	SDL_BlitSurface(fondo,0,screen,0);
	SDL_Flip(screen);
	
	return 0;
}

void video :: cargar_rectangulo_actual(SDL_Rect* rect)
{
	
	rec_actual[lim_actual] = *rect; 					
					
	lim_actual++;
}

void video :: cargar_rectangulo_todos()
{
	int i=0;
	
	lim_todos=0;
	
	for(i=0 ; i<lim_actual ;i++,lim_todos++) 
		rec_todos[i]=rec_actual[i];
	
	for(i=0 ; i<lim_anteriores ;i++,lim_todos++) 
		rec_todos[lim_todos]=rec_anteriores[i];
	
}


int video :: restaurar_fondo(void)
{
	int i;

	SDL_UpdateRects(screen,lim_todos,rec_todos);

	for(i=0 ; i<lim_actual ;i++) 
			SDL_BlitSurface(fondo,&(rec_actual[i]),screen,&(rec_actual[i]));	
}


int video :: actualizar(SDL_Surface* src,SDL_Rect* srcRect)
{
	
	if(SDL_BlitSurface(src,0,screen,srcRect) == -1)
	{
		fprintf(stderr,"error de blit\n",SDL_GetError());		
		return 1;
	}
	
//	SDL_Flip(screen);
}


void video :: cargar_rectangulo_anteriores()
{
	int i;
	
	lim_anteriores=0;

	for(i=0 ; i<lim_actual ;i++,lim_anteriores++) 
		rec_anteriores[i]=rec_actual[i];

	lim_actual=0;
}


