/*
 * Copyright (C) 2006 Gabriel Valentin
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include"juego.h"

int juego :: iniciar()
{
	video = new class video;
	
	procesos = new class procesos;
					
	if(video->iniciar())
		return 1;
	
	procesos->iniciar(video);
	
	SDL_WM_SetCaption("Colision de esferas",NULL);
	
	return 0;
}

int juego :: actualizar()
{
	procesos->actualizar();
	procesos->avisar_colisiones();
}


int juego :: imprimir()
{
	
	procesos->imprimir();
	video->cargar_rectangulo_todos();
	video->restaurar_fondo();
	video->cargar_rectangulo_anteriores();
	
}


int juego :: salir()
{
	SDL_Event evento;

	if(SDL_PollEvent(&evento))
	{
		switch(evento.type)
		{
						case SDL_KEYDOWN:
										
										if(evento.key.keysym.sym == SDLK_ESCAPE)
										{
											procesos->liberar();	
											return 0;
										}
										
										if(evento.key.keysym.sym == SDLK_SPACE)
										{
											procesos->iniciar(video);
											return 1;
										}
						break;

						case SDL_QUIT:		
										procesos->liberar();	
										return 0;
						break;
		}	
	}
		
	return 1;
}
