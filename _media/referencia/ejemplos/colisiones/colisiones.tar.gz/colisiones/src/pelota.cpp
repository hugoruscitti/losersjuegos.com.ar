/*
 * Copyright (C) 2006 Gabriel Valentin
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include<stdio.h>
#include"pelota.h"

#define PI 3.141592654


int pelota :: iniciar(class video* video)
{
	imagen = SDL_LoadBMP(DATADIR "esfera.bmp");
	
	this->video = video;
		
	x=0;
	y=0;
	dx= cos(0.785398163);
	dy= sin(0.785398163);
			
	if(imagen == NULL)
	{
		fprintf(stderr,"Error al cargar imagen:%s",SDL_GetError());
		return 1;
	}
		
	SDL_SetColorKey(imagen,SDL_SRCCOLORKEY,SDL_MapRGB(imagen->format,255,0,255));
		
	return 0;
}

void pelota :: actualizar(void)
{
	x += (dx*1.5);
	y += (dy*1.5);

	if (x > 640 - 100)
	{
		//dx = -1;
		dx = cos(radianes(135));
	}
	if (y > 480 - 100)
	{
		dy = sin(radianes(315));
	//	dx = cos(radianes(315));
	}
	
	if (x < 0)
	{
		//dx = 1;
		dx = cos(radianes(45));
	}

	if (y < 0)
	{
		//dy = 1;
		dy = sin(radianes(135));
	}

	actualizar_rectangulo();
}

void pelota :: cambiar_flips()
{
	dy*=-1;
	dx*=-1;
}


void pelota :: avisar_colision(int xm,int ym, int xo, int yo)
{
	int caso;
	float angulo,otro;

	caso = verificar_caso(xm,ym,xo,yo);
	
	switch (caso)
	{
		case 1://abajo-derecha
			otro =(ym-yo)/(xm-xo);
			angulo = atan(otro);
			dx = cos(angulo); 
			dy = sin(angulo);
			break;

		case 2://abajo-izquierda	
			otro = (ym-yo)/(xo-xm);
			angulo = atan(otro);
			angulo = radianes(180) - angulo;
			dx = cos(angulo); 
			dy = sin(angulo);
			break;
				
		case 3://arriba-derecha
			otro = (xm-xo)/(yo-ym);
			angulo = atan(otro);			
			angulo = radianes(270) + angulo;
			dx = cos(angulo); 
			dy = sin(angulo);
			break;
				
		case 4://arriba-izquierda
			otro = (xo-xm)/(yo-ym);
			angulo = atan(otro);			
			angulo = radianes(270) - angulo;  
			dx = cos(angulo); 
			dy = sin(angulo);
			break;

		case 5://igual y
			dy *= -1;
			break;
			
		case 6://igual x
			dx *=-1 ; 
			break;
		
	}
	
}

int pelota :: verificar_caso(int xm,int ym, int xo, int yo)
{
				
	if((ym > yo) && ( xm > xo))
		return 1;

	if((ym > yo) && ( xm < xo))
		return 2;

	if((ym < yo) && ( xm > xo))
		return 3;

	if((ym < yo) && ( xm < xo))
		return 4;

	if(ym == yo)
		return 5;

	if( xm == xo )
		return 6;

}

void pelota :: imprimir()
{
	video->actualizar(imagen,&rectangulo);
	video->cargar_rectangulo_actual(&rectangulo);
}

SDL_Rect pelota :: actualizar_rectangulo()
{
	SDL_Rect auxiliar;
	
	rectangulo.x = (int) x;
	rectangulo.y = (int) y;
	rectangulo.w = 0;
	rectangulo.h = 0;

	auxiliar = rectangulo;

	return auxiliar;
}


void pelota :: liberar_superficie(void)
{
	SDL_FreeSurface(imagen);
}


float pelota :: radianes(float x) 
{				
	return x*PI/180; 
}
