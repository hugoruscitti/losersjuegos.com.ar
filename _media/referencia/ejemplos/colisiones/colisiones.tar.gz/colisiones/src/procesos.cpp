/*
 * Copyright (C) 2006 Gabriel Valentin
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include"procesos.h"
#include"pelota.h"

void procesos :: iniciar(class video* video)
{
	crear(video);
}

void procesos :: crear(class video* video)
{
	nodos nuevo= new struct nodo;
	
	nuevo->pelota = new class pelota;
	nuevo->pelota->iniciar(video);
	nuevo->sgte=NULL;
	
	insertar(nuevo);
}

void procesos :: insertar(struct nodo* nuevo)
{
	nodos ptr,aux;
	
	if(lista != NULL)
	{
		for(ptr = lista ; ptr ;aux=ptr,ptr = ptr->sgte);
		aux->sgte=nuevo;
	}
	else
		lista=nuevo;

}


void procesos ::liberar()
{
	nodos ptr;
	
	for(;lista;lista=lista->sgte)
	{
		ptr = lista;
		ptr->pelota->liberar_superficie();
		delete ptr;
	}
					
}
void procesos :: actualizar()
{
	nodos ptr;
	
	for(ptr = lista;ptr;ptr=ptr->sgte)
		ptr->pelota->actualizar();
}
				
void procesos :: imprimir()
{
	nodos ptr;
	
	for(ptr = lista;ptr;ptr=ptr->sgte)
		ptr->pelota->imprimir();
}	

int procesos :: cant_nodos()
{
	nodos ptr;
	int i=0;

	for(ptr=lista;ptr;ptr=ptr->sgte,i++);

	return i;
}

float procesos :: distancia(int x1,int y1,int x2,int y2)
{
	return sqrt(pow(x1-x2,2) + pow(y1-y2,2));
}

void procesos :: avisar_colisiones()
{
	float delta;
	SDL_Rect rect1,rect2;
	nodos ptr,aux;
	
	while(cant_nodos() != 1)
	{
		ptr=sacar_nodo();
		
		rect1=ptr->pelota->actualizar_rectangulo();
		
		for(aux=lista;aux;aux=aux->sgte)
		{
			rect2=aux->pelota->actualizar_rectangulo();
			delta=distancia(rect1.x+50,rect1.y+50,rect2.x+50,rect2.y+50);
			
			if(delta <= 100)
			{
				ptr->pelota->avisar_colision(rect1.x+50,rect1.y+50,rect2.x+50,rect2.y+50);
				aux->pelota->avisar_colision(rect2.x+50,rect2.y+50,rect1.x+50,rect1.y+50);
			}	
		}		
	}
	
	if(lista_aux != NULL)
		restaurar_lista();			

}

void procesos :: restaurar_lista()
{
	nodos ptr,aux;

	for(;lista_aux;)
	{
		aux = lista_aux;
		lista_aux=lista_aux->sgte;
		aux->sgte=NULL;
		insertar(aux);	
	}
	
}


struct nodo* procesos :: sacar_nodo()
{
	nodos ptr,aux,pun;
	
	pun = lista;
	lista = lista->sgte;
					
	if(lista_aux != NULL)
	{
		for(ptr = lista_aux ; ptr ;aux=ptr,ptr = ptr->sgte);	
		aux->sgte = pun;
	}
	else
		lista_aux = pun;

	pun->sgte=NULL;
	
	return pun;	
}
