import direct.directbase.DirectStart
from direct.actor import Actor
from panda3d.core import Point3
from direct.interval.IntervalGlobal import Sequence

# Carga el modelo del cooperativista feliz...
actor = loader.loadModel('coop.egg')
actor.setScale(30)
actor.setPos(0, 100, -15)

# Define la interpolacion de rotacion.
# y la ejecuta en modo 'loop' (constante).
positions = actor.hprInterval(10, Point3(0, -75, 0), startHpr=Point3(0, -75, 360))
rotate_motion = Sequence(positions)
rotate_motion.loop()

# coloca al actor en la escena.
actor.reparentTo(render)


run()
