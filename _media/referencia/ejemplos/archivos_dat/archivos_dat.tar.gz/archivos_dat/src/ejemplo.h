/* Allegro datafile object indexes, produced by grabber v4.2.0, Unix */
/* Datafile: /home/jorge/Projects/Archivos DAT de Allegro/ejemplo/res/ejemplo.dat */
/* Date: Sun Aug 13 11:54:33 2006 */
/* Do not hand edit! */

#define DAT_FONDO                        0        /* BMP  */
#define DAT_NAVE                         1        /* BMP  */
#define DAT_MUSICA                       2        /* MIDI */
#define DAT_MENSAJE                      3        /* TXT  */
#define DAT_CONFIG                       4        /* TXT  */
#define DAT_EFECTO                       5        /* SAMP */
#define DAT_COUNT                        6

