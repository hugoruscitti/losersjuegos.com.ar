/*
 * Ejemplo de utilizaci�n de archivos DAT de Allegro.
 * por Jos� Jorge Enr�quez Rguez. <josejorge+mail@gmail.com>
 *
 * Allegro es una librer�a para programaci�n de videojuegos,
 * m�s informaci�n en http://alleg.sourceforge.net/
 *
 */

/* Incluir Allegro y el archivo de cabecera creado con grabber.exe */
#include "ejemplo.h"
#include <allegro.h>

DATAFILE *archivoDAT = NULL;

/* BITMAPs de fondo y b�fer (para la t�cnica de doble b�fer, que se
 * utiliza para evitar parpadeos al dibujar.
 */
BITMAP *imgFondo = NULL;
BITMAP *buffer = NULL;

/* La nave. */
BITMAP *imgNave = NULL;
int naveX, naveY;

/* M�sica de fondo. */
MIDI *midiMusica = NULL;
SAMPLE *efectoSonido = NULL;

// funciones de ayuda (ya saben, divide y vencer�s :P)
void iniciar();
void terminar();
void actualizarJuego();

// funciones llamadas desde actualizarJuego();
void actualizarNave();
void dibujar();

/* ------------------------------------------
 * Programa principal.
 * ------------------------------------------
 */
int main() {

	iniciar();
	while ( !key[ KEY_ESC ] ) actualizarJuego();
	terminar();

  return 0;
} END_OF_MAIN();

/* ------------------------------------------
 * Inicializaci�n
 * ------------------------------------------
 */
void iniciar() {
	DATAFILE* data;
	int colMensaje, colFondoMensaje;
	int coordMensajeY = 100;

	// Variables que se cargan del archivo .dat
	const char *titulo;
	const char *mensaje1;
	const char *mensaje2;
	const char *mensaje3;
	
	/* Inicializar Allegro y subsistemas necesarios. */
	allegro_init();
	install_keyboard();
	install_timer();

	set_color_depth( 24 );
	/* Iniciar modo gr�fico 640x480x32. */
	if ( set_gfx_mode( GFX_AUTODETECT, 640, 480, 0, 0 ) < 0 ) {
		allegro_message( "ERROR: no se pudo iniciar modo gr�fico." );
		exit( 1 );
	}

	/* Inicializar el subsistema de audio, adem�s comprobamos si se inici�. */
	if ( install_sound( DIGI_AUTODETECT, MIDI_AUTODETECT, NULL ) != 0 ) {
		allegro_message( "ERROR: no se pudo iniciar audio.\n%s", allegro_error );
	}

	// Abrir el archivo .dat
	archivoDAT = load_datafile( "../res/ejemplo.dat" );
	if ( archivoDAT == NULL ) {
		allegro_message( "ERROR: no se pudo cargar el archivo .dat.\n%s", allegro_error );
		exit( 1 );
	}

	data = find_datafile_object( archivoDAT, "CONFIG" );
	if ( !data ) {
		allegro_message( "ERROR: %s.\n", allegro_error );
		exit( 1 );
	}
	// Establecemos los datos para las rutinas de configuraci�n.
	set_config_data( data->dat, data->size );

	titulo = get_config_string( "EJEMPLO", "titulo", "T�tulo por defecto" );
	set_window_title( titulo );

	mensaje1 = get_config_string( "EJEMPLO", "mensaje_1", "Mensaje 1 por defecto." );
	mensaje2 = get_config_string( "EJEMPLO", "mensaje_2", "Mensaje 2 por defecto." );
	mensaje3 = get_config_string( "EJEMPLO", "mensaje_3", "Mensaje 3 por defecto" );
	
	/* Creamos el BITMAP que servir� de b�fer. */
	buffer = create_bitmap( SCREEN_W, SCREEN_H );
	
	/* Limpia pantalla y b�fer. */
	clear( screen );
	clear( buffer );
  

	/* Para usar la imagen del archivo .dat, se puede hacer de dos formas:
	 * 1) Referenci�ndola directamente:
	 * blit(archivoDAT[DAT_fondo].dat, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
	 * 2) Asign�ndola a un BITMAP, y usando este:
	 */
	imgFondo = (BITMAP *)archivoDAT[ DAT_FONDO ].dat;
	if ( !imgFondo ) {
		allegro_message( "ERROR: no se pudo cargar la imagen de fondo." );
		exit( 1 );
	}
	/* Recomiendo usar esta �ltima forma, ya que es m�s pr�ctica p. ej.: si hay
	 * alg�n cambio (en el nombre del archivo, o en el nombre del recurso, o si
	 * decidi�ramos no usar archivos .dat, etc.) s�lo habr�a que hacer un cambio
	 * y no uno por cada vez que hacemos referencia al recurso.
	 */

	colMensaje = makecol( 255, 255, 255 );
	colFondoMensaje = -1; // transparente.

	textout_centre_ex( imgFondo, font, mensaje1,
		SCREEN_W / 2, coordMensajeY, colMensaje, colFondoMensaje );
	textout_centre_ex( imgFondo, font, mensaje2,
		SCREEN_W >> 1, coordMensajeY + 15, colMensaje, colFondoMensaje );
	textout_centre_ex( imgFondo, font, mensaje3,
		SCREEN_W / 2, coordMensajeY + 30, colMensaje, colFondoMensaje );
	
	blit( imgFondo, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H );
	
	// la nave, usamos el segundo m�todo que mencion� para la imagen de fondo:
	// asignar del archivo dat a un BITMAP
	imgNave = archivoDAT[ DAT_NAVE ].dat;
	if ( !imgNave ) {
		allegro_message( "ERROR: no se pudo cargar la imagen de la nave." );
		exit(1);
	}
	
	// Inicializar coordenadas de la nave
	// (centro de la pantalla - la mitad del ancho y del alto)
	naveX = SCREEN_W / 2 - imgNave->w / 2;
	naveY = SCREEN_H - imgNave->h;

	// La m�sica de fondo, tambi�n usamos un MIDI para referenciar al del
	// archivo .dat
	midiMusica = archivoDAT[ DAT_MUSICA ].dat;
	if ( !midiMusica ) {
		allegro_message( "ERROR: no  se pudo cargar melod�a de fondo." );
		exit( 1 );
	}

	efectoSonido = archivoDAT[ DAT_EFECTO ].dat;
	if ( !efectoSonido ) {
		allegro_message( "ERROR: no se pudo cargar efecto de sonido.\n%s", allegro_error );
		exit( 1 );
	}

	// Iniciar reproducci�n de la m�sica de fondo
	play_midi( archivoDAT[DAT_MUSICA].dat, 1 );
}

/* ------------------------------------------
 * Finalizaci�n del programa.
 * ------------------------------------------
 */
void terminar() {
	DATAFILE *mensajeSalida;

	// Detener la melod�a de fondo
	if ( midiMusica ) stop_midi();

	mensajeSalida = find_datafile_object( archivoDAT, "MENSAJE" );
	allegro_message( mensajeSalida->dat );

	// Liberar la memoria utilizada por el archivo .dat
	unload_datafile( archivoDAT );
	/* Comentario:
	 * vale la pena aclarar que, en este caso, no es necesario llamar a las
	 * funciones para liberar la memoria utilizada por los BITMAP (ni por el MIDI),
	 * puesto que no se reserv� memoria para ellos, sino para el archivo .dat,
	 * basta con liberar a este �ltimo.
	 */

	/* Sale de Allegro. */
	allegro_exit();
}

/* ------------------------------------------
 * Actualizaci�n del juego.
 * ------------------------------------------
 */
void actualizarJuego() {
	actualizarNave();
	dibujar();
}

/* ------------------------------------------
 * Actualizaci�n de la posici�n de la nave.
 * ------------------------------------------
 * Actualiza las coordenadas de la nave de acuerdo a la entrada del usuario.
 * -------------------------------------------------------------------------
 */
void actualizarNave() {
	static int puedeDisparar = 1;

	if ( key[ KEY_LEFT ] ) naveX -= 2;
	if ( key[ KEY_RIGHT ] ) naveX += 2;
	if ( naveX < 0 ) naveX = 0;
	if ( naveX > SCREEN_W - imgNave->w ) naveX = SCREEN_W - imgNave->w;

	if ( key[ KEY_UP ] ) naveY -= 2;
	if ( key[ KEY_DOWN ] ) naveY += 2;
	if ( naveY < 0 ) naveY = 0;
	if ( naveY > SCREEN_H - imgNave->h ) naveY = SCREEN_H - imgNave->h;

	if ( key[ KEY_LCONTROL ] ) {
		if ( puedeDisparar == 1 ) {
			play_sample( efectoSonido, 128, 128, 1000, 0 );
			puedeDisparar = 0;
		}
	}
	else {
		puedeDisparar = 1;
	}
}

/* ------------------------------------------
 * Volcado a pantalla.
 * ------------------------------------------
 */
void dibujar() {
	/* Dibujar al b�fer */
	blit( imgFondo, buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H );
	draw_sprite( buffer, imgNave, naveX, naveY );

	/* Esperar al retrazado vertical de la pantalla. */
	vsync();
	
	/* Dibujar el b�fer a la pantalla. */
	blit( buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H );
}
