/*
 * Copyright (C) 2006 Gabriel Valentin
 * Copyright (C) 2009 David Ramirez
 *
 * This program is free software; you can redistribute it &&/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <SDL.h>
#include <math.h>

#define COLOR 255, 255, 255
#define SCREEN_W 320
#define SCREEN_H 240

void draw_circle0(SDL_Surface *screen, Uint32 color, int largo);
void draw_circle1(SDL_Surface *screen, Uint32 color, int largo);
void draw_circle2(SDL_Surface *screen, Uint32 color, int largo);
void draw_circle3(SDL_Surface *screen, Uint32 color, int largo);
void put_pixel(SDL_Surface *_ima, int x, int y, Uint32 pixel);
int esperar (void);

int main (void)
{
	SDL_Surface * screen;
	
	SDL_Init (SDL_INIT_VIDEO);
	
	screen = SDL_SetVideoMode (SCREEN_W, SCREEN_H, 16, SDL_HWSURFACE);

	Uint32 color;
	color = SDL_MapRGB (screen->format,COLOR);

	int largo = 92; 
	
	int salir = 0;
	int metodo = 0;
	while (!salir)
	{
		SDL_FillRect(screen, NULL, 0);
		     if (metodo == 0) draw_circle0(screen, color, largo);
		else if (metodo == 1) draw_circle1(screen, color, largo);
		else                  draw_circle2(screen, color, largo);
		metodo = (metodo+1)%3;
		SDL_Flip (screen);

		salir = esperar ();
	}
	
	return 0;
}


void draw_circle0(SDL_Surface *screen, Uint32 color, int largo)
{
	int x, y;
	int angulo = 0;
	float angulo2;

	while ( angulo < 256 )
	{
		angulo2 = angulo * M_PI / 128;
		x = largo * cos (angulo2);
		y = largo * sin (angulo2);

		put_pixel (screen, SCREEN_W / 2 + x, SCREEN_H / 2 + y, color);

		angulo ++;
	}
}

void draw_circle1(SDL_Surface *screen, Uint32 color, int largo) {
    int x = SCREEN_W / 2;
    int y = SCREEN_H / 2;
    int j;
    for (j = 0; j <= largo; ++j) {
        int ii = sqrt(largo*largo-j*j);
        int i;
        for (i = 0; i <= ii; ++i) {
            if (y+i < SCREEN_H && x+j < SCREEN_W) put_pixel (screen, x+j, y+i, color);
            if (y+i < SCREEN_H && x-j >= 0) put_pixel (screen, x-j, y+i, color);
            if (y-i >= 0 && x+j < SCREEN_W) put_pixel (screen, x+j, y-i, color);
            if (y-i >= 0 && x-j >= 0) put_pixel (screen, x-j, y-i, color);
        }
    }
}

void draw_circle2(SDL_Surface *screen, Uint32 color, int largo) {
    int x = SCREEN_W / 2;
    int y = SCREEN_H / 2;
    int i = largo;
    int j = 0;
    int d = 3 - 2*largo;
    while (j <= i) {
        if (y+i < SCREEN_H && x+j < SCREEN_W) put_pixel (screen, x+i, y+j, color);
        if (y+i < SCREEN_H && x-j >= 0) put_pixel (screen, x+i, y-j, color);
        if (y-i >= 0 && x+j < SCREEN_W) put_pixel (screen, x-i, y+j, color);
        if (y-i >= 0 && x-j >= 0) put_pixel (screen, x-i, y-j, color);

        if (y+j < SCREEN_H && x+i < SCREEN_W) put_pixel (screen, x+j, y+i, color);
        if (y+j < SCREEN_H && x-i >= 0) put_pixel (screen, x+j, y-i, color);
        if (y-j >= 0 && x+i < SCREEN_W) put_pixel (screen, x-j, y+i, color);
        if (y-j >= 0 && x-i >= 0) put_pixel (screen, x-j, y-i, color);

        ++j;
        if (d < 0) d = d + 4*j + 6;
        else {
            d = d + 4*(j - i) + 10;
            --i;
        }
    }
}

void put_pixel(SDL_Surface *_ima, int x, int y, Uint32 pixel)
{
	int bpp = _ima->format->BytesPerPixel;
	Uint8 *p = (Uint8 *)_ima->pixels + y * _ima->pitch + x*bpp;

	switch (bpp)
	{
		case 1:
			*p = pixel;
			break;
			
		case 2:
			*(Uint16 *)p = pixel;
			break;
			
		case 3:
			if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
			{
				p[0]=(pixel >> 16) & 0xff;
				p[1]=(pixel >> 8) & 0xff;
				p[2]=pixel & 0xff;
			}
			else
			{
				p[0]=pixel & 0xff;
				p[1]=(pixel >> 8) & 0xff;
				p[2]=(pixel >> 16) & 0xff;
			}
			break;
			
		case 4:
			*(Uint32 *) p = pixel;
			break;
	}
}


int esperar (void)
{
	SDL_Event evento;
	
	while ( SDL_WaitEvent (& evento))
	{
		if (evento.type == SDL_KEYDOWN)
			return evento.key.keysym.sym == SDLK_ESCAPE;
	}
	return 0;
}
