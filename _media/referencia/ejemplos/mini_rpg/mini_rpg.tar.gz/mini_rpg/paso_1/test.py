import pygame

def imprimir_nivel(superficie):
    "Dibuja sobre una superficie todos los bloques del nivel."

    archivo = file('nivel.txt', 'rt')
    contenido = archivo.readlines()
    archivo.close()

    bloques = cargar_imagenes_de_bloques()
    numero_de_filas = len(contenido)
    numero_de_columnas = len(contenido[0]) - 1      # -1 por el salto de linea

    superficie.fill((150, 150, 255))

    for fila in range(numero_de_filas):
        for columna in range(numero_de_columnas):
            indice = int(contenido[fila][columna])
            pos_x = columna * 50
            pos_y = fila * 40 - 20
            superficie.blit(bloques[indice], (pos_x, pos_y))

def cargar_imagenes_de_bloques():
    "Retorna una lista de superficies con todos los bloques del escenario."
    bloques = []

    for n in range(3):
        bloques.append(pygame.image.load('../ima/%d.png' %n).convert_alpha())

    return bloques

def main():
    screen = pygame.display.set_mode((320, 240))
    pygame.display.set_caption("Mini RPG - en losersjuegos")
    imprimir_nivel(screen)
    pygame.display.flip()
    salir = False

    while not salir:

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                salir = True
            elif e.type == pygame.KEYDOWN and e.unicode == 'q':
                salir = True

        pygame.time.wait(100)

if __name__ == '__main__':
    pygame.display.init()
    main()
