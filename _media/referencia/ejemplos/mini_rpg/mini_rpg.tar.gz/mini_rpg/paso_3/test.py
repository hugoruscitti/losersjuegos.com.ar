# -*- coding: utf-8 -*-

# cambios respecto de la versión anterior:
#
#   * se agrega un algoritmo de "interpolacion" para suavizar el movimiento de
#     la cámara.
#
#   * aumenta aún mas el tamaño del escenario.

import pygame
from pygame.locals import K_LEFT, K_RIGHT, K_UP, K_DOWN, QUIT, KEYDOWN

class Escenario:
    "Representa el ambiente del juego, creando efectos de desplazamiento."

    def __init__(self):

        # matriz que se utiliza para imprimir el escenario y detectar limites
        self.grilla = self._cargar_grilla('nivel.txt')
        self.bloques = self._cargar_imagenes_de_bloques()
        self.fondo = self._crear_fondo()
        self._pintar_fondo()

        # coordenada superior izquierda de la cámara.
        # estas variables intentan alcanzar el valor de las variables
        # 'destino_camara_x' y 'destino_camara_y'.
        self.camara_x = 0
        self.camara_y = 0

        # indican la posición a la que debe llegar la cámara
        self.destino_camara_x = 200
        self.destino_camara_y = 100

    def imprimir(self, screen):
        origen = (self.camara_x, self.camara_y, 320, 240)
        destino = (0, 0, 320, 240)
        screen.blit(self.fondo, destino, origen)

    def update(self):
        # actualiza la coordenada de la cámara para suavizar el movimiento
        # el factor '10.0' es la 'suavidad' de movimiento, cuando mayor sea
        # este número, mas pequeño será el movimiento de cámara.
        self.camara_x += (self.destino_camara_x - self.camara_x) / 10.0
        self.camara_y += (self.destino_camara_y - self.camara_y) / 10.0

    def mover(self, dx, dy):
        self.destino_camara_x += dx
        self.destino_camara_y += dy

        # aplica limites al desplazamiento
        if self.destino_camara_x < 0:
            self.destino_camara_x = 0
        
        if self.destino_camara_y < 0:
            self.destino_camara_y = 0

        if self.destino_camara_x + 320 > self.fondo.get_width():
            self.destino_camara_x = self.fondo.get_width() - 320

        if self.destino_camara_y + 240 > self.fondo.get_height():
            self.destino_camara_y = self.fondo.get_height() - 240


    def _cargar_grilla(self, ruta):
        archivo = file(ruta, 'rt')
        contenido = archivo.readlines()
        archivo.close()
        return contenido

    def _crear_fondo(self):
        filas = len(self.grilla)
        columnas = len(self.grilla[0]) - 1
        ancho = columnas * 50
        alto = filas * 40
        return pygame.Surface((ancho, alto)).convert()

    def _pintar_fondo(self):
        "Dibuja sobre el fondo todos los bloques del nivel."

        numero_de_filas = len(self.grilla)
        numero_de_columnas = len(self.grilla[0]) - 1

        self.fondo.fill((150, 150, 255))

        for fila in range(numero_de_filas):
            for columna in range(numero_de_columnas):
                indice = int(self.grilla[fila][columna])
                pos_x = columna * 50
                pos_y = fila * 40 - 20
                self.fondo.blit(self.bloques[indice], (pos_x, pos_y))

    def _cargar_imagenes_de_bloques(self):
        "Retorna una lista de superficies con todos los bloques del escenario."
        bloques = []

        for n in range(5):
            bloques.append(pygame.image.load('../ima/%d.png' %n).convert_alpha())

        return bloques



class Personaje:

    def __init__(self, escenario):
        self.escenario = escenario

    def update(self):
        "Realiza movimientos de la cámara en base a la pulsación de teclas."
        teclas_pulsadas = pygame.key.get_pressed()

        if teclas_pulsadas[K_UP]:
            self.escenario.mover(0, -5)
        elif teclas_pulsadas[K_DOWN]:
            self.escenario.mover(0, 5)

        if teclas_pulsadas[K_LEFT]:
            self.escenario.mover(-5, 0)
        elif teclas_pulsadas[K_RIGHT]:
            self.escenario.mover(5, 0)


def main():
    screen = pygame.display.set_mode((320, 240))
    pygame.display.set_caption("Mini RPG - en losersjuegos")

    escenario = Escenario()
    personaje = Personaje(escenario)
    salir = False

    while not salir:

        for e in pygame.event.get():
            if e.type == QUIT:
                salir = True
            elif e.type == KEYDOWN and e.unicode == 'q':
                salir = True

        # se actualiza el personaje todo el tiempo, de modo que este
        # pueda alterar la posición de la cámara.
        personaje.update()

        # actualiza la posición de la cámara
        escenario.update()

        escenario.imprimir(screen)
        pygame.display.flip()
        pygame.time.wait(10)


if __name__ == '__main__':
    pygame.display.init()
    main()
