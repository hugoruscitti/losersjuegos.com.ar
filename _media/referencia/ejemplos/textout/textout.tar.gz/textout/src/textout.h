/*
 * Copyright (C) 2006 José Jorge Enríquez Rodríguez
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef TEXTOUT_H
#define TEXTOUT_H

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>

void textout( SDL_Surface *dest, TTF_Font *fuente, Sint16 x, Sint16 y,
	SDL_Color color, const char *texto );
void textout_center(SDL_Surface *dest, TTF_Font *fuente, Sint16 x, Sint16 y,
	SDL_Color color, const char *texto);
void textprintf(SDL_Surface *dest, TTF_Font *fuente, Sint16 x, Sint16 y,
	SDL_Color color, const char *formato, ...);
void utextout( SDL_Surface *dest, TTF_Font *fuente, Sint16 x, Sint16 y,
	SDL_Color color, const char *texto );
void unitextout( SDL_Surface *dest, TTF_Font *fuente, Sint16 x, Sint16 y,
	SDL_Color color, const Uint16 *texto );

#endif
