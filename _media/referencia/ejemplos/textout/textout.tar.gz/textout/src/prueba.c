/*
 * Copyright (C) 2006 José Jorge Enríquez Rodríguez
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "textout.h"
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
	SDL_Surface *pantalla;
	SDL_Event evento;
	SDL_Color colBlanco = { 255, 255, 255, 0 };
	SDL_Color colRojo = { 255 };
	TTF_Font *fuente;

	// Inicialización
	SDL_Init( SDL_INIT_VIDEO );
	TTF_Init();

	// Carga la fuente
	fuente = TTF_OpenFont( "res/FreeMono.ttf", 16 );
	if ( !fuente ) {
		printf( "Error: %s.\n", SDL_GetError() );
		exit( 1 );
	}

	// Inicializa pantalla	
	pantalla = SDL_SetVideoMode( 640, 480, 0, SDL_ANYFORMAT );
	if ( !pantalla ) {
		printf( "Error: %s.\n", SDL_GetError() );
		exit( 1 );
	}

	SDL_WM_SetCaption( "textout, wrapper para SDL_ttf", NULL );

	// Prueba las funciones "wrapper"
	textout( pantalla, fuente, 240, 50, colBlanco, "Texto de prueba con textout" );
	textout_center( pantalla, fuente, 240, 100, colBlanco, "Texto de prueba con textout_center" );

	textprintf( pantalla, fuente, 240, 150, colBlanco, "La suma de %d + %d es igual a %d", 24, 30, 24 + 30 );

	textout( pantalla, fuente, 20, 250, colRojo, "Probando caracteres especiales: ¿De dónde eres?." );
	utextout( pantalla, fuente, 20, 280, colRojo, "Probemos nuevamente: De México ¿y tú?" );

	utextout( pantalla, fuente, 20, 340, colRojo, "Más caracteres especiales: áéíóúñ !¿ äëïöü àèìòù âêîôû" );

	textout( pantalla, fuente, 0, 450, colBlanco, "Presiona ESC para salir..." );


	// Actualiza pantalla
	SDL_Flip( pantalla );
	// Esperamos hasta que el usuario finalice el programa.
	while ( 1 ) {
		if ( SDL_PollEvent( &evento ) ) {
			if ( evento.type == SDL_QUIT ) break;
			if ( evento.type == SDL_KEYDOWN )
				if ( evento.key.keysym.sym == SDLK_ESCAPE ) break;
		}
	}

	// Libera memoria utilizada por la fuente.
	TTF_CloseFont( fuente );

	// Cerramos
	TTF_Quit();
	SDL_Quit();

	return 0;
}
