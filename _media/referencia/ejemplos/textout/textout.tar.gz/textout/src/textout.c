/*
 * Copyright (C) 2006 José Jorge Enríquez Rodríguez
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "textout.h"
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdarg.h> /* Para la lista de parámetros variable. */

/*!
 * \brief Escribe la cadena texto a la superficie indicada.
 *
 * \param dest Superficie destino.
 * \param fuente Fuente (TTF_Font) a utilizar para escribir.
 * \param x posición x.
 * \param y posición y.
 * \param color Color (SDL_Color) a utilizar para el texto.
 * \param texto Cadena de texto a escribir.
 */
void textout( SDL_Surface *dest, TTF_Font *fuente, Sint16 x, Sint16 y,
	SDL_Color color, const char *texto ) {

	SDL_Surface *s;
	SDL_Rect rect = { x, y, 0, 0 };

	// Revisa que todo esté correcto.
	if ( !texto || !dest || !fuente ) return;

	s = TTF_RenderText_Solid( fuente, texto, color );
	SDL_BlitSurface( s, NULL, dest, &rect );

	SDL_FreeSurface( s );
}

/*!
 * \brief Escribe la cadena texto, toma la coordenada x como el centro.
 *
 * \param dest Superficie destino.
 * \param fuente Fuente (TTF_Font) a utilizar para escribir.
 * \param x posición x.
 * \param y posición y.
 * \param color Color (SDL_Color) a utilizar para el texto.
 * \param texto Cadena de texto a escribir.
 */
void textout_center(SDL_Surface *dest, TTF_Font *fuente, Sint16 x, Sint16 y,
	SDL_Color color, const char *texto) {

	SDL_Surface *s;
	SDL_Rect rect = { x, y, 0, 0 };
	int ancho, alto;

	// Revisa que todo esté correcto.
	if ( !texto || !dest || !fuente ) return;

	/* Obtener dimensiones del texto. */
	TTF_SizeText( fuente, texto, &ancho, &alto );
	/* Obteniendo la coordenada x. */
	rect.x = rect.x - ancho / 2;

	s = TTF_RenderText_Solid( fuente, texto, color );
	SDL_BlitSurface( s, NULL, dest, &rect );

	SDL_FreeSurface( s );
}

/*!
 * \brief Escribe una cadena de texto con el formato indicado.
 *
 * \param dest Superficie destino.
 * \param fuente Fuente (TTF_Font) a utilizar para escribir.
 * \param x posición x.
 * \param y posición y.
 * \param color Color (SDL_Color) a utilizar para el texto.
 * \param formato Cadena que indica el texto y el formato a escribir.
 */
void textprintf(SDL_Surface *dest, TTF_Font *fuente, Sint16 x, Sint16 y,
	SDL_Color color, const char *formato, ...) {

	SDL_Surface *s;
	SDL_Rect rectDest = { x, y, 0, 0 };
	char bufer[512];

	va_list ap;
	
	// Revisa que todo esté correcto.
	if ( !formato || !dest || !fuente ) return;
	
	va_start( ap , formato );
	vsprintf( bufer , formato , ap );
	va_end( ap );

	s = TTF_RenderText_Solid( fuente, bufer, color );
	SDL_BlitSurface( s, NULL, dest, &rectDest );

	SDL_FreeSurface( s );
}

/*!
 * \brief Escribe la cadena texto (codificada en UTF-8) a la superficie indicada.
 *
 * \param dest Superficie destino.
 * \param fuente Fuente (TTF_Font) a utilizar para escribir.
 * \param x posición x.
 * \param y posición y.
 * \param color Color (SDL_Color) a utilizar para el texto.
 * \param texto Cadena (UTF-8) de texto a escribir.
 */
void utextout( SDL_Surface *dest, TTF_Font *fuente, Sint16 x, Sint16 y,
	SDL_Color color, const char *texto ) {

	SDL_Surface *s;
	SDL_Rect rect = { x, y, 0, 0 };

	
	// Revisa que todo esté correcto.
	if ( !texto || !dest || !fuente ) return;

	s = TTF_RenderUTF8_Solid( fuente, texto, color );
	SDL_BlitSurface( s, NULL, dest, &rect );

	SDL_FreeSurface( s );
}
