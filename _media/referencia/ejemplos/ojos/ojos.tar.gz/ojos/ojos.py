# -*- coding: utf-8 -*-
#
# Autor: David Ramírez
# Licencia: GPL 3

import pygame
from pygame import *
from math import *

resolucion = (500, 300)
color = (255, 240, 220)

class Ojo(sprite.Sprite):

    def __init__(self, centro, rad_g, gros_g, color_g, color_i, rad_mov, rad_p, color_p):
        # El ojo se compone de dos partes:
        #   - Una circunferencia grande de centro "centro", radio "rad_g",
        #   grosor "gros_g", color de borde "color_g" y color interior "color_i
        #   (negro = transparente).
        #   - Una circunferencia pequeña, sin centro fijo (se desplaza en
        #   dirección al puntero del ratón a una distancia "rad_mov"(como máximo)
        #   desde "centro"), radio "rad_p", rellena y de color "color_p".
        sprite.Sprite.__init__(self)
       
        # Se crea la imagen de la circunferencia grande y se situa
        self.img_fondo = Surface((rad_g * 2, rad_g * 2)).convert()
        draw.circle(self.img_fondo, color_g, (rad_g, rad_g), rad_g)
        draw.circle(self.img_fondo, color_i, (rad_g, rad_g), rad_g - gros_g)
        self.img_fondo.set_colorkey((0, 0, 0))
        self.rect = self.img_fondo.get_rect()
        self.rect.center = centro
       
        # Se crea la imagen de la circunferencia pequeña
        self.img_mirada = Surface((rad_p * 2, rad_p * 2)).convert()
        draw.circle(self.img_mirada, color_p, (rad_p, rad_p), rad_p)
        self.img_mirada.set_colorkey((0, 0, 0))
       
        self.centro = float(centro[0]), float(centro[1])
        self.rad_p = rad_p
        self.rad_g = rad_g
        self.rad_mov = rad_mov
       
    def update(self, pos_rat):
        # Se hace una copia de la imagen de la circunferencia grande y se
        # imprime, sobre ella, la circunferencia pequeña con centro en la posición
        # que devuelve "obt_pos_mir".
        self.pos_mirada = self.obt_pos_mir(pos_rat)
        self.image = self.img_fondo.copy()
        self.image.blit(self.img_mirada, (self.pos_mirada[0] - self.rad_p, self.pos_mirada[1] - self.rad_p))
       
    def obt_pos_mir(self, pos_rat):
        # Se devuelve la posición en la que se tiene que situar el centro de la
        # circunferencia pequeña, en relación a la grande, dependiendo de la
        # posición del ratón.
        # Para ello, hace falta saber el ángulo exacto del centro a la posición
        # del ratón. Teniendo en cuenta que tan(ángulo) == tan(ángulo + pi).
        if self.dis_pq(pos_rat, self.centro) > self.rad_mov:
            if (pos_rat[0] - self.centro[0]) == 0:
                if pos_rat[1] > self.centro[1]:
                    a = pi / 2
                else:
                    a = - pi / 2
            else:
                if pos_rat[0] > self.centro[0]:
                    a = atan((self.centro[1] - pos_rat[1]) / (self.centro[0] - pos_rat[0]))
                else:
                    a = pi + atan((self.centro[1] - pos_rat[1]) / (self.centro[0] - pos_rat[0]))
            x = self.rad_g + cos(a) * self.rad_mov
            y = self.rad_g + sin(a) * self.rad_mov
            return x, y
        else:
            x = pos_rat[0] - self.centro[0] + self.rad_g
            y = pos_rat[1] - self.centro[1] + self.rad_g
            return x, y
           
    def dis_pq(self, P, Q):
        # Se devuelve la distancia de un punto a otro
        Px, Py = P
        Qx, Qy = Q
       
        h = hypot(Px - Qx, Py - Qy)
        return h

def main():
    # Se crea la pantalla con la resolución determinada
    screen = pygame.display.set_mode(resolucion)
    # Se crea el grupo ojos y se añaden dos
    ojos = pygame.sprite.Group()
    ojos.add(Ojo((230, 155), 25, 4, (100, 60, 100), (255, 204, 255), 13, 7, (120,140,60)))
    ojos.add(Ojo((300, 150), 35, 7, (255, 100, 50), (204, 255, 255), 11, 12, (60,125,120)))
   
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                # Finaliza el programa si hay un evento de cerrar
                return
        screen.fill(color)  # Se pinta la pantalla
        pos = mouse.get_pos()  # Se obtiene la posición del ratón
        ojos.update(pos)  # Se actualizan los ojos dependiendo de "pos"
        ojos.draw(screen)  # Se dibujan los ojos
        display.update()  # Se actualiza la pantalla

if __name__ == '__main__':
    main()
