/*
 * Copyright (C) 2006 Gabriel Valentin
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <SDL.h>

#define COLOR 255, 255, 255
#define LADO 300

void put_pixel(SDL_Surface *_ima, int x, int y, Uint32 pixel);
void esperar (void);

int main (void)
{
	SDL_Surface * screen;
	Uint32 color;
	int i = 0, j = 0;
	int x = 0, y = 0;
	
	SDL_Init (SDL_INIT_VIDEO);
	
	screen = SDL_SetVideoMode (640, 480, 16, SDL_HWSURFACE);

	color = SDL_MapRGB (screen->format,COLOR);
	
		// DIBUJA LOS LADOS VERTICALES
	for (; i < LADO; i++)
	{
		for (x = j = 0; j < 2; j++, x += LADO)
			put_pixel (screen, 150 + x, 60 + i, color);	
	}
		
		// DIBUJA LOS LADOS HORIZONTALES
	for (i = 0; i < LADO; i++)
	{
		for (y = j = 0; j < 2; j++, y += LADO)
			put_pixel (screen, 150 + i, 60 + y, color);	
	}
	
	SDL_Flip (screen);
		
	esperar ();
	
	return 0;
}

void put_pixel(SDL_Surface *_ima, int x, int y, Uint32 pixel)
{
	int bpp = _ima->format->BytesPerPixel;
	Uint8 *p = (Uint8 *)_ima->pixels + y * _ima->pitch + x*bpp;

	switch (bpp)
	{
		case 1:
			*p = pixel;
			break;
			
		case 2:
			*(Uint16 *)p = pixel;
			break;
			
		case 3:
			if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
			{
				p[0]=(pixel >> 16) & 0xff;
				p[1]=(pixel >> 8) & 0xff;
				p[2]=pixel & 0xff;
			}
			else
			{
				p[0]=pixel & 0xff;
				p[1]=(pixel >> 8) & 0xff;
				p[2]=(pixel >> 16) & 0xff;
			}
			break;
			
		case 4:
			*(Uint32 *) p = pixel;
			break;
	}
}


void esperar (void)
{
	SDL_Event evento;
	
	while ( SDL_WaitEvent (& evento))
	{
		if (evento.type == SDL_KEYDOWN)
			return;
	}
}
