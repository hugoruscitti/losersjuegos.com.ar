/*
 * Copyright (C) 2007 Pablo Abratte
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>

/* El tiempo que va a tardar el fundido */
#define TIEMPO_DE_FUNDIDO 3000
/* Directorio donde estan las imagenes */
#define DATADIR "../data/"

/* Las funciones que van a utilizarse */
void fundirPantalla(SDL_Surface *, Uint32);
Uint32 getpixel(SDL_Surface *, int, int);
void putpixel(SDL_Surface *, int, int, Uint32);


/*
 * La funcion principal
 */
int main(int argc, char **argv){
	SDL_Surface *pantalla, *imagen1, *imagen2;
	int salir=0; /*	Para saber cuando tenemos que salir del programa */
	SDL_Event event;
	int imagenActual=1; /* La imagen que estamos mostrando */


	/* Inicializamos la libreria SDL y comprobamos que no haya errores */
	if(SDL_Init(SDL_INIT_VIDEO)!=0){
		fprintf(stderr,"ERROR: %s\n",SDL_GetError());
		exit(-1);
	}
	
	/* Cargamos la primer imagen */
	imagen1=SDL_LoadBMP(DATADIR "imagen1.bmp");
	if(imagen1==NULL){
		fprintf(stderr,"ERROR: %s\n",SDL_GetError());
		exit(-1);
	}

	/* Cargamos la segunda imagen */
	imagen2=SDL_LoadBMP(DATADIR "imagen2.bmp");
	if(imagen1==NULL){
		fprintf(stderr,"ERROR: %s\n",SDL_GetError());
		exit(-1);
	}

	
	/* Seteamos el modo de video, creamos una ventana con el tama�o de las
	   imagenes, comprobamos que no haya errores */
	pantalla=SDL_SetVideoMode(imagen1->w,imagen1->h,imagen1->format->BitsPerPixel,SDL_HWSURFACE|SDL_DOUBLEBUF);
	if(pantalla==NULL){
		fprintf(stderr,"ERROR: %s\n",SDL_GetError());
		exit(-1);
	}
	
	/* Le ponemos titulo a la ventana que acabamos de crear */
	SDL_WM_SetCaption("Presione cualquier tecla para iniciar el fundido",
NULL);

	/* Volcamos la primer imagen sobre la superficie de la pantalla
	   y luego actualizamos el video */
	SDL_BlitSurface(imagen1,NULL,pantalla,NULL);	
	SDL_Flip(pantalla);

	/* Bucle principal */
	while(!salir){
		while(SDL_PollEvent(&event)){
			switch(event.type){
				/* Manejar evento de cerrar la ventana */
				case SDL_QUIT:
				salir=1;
				break;

				/* Manejar pulsaciones de teclas */
				case SDL_KEYDOWN:
					switch(event.key.keysym.sym){
						case SDLK_ESCAPE:
						salir=1;
						break;
						
						default:
							if(imagenActual==1){
							fundirPantalla(imagen2,TIEMPO_DE_FUNDIDO);
							imagenActual=2;
							}else{
							fundirPantalla(imagen1,TIEMPO_DE_FUNDIDO);
							imagenActual=1;
							}
							break;
					}
				break;
			}
		}
	}

	SDL_Quit();
return 0;
}



/*
 * Las funciones getpixel y putpixel proporcionadas por la
 * documentacion de SDL. Las vamos a usar para trabajar
 * directamente sobre las superficies
 */
Uint32 getpixel(SDL_Surface *surface, int x, int y){
    int bpp = surface->format->BytesPerPixel;
    /* Here p is the address to the pixel we want to retrieve */
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch(bpp) {
    case 1:
        return *p;

    case 2:
        return *(Uint16 *)p;

    case 3:
        if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
            return p[0] << 16 | p[1] << 8 | p[2];
        else
            return p[0] | p[1] << 8 | p[2] << 16;

    case 4:
        return *(Uint32 *)p;

    default:
        return 0;
    }
}


void putpixel(SDL_Surface *surface, int x, int y, Uint32 pixel){
    int bpp = surface->format->BytesPerPixel;
    /* Here p is the address to the pixel we want to set */
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch(bpp) {
    case 1:
        *p = pixel;
        break;

    case 2:
        *(Uint16 *)p = pixel;
        break;

    case 3:
        if(SDL_BYTEORDER == SDL_BIG_ENDIAN) {
            p[0] = (pixel >> 16) & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = pixel & 0xff;
        } else {
            p[0] = pixel & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = (pixel >> 16) & 0xff;
        }
        break;

    case 4:
        *(Uint32 *)p = pixel;
        break;
    }
}






/*
 * Descripcion: Realiza un fundido progresivo entre la superficie de video y
 * 		una imagen proporcionada 
 * Parametro:	Imagen con la cual realizar el fundido
 * Parametro:	Duracion en milisegundos del fundido
 * Devuelve:	void
 */
void fundirPantalla(SDL_Surface *imagen, Uint32 duracion){
	Uint32 ticksPrincipio, ticksActuales, contx, conty;

	/* Declaramos 3 variables para pixeles (uno para el de la imagen original,
	otro para la imagen que vamos a mostrar progresivamente y el tercero para
	guardar el valor de color que nos corresponde mostrar en cada iteracion).
	Ademas, declaramos los componentes RGB de cada pixelk */
	Uint32 pixelOriginal, pixelImagen, pixelNuevo;
	Uint8 rOrig, gOrig, bOrig;
	Uint8 rImagen, bImagen, gImagen;
	Uint8 rNuevo, bNuevo, gNuevo;

	/* El porcentaje del proceso que ya se realizo */
	float porcentage;
	
	
	SDL_Surface *pantalla, *copiaPantalla;
	pantalla=SDL_GetVideoSurface();
	/* Copiamos la pantalla para conservar una copia, ya que a la original la
	vamos a modificar en cada iteracion */
	copiaPantalla=SDL_CreateRGBSurface(SDL_HWSURFACE,pantalla->w,pantalla->h,pantalla->format->BitsPerPixel,pantalla->format->Rmask,pantalla->format->Gmask,pantalla->format->Bmask,pantalla->format->Amask);
	SDL_BlitSurface(pantalla,NULL,copiaPantalla,NULL);
	
	
	ticksPrincipio=ticksActuales=SDL_GetTicks();

	while(ticksActuales-ticksPrincipio<duracion){
		
		ticksActuales=SDL_GetTicks();
		/* Calculamos el procentaje del proceso que ya se llevo a cabo */
		porcentage=(float)((ticksActuales-ticksPrincipio)*100)/duracion;
		if(porcentage>100) porcentage=100;
	
			/* Antes de trabajar directamente sobre las superficies,
			posiblemente sea necesario bloquearlas */
			if(SDL_MUSTLOCK(pantalla)) SDL_LockSurface(pantalla);
			if(SDL_MUSTLOCK(copiaPantalla))SDL_LockSurface(copiaPantalla);
			if(SDL_MUSTLOCK(imagen)) SDL_LockSurface(imagen);

			for(contx=0; contx<pantalla->w; contx++){
				for(conty=0; conty<pantalla->h; conty++){
					/* Leemos los pixeles de la imagen que teniamos al principio
					y de la imagen a la cual vamos a llegar y separamos el color de
					cada pixel en sus componentes RGB */
					pixelOriginal=getpixel(copiaPantalla,contx,conty);
					pixelImagen=getpixel(imagen,contx,conty);
					SDL_GetRGB(pixelOriginal,copiaPantalla->format,&rOrig,&gOrig,&bOrig);
					SDL_GetRGB(pixelImagen,pantalla->format,&rImagen,&gImagen,&bImagen);
						
						/* Con las componentes RGB de cada pixel y el porcentaje actual
						del proceso calculamos las componentes del pixel que deberiamos
						ver en este momento*/
						if(rOrig>rImagen)
							rNuevo=rOrig-(porcentage*(rOrig-rImagen)/(float)100);
						else if(rOrig<rImagen)
							rNuevo=rOrig+(porcentage*(rImagen-rOrig)/(float)100);
						else rNuevo=rImagen;

						if(gOrig>gImagen)
							gNuevo=gOrig-(porcentage*(gOrig-gImagen)/(float)100);
						else if(gOrig<gImagen)
							gNuevo=gOrig+(porcentage*(gImagen-gOrig)/(float)100);
						else gNuevo=gImagen;
					
						if(bOrig>bImagen)
							bNuevo=bOrig-(porcentage*(bOrig-bImagen)/(float)100);
						else if(bOrig<bImagen)
							bNuevo=bOrig+(porcentage*(bImagen-bOrig)/(float)100);
						else bNuevo=bImagen;
					
					/* Formamos el nuevo pixel con las componentes RGB calculadas
					y lo ponemos en pantalla */
					pixelNuevo=SDL_MapRGB(pantalla->format,rNuevo,gNuevo,bNuevo);
					putpixel(pantalla,contx,conty,pixelNuevo);
				}
			}
			/* Desbloqueamos las superficies y actualizamos la pantalla */
			if(SDL_MUSTLOCK(pantalla)) SDL_UnlockSurface(pantalla);
			if(SDL_MUSTLOCK(copiaPantalla))SDL_UnlockSurface(copiaPantalla);
			if(SDL_MUSTLOCK(imagen)) SDL_LockSurface(imagen);
		SDL_Flip(pantalla);
	}
	/* Una vez terminado el proceso, la copia que hicimos de la superficie de video ya no nos sirve */
	SDL_FreeSurface(copiaPantalla);
}
